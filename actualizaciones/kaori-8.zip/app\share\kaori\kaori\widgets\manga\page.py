import re
import asyncio
from gi.repository import Gtk, Adw, GObject, Gio, GLib

from ...integrations import models

from .backdrop import Backdrop
from .card import MangaCard
from .chapters import ChapterList, real_dates
from .preview import ChapterPreview
from .similar import SimilarRow
from ...integrations.compare import format_updated

CHAPTER_RETRY_DELAYS = (3, 8)  # s before trying the site again


def explain_error(error) -> str:
    """Why the chapters didn't load, in words."""
    text = str(getattr(error, "errors", None) or error)
    if "cloudflare" in text.casefold():
        return ("El sitio está pidiendo una verificación anti-bots (Cloudflare) y no dejó cargar los capítulos. "
                "Suele pasarse en unos minutos: pulsa Reintentar o prueba «Buscar en otras fuentes».")
    for code in ("429", "500", "502", "503", "520", "521", "522", "523", "524"):
        if f"HTTP error {code}" in text or f" {code}" in text:
            return f"El sitio no responde ahora mismo (error {code}). Pulsa Reintentar en un rato o prueba «Buscar en otras fuentes»."
    if "timed out" in text.casefold() or "timeout" in text.casefold():
        return "El sitio tardó demasiado en responder. Pulsa Reintentar o prueba «Buscar en otras fuentes»."
    return f"No se pudieron cargar los capítulos ({text[:160]}). Pulsa Reintentar o prueba «Buscar en otras fuentes»."


STATUS_NAMES = {
    "ONGOING": "En emisión", "COMPLETED": "Finalizada", "PUBLISHING_FINISHED": "Publicación terminada",
    "CANCELLED": "Cancelada", "ON_HIATUS": "En pausa", "LICENSED": "Licenciada",
}

def markdown_to_pango(md: str) -> str:
    if md is None:
        return
    def inline(text: str) -> str:
        text = GLib.markup_escape_text(text or "")

        text = re.sub(
            r"`([^`]+)`",
            r'<tt>\1</tt>',
            text,
        )

        text = re.sub(
            r"\*\*(.+?)\*\*",
            r"<b>\1</b>",
            text,
        )

        text = re.sub(
            r"(?<!\*)\*(.+?)\*(?!\*)",
            r"<i>\1</i>",
            text,
        )

        text = re.sub(
            r"\[(.*?)\]\((.*?)\)",
            r'<a href="\2">\1</a>',
            text,
        )

        return text

    lines = md.splitlines()
    out = []

    for line in lines:
        stripped = line.strip()

        if not stripped:
            out.append("")
            continue

        m = re.match(r"^(#{1,6})\s+(.*)$", stripped)
        if m:
            level = len(m.group(1))
            size = {
                1: "xx-large",
                2: "x-large",
                3: "large",
                4: "medium",
                5: "small",
                6: "small",
            }[level]

            out.append(
                f'<span size="{size}" weight="bold">{inline(m.group(2))}</span>'
            )
            continue

        m = re.match(r"^[-*]\s+(.*)$", stripped)
        if m:
            out.append(f"• {inline(m.group(1))}")
            continue

        out.append(inline(line))

    return "\n".join(out)


@Gtk.Template(resource_path='/io/github/riyaniii/Kaori/manga/page.ui')
class MangaPage(Adw.NavigationPage):
    __gtype_name__ = "KaoriMangaPage"

    model = GObject.Property(type=models.Manga)

    genres = Gtk.Template.Child()
    description = Gtk.Template.Child()
    library = Gtk.Template.Child()
    read = Gtk.Template.Child()
    resume_box = Gtk.Template.Child()
    resume_label = Gtk.Template.Child()
    resume_progress = Gtk.Template.Child()
    preview_box = Gtk.Template.Child()
    facts = Gtk.Template.Child()
    chapters_box = Gtk.Template.Child()
    similar_box = Gtk.Template.Child()
    backdrop_slot = Gtk.Template.Child()
    series_box = Gtk.Template.Child()
    series_label = Gtk.Template.Child()
    series_progress = Gtk.Template.Child()

    def __init__(self, model):
        super().__init__()
        self.model = model
        app = Gio.Application.get_default()
        self.suwayomi = app.suwayomi
        self.history = app.history

        # Keep the "Continuar" button in sync with Tus Lecturas and the chapter list
        self.handlers = []

        # Download menu: "manga.download" with the batch name as target
        actions = Gio.SimpleActionGroup()
        download = Gio.SimpleAction.new("download", GLib.VariantType.new("s"))
        download.connect("activate", lambda action, batch: asyncio.create_task(self.download(batch.get_string())))
        actions.add_action(download)
        self.insert_action_group("manga", actions)

        self.backdrop = Backdrop()
        self.backdrop_slot.set_child(self.backdrop)
        self.backdrop.set_paintable(self.model.paintable)
        # "Tus capturas": panels of this series saved to the Galería, in reading order
        self.captures = app.captures
        self.captures_section = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, margin_bottom=18,
                                        visible=False)
        captures_header = Gtk.Box(spacing=10)
        captures_header.append(Gtk.Label(label="Tus capturas", css_classes=["title-4"]))
        self.captures_count = Gtk.Label(css_classes=["dim-label"], hexpand=True, xalign=0)
        captures_header.append(self.captures_count)
        gallery_button = Gtk.Button(label="Ver Galería", css_classes=["flat"], action_name="app.open_gallery")
        captures_header.append(gallery_button)
        self.captures_section.append(captures_header)
        self.captures_strip = Gtk.Box(spacing=8)
        self.captures_section.append(Gtk.ScrolledWindow(vscrollbar_policy=Gtk.PolicyType.NEVER,
                                                        propagate_natural_height=True,
                                                        child=self.captures_strip))
        self.chapters_box.append(self.captures_section)

        self.chapter_list = ChapterList(self)
        self.chapters_box.append(self.chapter_list)
        self.similar = SimilarRow()
        self.similar_box.append(self.similar)
        self.source_name = ""
        self.identity_entry = None
        self.identity_state = "pending"  # pending / found / missing
        self.identity_task = None
        self.creators = []  # who wrote / drew it, once identified in AniList
        self.anilist_facts = []  # score and years from AniList, which no source has
        self.anilist_task = None

        self.connect("realize", self.on_realize)
        self.connect("unrealize", self.on_unrealize)
        self.add_status_selector()
        self.update_resume()

    def add_status_selector(self):
        """Leyendo / Pendiente / Completada / Abandonada, next to the heart. Choosing one also adds
        the series to the library."""
        from ...tracker import STATUSES
        self.tracker = Gio.Application.get_default().tracker
        self.statuses = [status for status, _ in STATUSES]
        self.status = Gtk.DropDown.new_from_strings([name for _, name in STATUSES])
        self.status.set_tooltip_text("Estado en tu biblioteca")
        self.status.set_valign(Gtk.Align.CENTER)
        self.status.set_visible(self.model.in_library)
        self.library.get_parent().append(self.status)
        self.updating_status = False
        self.sync_status()
        self.status.connect("notify::selected", self.on_status_selected)
        self.model.connect("notify::in-library", lambda *_: (self.status.set_visible(self.model.in_library),
                                                              self.sync_status()))
        self.tracker.connect("changed", lambda *_: self.sync_status())

    def sync_status(self):
        self.updating_status = True
        self.status.set_selected(self.statuses.index(self.tracker.status_of(self.model)))
        self.updating_status = False

    def on_status_selected(self, *args):
        if not self.updating_status:
            self.tracker.set_status(self.model.id, self.statuses[self.status.get_selected()])

    def on_realize(self, *_):
        self.handlers = [
            (self.history, self.history.connect("changed", lambda *_: self.update_resume())),
            (self.model, self.model.connect("notify::last-read-chapter", lambda *_: self.update_resume())),
            (self.model, self.model.connect("notify::paintable",
                                            lambda *_: self.backdrop.set_paintable(self.model.paintable))),
            (self.model, self.model.connect("notify::status", lambda *_: self.update_facts())),
            (self.captures, self.captures.connect("changed", lambda *_: self.update_captures())),
        ]
        self.update_captures()
        if self.model.chapters is not None:
            self.handlers.append((self.model.chapters,
                                  self.model.chapters.connect("items-changed", lambda *_: self.update_resume())))
        self.chapter_list.connect_model()
        self.update_resume()

        # Hold the cover while this page is up, and fetch it when no list loaded it first
        # (opened from Tus Lecturas or the reader, whose tiles keep covers of their own)
        from ..containers import covers  # imported here: the containers import this package
        covers.retain(self.model)
        self.retained_cover = True
        if self.model.paintable is None and self.model.thumbnail_url:
            asyncio.create_task(self.load_cover())

    async def load_cover(self):
        from ..containers import covers
        try:
            paintable = await covers.load(self.suwayomi, self.model.id, self.model.thumbnail_url, identify=True)
        except asyncio.CancelledError:
            raise
        except Exception:
            return
        if paintable and self.model.paintable is None:
            self.model.paintable = paintable

    def on_unrealize(self, *_):
        for obj, handler in self.handlers:
            obj.disconnect(handler)
        self.handlers = []
        self.chapter_list.disconnect_model()
        if getattr(self, "retained_cover", False):
            from ..containers import covers
            covers.release(self.model)
            self.retained_cover = False
        self.handlers = []

    def resume_point(self):
        """(chapter, 1-based page, page count) where reading was left, or None if never read."""
        if entry := self.history.entries.get(str(self.model.id)):
            chapter = self.suwayomi.getModel(entry['chapter_id'], 'Chapter')
            if chapter is not None:
                return chapter, entry.get('page', 1), entry.get('page_count', 0) or chapter.page_count
        last = self.model.last_read_chapter
        if last is not None:
            # Suwayomi can point at a chapter that was only opened or fetched, not read: require real progress
            chapter = self.suwayomi.getModel(last.id, 'Chapter')
            if chapter is not None and (chapter.is_read or chapter.last_page_read > 0):
                return chapter, max(chapter.last_page_read, 1), chapter.page_count
        return None

    def first_chapter(self):
        chapters = list(self.model.chapters or [])
        if not chapters:
            return None
        return min(chapters, key=lambda chapter: (chapter.chapter_number, chapter.source_order))

    def update_captures(self):
        from ..pages.gallery import CaptureTile  # imported here: the pages import this package
        while child := self.captures_strip.get_first_child():
            self.captures_strip.remove(child)
        entries = self.captures.for_manga(self.model.id)
        for entry in entries:
            self.captures_strip.append(CaptureTile(entry))
        self.captures_count.set_label(str(len(entries)))
        self.captures_section.set_visible(bool(entries))

    def update_series_progress(self):
        chapters = list(self.model.chapters or [])
        if not chapters:
            self.series_box.set_visible(False)
            return
        read = sum(1 for chapter in chapters if chapter.is_read)
        share = read / len(chapters)
        text = f"{read} de {len(chapters)} capítulos leídos · {round(share * 100)} %"
        entry = self.history.entries.get(str(self.model.id)) or {}
        if minutes := round(entry.get('seconds', 0) / 60):
            text += f" · {minutes // 60} h {minutes % 60} min" if minutes >= 60 else f" · {minutes} min"
        self.series_label.set_label(text)
        self.series_progress.set_fraction(share)
        self.series_box.set_visible(True)

    def start_identify(self):
        if self.identity_task is None or self.identity_task.done():
            self.identity_task = asyncio.create_task(self.identify())

    async def identify(self):
        """Which real series this is (AniList / MangaUpdates), then recommendations for it."""
        identity = Gio.Application.get_default().identity
        try:
            entry = await identity.identify(self.model.id, self.model.title, self.model.description or "")
        except Exception:
            entry = None
        self.identity_entry = entry
        self.identity_state = "found" if entry else "missing"
        self.creators = []
        if entry and entry.get("anilist_id"):
            from .similar import shared_anilist
            try:
                self.creators = await shared_anilist().creators_of(entry["anilist_id"])
            except Exception:
                self.creators = []
        self.update_facts()
        self.similar.load(self.model.title, list(self.model.genre or []), (entry or {}).get("anilist_id"))
        if entry and entry.get("anilist_id"):
            self.anilist_task = asyncio.create_task(self.fill_from_anilist(entry["anilist_id"]))

    async def fill_from_anilist(self, anilist_id):
        """What the source left empty, from AniList: the synopsis (in Spanish), genres and cover;
        plus its score and years, which no source gives."""
        from .similar import shared_anilist
        from ...integrations import synopsis
        try:
            media = await shared_anilist().details(anilist_id)
        except Exception:
            return
        if not media:
            return
        facts = []
        if score := media.get("averageScore"):
            facts.append(("starred-symbolic", f"★ {score} en AniList"))
        start = (media.get("startDate") or {}).get("year")
        end = (media.get("endDate") or {}).get("year")
        if start:
            facts.append(("x-office-calendar-symbolic",
                          f"Desde {start}" if not end else str(start) if end == start else f"{start}–{end}"))
        self.anilist_facts = facts
        self.update_facts()
        if not self.model.genre and media.get("genres"):
            self.genres.set_visible(self.populate_genres(None, [synopsis.GENRES_ES.get(g, g)
                                                                 for g in media["genres"]]))
        cover = (media.get("coverImage") or {}).get("extraLarge")
        if self.model.paintable is None and cover:  # the source's cover is missing or broken
            try:
                paintable = await self.suwayomi.getPaintable(cover)
            except Exception:
                paintable = None
            if paintable and self.model.paintable is None:
                self.model.paintable = paintable
        if synopsis.lacks_description(self.model.description) and media.get("description"):
            self.description.set_label("<i>Traduciendo la sinopsis de AniList…</i>")
            self.description.set_visible(True)
            text, translated = await synopsis.shared().spanish(anilist_id, media["description"])
            if not synopsis.lacks_description(self.model.description):
                return  # the source sent one meanwhile
            note = ("Sinopsis de AniList, traducida automáticamente" if translated else
                    "Sinopsis de AniList (en inglés: la traducción no está disponible ahora)")
            self.description.set_label(GLib.markup_escape_text(text) + f"\n\n<small><i>{note}</i></small>"
                                       if text else "")

    def on_linked(self):
        self.similar.reset()
        self.identity_state = "pending"
        self.start_identify()

    def link_chip(self, label, tooltip, callback, icon="web-browser-symbolic"):
        chip = Gtk.Button(css_classes=["flat", "fact-chip", "fact-link"], tooltip_text=tooltip)
        box = Gtk.Box(spacing=6)
        box.append(Gtk.Image(icon_name=icon, pixel_size=14))
        box.append(Gtk.Label(label=label))
        chip.set_child(box)
        chip.connect("clicked", lambda button: callback())
        return chip

    def open_creator(self, person):
        from ..pages.for_you import CreatorPage
        mode = Gio.Application.get_default().settings.get_string("foryou-adult")
        self.get_ancestor(Adw.NavigationView).push(CreatorPage(person["id"], person["name"], mode))

    def open_url(self, url):
        Gtk.UriLauncher(uri=url).launch(self.get_root(), None, None)

    def update_facts(self):
        while child := self.facts.get_first_child():
            self.facts.remove(child)
        chapters = list(self.model.chapters or [])
        facts = []
        if self.source_name:
            facts.append(("folder-remote-symbolic", self.source_name))
        if status := STATUS_NAMES.get(self.model.status or ""):
            facts.append(("media-playback-start-symbolic" if self.model.status == "ONGOING" else
                          "emblem-ok-symbolic", status))
        if chapters:
            facts.append(("view-list-bullet-symbolic", f"{len(chapters)} capítulos"))
            dates = real_dates(chapters)  # sources without dates get the fetch time: not an update
            if dates:
                facts.append(("document-open-recent-symbolic", format_updated(max(dates) / 1000).capitalize()))
        if self.model.artist and self.model.artist != self.model.author:
            facts.append(("applications-graphics-symbolic", self.model.artist))
        facts += self.anilist_facts
        for icon, text in facts:
            chip = Gtk.Box(spacing=6, css_classes=["fact-chip"])
            chip.append(Gtk.Image(icon_name=icon, pixel_size=14))
            chip.append(Gtk.Label(label=text))
            self.facts.append(chip)

        # The real series behind the scan's name: links to its listings, or a way to link it by hand
        entry = self.identity_entry or {}
        found = f"Identificada como «{entry.get('title')}»" if entry else ""
        if entry.get("anilist_id"):
            self.facts.append(self.link_chip("AniList", f"{found} · abrir su ficha",
                                             lambda: self.open_url(f"https://anilist.co/manga/{entry['anilist_id']}")))
        if entry.get("mu_url"):
            self.facts.append(self.link_chip("MangaUpdates", f"{found} · abrir su ficha",
                                             lambda: self.open_url(entry["mu_url"])))
        for person in self.creators:
            self.facts.append(self.link_chip(f"{person['name']} · {person['role']}", "Ver todas sus obras",
                                             lambda p=person: self.open_creator(p), icon="avatar-default-symbolic"))
        if self.identity_state == "missing" or (entry and not entry.get("anilist_id")):
            from .link import LinkDialog
            self.facts.append(self.link_chip("Vincular serie", "Kaori no sabe qué serie es esta: elígela en AniList "
                                             "para tener recomendaciones", lambda: LinkDialog(self.model, self.on_linked)
                                             .present(self.get_root()), icon="insert-link-symbolic"))
        self.facts.set_visible(self.facts.get_first_child() is not None)

    async def load_source(self):
        try:
            source = await self.suwayomi.getMangaSource(self.model.id)
        except Exception:
            return
        if source:
            self.source_name = source.get('displayName') or source.get('name') or ""
            self.update_facts()

    @Gtk.Template.Callback()
    def on_compare_clicked(self, button):
        asyncio.create_task(self.compare_everywhere(button))

    async def compare_everywhere(self, button):
        """Search every source with all the names this series goes by, then compare them.

        The series is already identified here, so its real names are used: this source's title,
        the English one from its listing, MangaDex's Spanish ones (checked by AniList id) and
        translations as a fallback."""
        from ..pages.ranking_detail import search_in_sources
        app = Gio.Application.get_default()
        names = [self.model.title]
        button.set_sensitive(False)
        button.set_label("Preparando nombres…")
        try:
            if self.identity_task is not None and not self.identity_task.done():
                await self.identity_task
            entry = self.identity_entry or {}
            if entry.get("title"):
                found = await app.names.for_entry({"id": entry.get("anilist_id"), "title": entry["title"],
                                                   "search_titles": [entry["title"]]})
            else:
                found = await app.names.for_typed(self.model.title)
            names += [name for name in found if name not in names]
        except Exception:
            pass
        finally:
            button.set_sensitive(True)
            button.set_label("Buscar en otras fuentes")
        search_in_sources(self.get_root(), names, self.model.title, compare=True)

    def update_resume(self):
        self.update_series_progress()
        self.update_facts()
        self.chapter_list.queue_rebuild()
        point = self.resume_point()
        if point is None:
            self.read.set_label("▶  Empezar")
            self.read.set_tooltip_text("Leer desde el primer capítulo")
            self.resume_box.set_visible(False)
            return
        chapter, page, count = point
        short = chapter.name.replace("Capítulo", "Cap.").replace("Capitulo", "Cap.")
        self.read.set_label(f"▶  Continuar · {short}")
        self.read.set_tooltip_text(f"Seguir en {chapter.name}, página {page}")
        text = f"Te quedaste en {chapter.name} · página {page}" + (f" de {count}" if count > 0 else "")
        entry = self.history.entries.get(str(self.model.id)) or {}
        if new := entry.get('new_chapters', 0):
            text += f" · {new} capítulo{'s' if new > 1 else ''} nuevo{'s' if new > 1 else ''}"
        self.resume_label.set_label(text)
        self.resume_progress.set_visible(count > 0)
        if count > 0:
            self.resume_progress.set_fraction(min(page / count, 1.0))
        self.resume_box.set_visible(True)

    @Gtk.Template.Callback()
    def on_shown(self, *_):
        if not self.source_name:
            asyncio.create_task(self.load_source())
        if self.model.initialized:
            asyncio.create_task(self.load_chapters())
        else:
            asyncio.create_task(self.load_manga())
            return
        self.start_identify()

    async def load_manga(self):
        await self.with_retries(self.fetch_manga)

    async def load_chapters(self):
        await self.with_retries(self.fetch_chapters)

    async def with_retries(self, loader):
        """Sites fail now and then (Cloudflare checks, a minute offline): try again a couple of times,
        then say why under Capítulos, with a button to retry, instead of "Cargando…" forever."""
        for delay in (*CHAPTER_RETRY_DELAYS, None):
            try:
                await loader()
                self.chapter_list.set_load_error(None)
                return
            except asyncio.CancelledError:
                raise
            except Exception as error:
                print(f"[capítulos] {self.model.title}: {error}")
                if delay is None:
                    self.chapter_list.set_load_error(
                        explain_error(error), lambda: asyncio.create_task(
                            self.load_chapters() if self.model.initialized else self.load_manga()))
                    return
                self.chapter_list.set_load_error("El sitio no respondió, reintentando…")
                await asyncio.sleep(delay)

    async def fetch_manga(self):
        await self.suwayomi.getManga(self.model.id)
        self.update_resume()
        self.start_identify()
        if self.model.paintable is None and self.model.thumbnail_url and self.get_realized():
            asyncio.create_task(self.load_cover())
        self.refresh_chapter_panel()
        self.build_preview()

    async def fetch_chapters(self):
        await self.suwayomi.getChapters(self.model.id)
        self.update_resume()
        self.refresh_chapter_panel()
        self.build_preview()

    def build_preview(self):
        """Peek at the first chapter; folded when the series is already being read."""
        if self.preview_box.get_first_child() is not None:
            return
        chapter = self.first_chapter()
        if chapter is None:
            return
        # Open for series you haven't started; folded (one line) once you're reading it, so your
        # captures and the chapter list come first
        started = self.resume_point() is not None or str(self.model.id) in self.history.entries
        preview = ChapterPreview(self.suwayomi, self.open_chapter, expanded=not started)
        preview.set_chapter(chapter)
        self.preview_box.append(preview)
        self.preview_box.set_visible(True)

    def refresh_chapter_panel(self):
        self.activate_action("app.set_chapters", GLib.Variant("i", self.model.id))

    @Gtk.Template.Callback()
    def populate_genres(self, obj, genre):
        while child := self.genres.get_first_child():
            self.genres.remove(child)
        for name in genre or []:
            self.genres.append(Gtk.Button(label=name))
        return bool(genre)

    @Gtk.Template.Callback()
    def get_library_icon_name(self, obj, in_library):
        return "heart-filled-symbolic" if in_library else "heart-outline-thick-symbolic"

    @Gtk.Template.Callback()
    def get_library_button_tooltip(self, obj, in_library):
        return "Quitar de la biblioteca" if in_library else "Añadir a la biblioteca"

    @Gtk.Template.Callback()
    def on_read_clicked(self, *_):
        asyncio.create_task(self.open_reader())

    async def open_reader(self):
        if not self.model.chapters or not self.model.chapters.get_n_items():
            await self.suwayomi.getChapters(self.model.id)
        point = self.resume_point()
        if point is not None:
            chapter, page, _ = point
            chapter = self.suwayomi.getModel(chapter.id, 'Chapter') or chapter
            position = max(page - 1, 0)
        else:
            chapter, position = self.first_chapter(), 0
        if chapter is not None:
            self.open_chapter(chapter, position)

    def chapters_to_download(self, batch: str) -> list:
        """Chapters (oldest first, not downloaded yet) for a download batch: next5, next10, unread or all."""
        chapters = sorted(self.model.chapters or [], key=lambda chapter: (chapter.chapter_number, chapter.source_order))
        if batch != "all":
            # Unread ones from where you are: chapters before your current one don't count, even if never opened
            point = self.resume_point()
            start = point[0].chapter_number if point else float("-inf")
            chapters = [chapter for chapter in chapters if not chapter.is_read and chapter.chapter_number >= start]
        chapters = [chapter for chapter in chapters if not chapter.is_downloaded]
        limit = {"next5": 5, "next10": 10}.get(batch)
        return chapters[:limit] if limit else chapters

    async def download(self, batch: str):
        if not self.model.chapters or not self.model.chapters.get_n_items():
            await self.suwayomi.getChapters(self.model.id)
        chapters = self.chapters_to_download(batch)
        window = self.get_root()
        if not chapters:
            message = "No hay capítulos pendientes de descargar"
        else:
            try:
                await self.suwayomi.enqueueChapterDownloads([chapter.id for chapter in chapters])
                count = len(chapters)
                message = f"Descargando {count} capítulo{'s' if count != 1 else ''}"
            except Exception:
                message = "No se pudo iniciar la descarga"
        if window is not None:
            window.toast_overlay.dismiss_all()
            toast = Adw.Toast(title=message, timeout=3, use_markup=False)
            if chapters:
                toast.set_button_label("Ver")
                toast.set_action_name("app.open_downloads_page")
            window.toast_overlay.add_toast(toast)

    def open_chapter(self, chapter, position: int):
        from ..reader import ReaderPage

        window = self.get_root()
        self.history.mark_seen(self.model.id)
        window.chapter_panel.set_manga_model(self.model)
        reader = ReaderPage(self.model, chapter)
        reader.start_load(chapter, resume_position=position)  # the exact page, not just the chapter
        window.main_nav_view.push(reader)

    @Gtk.Template.Callback()
    def on_library_button_clicked(self, *_):
        self.activate_action("app.toggle_library", GLib.Variant("i", self.model.id))

    @Gtk.Template.Callback()
    def get_description(self, obj, description):
        return markdown_to_pango(description)
