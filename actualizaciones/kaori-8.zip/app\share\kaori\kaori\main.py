import asyncio
import os
import subprocess
import sys
import time


def process_age() -> float:
    """Seconds since this Python process was created (to see where a slow start goes)."""
    if sys.platform == 'win32':
        import ctypes
        from ctypes import wintypes
        try:
            kernel32 = ctypes.WinDLL('kernel32')
            kernel32.GetCurrentProcess.restype = wintypes.HANDLE
            kernel32.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
            times = [wintypes.FILETIME() for _ in range(4)]
            if kernel32.GetProcessTimes(kernel32.GetCurrentProcess(), *(ctypes.byref(t) for t in times)):
                created = ((times[0].dwHighDateTime << 32) | times[0].dwLowDateTime) / 1e7 - 11644473600
                return time.time() - created
        except Exception:
            pass
    return time.process_time()


print(f"[arranque] Python abierto, cargando módulos ({process_age():.1f} s)")

import gi

gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.events import GLibEventLoopPolicy

asyncio.set_event_loop_policy(GLibEventLoopPolicy())

from gi.repository import Adw, Gdk, Gio, GLib, Gtk
from gql.transport.exceptions import TransportError

from .constants import NAME, set_version
from .history import ReadingHistory
from .tracker import Tracker
from .updater import Updater
from .integrations.romance import ContentFilter
from .captures import Captures
from . import theme
from .integrations.identity import SeriesIdentity
from .integrations.names import SeriesNames
from .updates import UpdateChecker
from .integrations import Suwayomi
from .widgets import KaoriWindow, build_shortcuts
from .widgets.preferences import KaoriPreferences
from .widgets.setup import SetupWindow

print(f"[arranque] módulos cargados ({process_age():.1f} s)")

APPLICATION_ID = 'io.github.riyaniii.Kaori'

# With the OpenGL renderer on Windows (GDK_DEBUG=dcomp) the transparent client-side shadow and
# rounded corners are composited as black, so draw the window as a plain opaque rectangle there.
# Some older Intel GL drivers also skip every rounded background fill (dialogs, selected rows,
# toggles, slider knobs vanish), so square corners everywhere.
WINDOWS_CSS = """
window.csd, window.csd.maximized, window.solid-csd {
  box-shadow: none;
  margin: 0;
  outline: none;
}

* {
  border-radius: 0;
}
"""
JAR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                   'Suwayomi-Server.jar')
# Java runs from Kaori's folder (app/share/kaori/ -> three levels up)
SERVER_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(JAR))))
JAR_RELATIVE = os.path.relpath(JAR, SERVER_DIR)
# Kaori.exe gives an ASCII alias of that folder when its path has accents (Java can't start from it)
SERVER_DIR = os.environ.get('KAORI_SERVER_DIR') or SERVER_DIR

LOCAL_URL = 'http://localhost:4567'
READY_TIMEOUT = 90
POLL_INTERVAL = 0.5
MAIN_CLOSE_GRACE = 30  # s after opening in which only a close of the window in front counts

class AdoptedProcess:
    """A process this program didn't start (the server Kaori.exe launched), with the bits of
    subprocess.Popen that Kaori uses: pid, poll(), wait()."""

    STILL_ACTIVE = 259

    def __init__(self, pid, handle):
        self.pid = pid
        self.handle = handle

    @classmethod
    def open(cls, pid):
        if sys.platform != 'win32':
            return None
        import ctypes
        # SYNCHRONIZE | PROCESS_QUERY_LIMITED_INFORMATION
        handle = ctypes.windll.kernel32.OpenProcess(0x00100000 | 0x1000, False, pid)
        if not handle:
            return None
        process = cls(pid, handle)
        return process if process.poll() is None else None

    def poll(self):
        import ctypes
        code = ctypes.c_ulong()
        ctypes.windll.kernel32.GetExitCodeProcess(self.handle, ctypes.byref(code))
        return None if code.value == self.STILL_ACTIVE else code.value

    def wait(self, timeout=None):
        import ctypes
        ctypes.windll.kernel32.WaitForSingleObject(self.handle, 0xFFFFFFFF if timeout is None else int(timeout * 1000))
        return self.poll()

    def terminate(self):
        subprocess.run(['taskkill', '/F', '/T', '/PID', str(self.pid)], stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL, creationflags=subprocess.CREATE_NO_WINDOW)


SERVER_CMD = [
    'java',
    '-Dsuwayomi.tachidesk.config.server.systemTrayEnabled=false',
    '-Dsuwayomi.tachidesk.config.server.initialOpenInBrowserEnabled=false',
    # Kaori talks to the server directly: its own web interface only slows startup (~3-4 s)
    '-Dsuwayomi.tachidesk.config.server.webUIEnabled=false',
    '-Dsuwayomi.tachidesk.config.server.webUIUpdateCheckInterval=0',
    # KCEF (hidden Chromium) is needed by extensions whose site only works in a browser, e.g. Ikigai's search.
    # It's downloaded once into the Suwayomi data folder the first time an extension asks for it.
    '-Dsuwayomi.tachidesk.config.server.kcefEnabled=true',
    '-jar', JAR_RELATIVE,
]
if os.name == 'nt':
    # Server data and Java's temp files (GBs of page cache) inside Kaori's folder. Absolute paths
    # (the database refuses relative ones), from SERVER_DIR, which has no accents (see above).
    SERVER_CMD[1:1] = [
        '-Dsuwayomi.tachidesk.config.server.rootDir=' + os.path.join(SERVER_DIR, 'data', 'suwayomi'),
        '-Djava.io.tmpdir=' + os.path.join(SERVER_DIR, 'data', 'tmp'),
    ]


def run_until_done(coro, timeout: float) -> None:
    task = asyncio.ensure_future(coro)
    context = GLib.MainContext.default()
    deadline = time.monotonic() + timeout
    while not task.done() and time.monotonic() < deadline:
        if not context.iteration(False):
            time.sleep(0.01)
    if not task.done():
        task.cancel()


class KaoriApplication(Adw.Application):

    def __init__(self, version: str) -> None:
        super().__init__(application_id=APPLICATION_ID,
                         flags=Gio.ApplicationFlags.DEFAULT_FLAGS,
                         resource_base_path='/io/github/riyaniii/Kaori')
        self.version = version
        self.settings = Gio.Settings(schema_id=APPLICATION_ID)
        self.history = ReadingHistory()
        self.captures = Captures()
        self.tracker = Tracker(self.history)
        self.identity = SeriesIdentity()
        self.names = SeriesNames(self.identity)
        self.updates = UpdateChecker(self)
        self.updater = Updater(self)
        self.content_filter = ContentFilter(self.settings)
        self.suwayomi = Suwayomi()
        self.server: subprocess.Popen | None = None
        self.server_log = None

        self.create_action('quit', lambda *_: self.quit(), ['<control>q'])
        self.create_action('preferences', self.on_preferences_action, ['<control>comma'])
        self.create_action('appearance', self.on_appearance_action)
        self.create_action('check_updates', self.on_check_updates_action)
        self.create_action('shortcuts', self.on_shortcuts_action,
                           ['<control>question', '<control>slash'])
        self.create_action('about', self.on_about_action)
        self.create_action('change_instance', self.on_change_instance_action)

        if sys.platform == 'win32':
            self.connect('startup', self.on_windows_startup)

    def do_startup(self) -> None:
        Adw.Application.do_startup(self)
        # The SkyBlue Sakura theme (style.css) is designed for a dark background
        Adw.StyleManager.get_default().set_color_scheme(Adw.ColorScheme.FORCE_DARK)
        theme.apply_saved(self.settings)  # the colours chosen in Apariencia

    def on_windows_startup(self, app) -> None:
        # Windows shows python's icon for the window unless GTK is given the app's own
        Gtk.Window.set_default_icon_name(APPLICATION_ID)
        provider = Gtk.CssProvider()
        provider.load_from_string(WINDOWS_CSS)
        Gtk.StyleContext.add_provider_for_display(
            Gdk.Display.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

    def do_activate(self) -> None:
        if win := self.props.active_window:
            win.present()
            return

        mode = self.settings.get_string('suwayomi-mode')
        if mode not in ('local', 'remote'):
            self.show_setup_window()
            return

        self.hold()
        asyncio.create_task(
            self.launch_or_setup(mode, self.settings.get_string('suwayomi-url')))

    def do_shutdown(self) -> None:
        print(f"[cierre] Kaori se cierra {time.strftime('%X')}")
        self.history.flush()
        run_until_done(self.suwayomi.close(), 5)
        self.stop_server()
        Adw.Application.do_shutdown(self)

    def start_server(self) -> None:
        # Kaori.exe starts the server the moment it's clicked, while Python and GTK are still loading
        # (~6 s): adopt that one instead of starting another
        pid = os.environ.pop('KAORI_SERVER_PID', '')
        if pid.isdigit() and (adopted := AdoptedProcess.open(int(pid))):
            self.server = adopted
            return
        log_dir = os.path.join(GLib.get_user_cache_dir(), 'kaori')
        os.makedirs(log_dir, exist_ok=True)
        self.server_log = open(os.path.join(log_dir, 'server.log'), 'ab')
        # On Windows java is a console program: started from a windowless Kaori it would pop up its own console
        flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
        self.server = subprocess.Popen(
            SERVER_CMD, stdout=self.server_log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
            creationflags=flags, cwd=SERVER_DIR)

    def stop_server(self) -> None:
        if self.server:
            if sys.platform == 'win32':
                # The whole tree: KCEF's Chromium helpers would otherwise outlive Java
                subprocess.run(['taskkill', '/F', '/T', '/PID', str(self.server.pid)],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               creationflags=subprocess.CREATE_NO_WINDOW)
            else:
                self.server.terminate()
            self.server.wait()
            self.server = None
        if self.server_log:
            self.server_log.close()
            self.server_log = None

    async def launch_or_setup(self, mode: str, url: str) -> None:
        try:
            if not await self.launch(mode, url):
                self.show_setup_window(
                    error="Couldn't reconnect. Check your setup and try again.")
        except Exception as e:
            
            
            self.stop_server()
            self.show_setup_window(error=f"No se pudo iniciar: {e}")
        finally:
            self.release()

    def show_splash(self):
        """A small window while the server starts, so opening Kaori shows something right away."""
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14, valign=Gtk.Align.CENTER,
                      margin_start=32, margin_end=32, margin_top=28, margin_bottom=28)
        box.append(Gtk.Image(icon_name=APPLICATION_ID, pixel_size=96))
        box.append(Gtk.Label(label="Kaori", css_classes=["title-1"]))
        box.append(Adw.Spinner(width_request=32, height_request=32, halign=Gtk.Align.CENTER))
        self.splash_label = Gtk.Label(label="Iniciando el servidor…", css_classes=["dim-label"])
        box.append(self.splash_label)
        splash = Adw.ApplicationWindow(application=self, title="Kaori", default_width=360, default_height=320,
                                       resizable=False, content=box)
        # Window managers (tiling ones especially) may ask windows to close when focus moves to another
        # app: a close request here must not cancel the startup
        splash.connect("close-request", self.on_splash_close_request)
        splash.present()
        print(f"[arranque] pantalla de carga {time.strftime('%X')}")
        return splash

    def on_splash_close_request(self, window):
        print(f"[cierre] se pidió cerrar la pantalla de carga {time.strftime('%X')}: ignorado mientras Kaori abre")
        return True  # keep it: it's replaced by the main window when the server is ready

    def on_main_close_request(self, window):
        # Closing it yourself (X, Alt+F4) needs the window in front. A close request for a window that
        # was never active (opened while you were in another app, e.g. Brave) comes from somewhere else,
        # like a window manager re-tiling: keep it, or opening Kaori would silently be cancelled.
        just_opened = time.monotonic() - self.main_shown < MAIN_CLOSE_GRACE
        if not self.main_was_active or (just_opened and not window.is_active()):
            print(f"[cierre] se pidió cerrar la ventana sin haberla usado {time.strftime('%X')}: ignorado")
            return True
        print(f"[cierre] ventana principal cerrada {time.strftime('%X')} (al frente: {window.is_active()})")
        return False

    def on_main_active(self, window, *args):
        if window.is_active():
            self.main_was_active = True

    async def launch(self, mode: str, url: str) -> bool:
        local = mode == 'local'
        # Kaori.exe already shows its animated scene until the main window appears
        splash = None if os.environ.pop('KAORI_LAUNCHER_SPLASH', '') else self.show_splash()
        if local:
            self.start_server()
        self.suwayomi.reconnect(LOCAL_URL if local else url)

        print(f"[arranque] esperando servidor {time.strftime('%X')} ({process_age():.1f} s)")
        if not await self.wait_for_server():
            if splash:
                splash.disconnect_by_func(self.on_splash_close_request)
                splash.destroy()
            await self.suwayomi.disconnect()
            self.stop_server()
            return False
        if splash:
            self.splash_label.set_label("Abriendo tu biblioteca…")
        print(f"[arranque] servidor listo {time.strftime('%X')} ({process_age():.1f} s)")

        self.settings.set_string('suwayomi-mode', mode)
        self.settings.set_string('suwayomi-url', '' if local else url)
        win = KaoriWindow(application=self)
        print(f"[arranque] ventana creada {time.strftime('%X')} ({process_age():.1f} s)")
        if sys.platform == 'win32':
            win.maximize()  # windowed mode still shows a thin black resize border on Windows
        self.main_shown = time.monotonic()
        self.main_was_active = False
        win.connect("close-request", self.on_main_close_request)
        win.connect("notify::is-active", self.on_main_active)
        win.present()
        if splash:
            splash.disconnect_by_func(self.on_splash_close_request)
            splash.destroy()
        return True

    async def restart_server(self) -> bool:
        """Restart the bundled server (unsticks a source whose hidden browser hung). False if Kaori
        uses an external server it can't restart."""
        if self.server is None:
            return False
        self.stop_server()
        self.start_server()
        return await self.wait_for_server()

    async def wait_for_server(self) -> bool:
        loop = asyncio.get_running_loop()
        deadline = loop.time() + READY_TIMEOUT
        while loop.time() < deadline:
            if self.server and self.server.poll() is not None:
                return False
            try:
                if await self.suwayomi.getServerSettings():
                    return True
            except (TransportError, OSError, TimeoutError):
                
                pass
            await asyncio.sleep(POLL_INTERVAL)
        return False

    def show_setup_window(self, error: str | None = None) -> None:
        SetupWindow(application=self, error=error).present()

    def on_change_instance_action(self, *args) -> None:
        self.stop_server()
        if win := self.props.active_window:
            for dialog in list(win.get_dialogs()):
                dialog.force_close()
            win.close()
        self.show_setup_window()

    def on_about_action(self, *args) -> None:
        Adw.AboutDialog(
            application_name=NAME,
            application_icon=APPLICATION_ID,
            developer_name='Riyan Parvez',
            version=self.version,
            developers=['Riyan Parvez (rini)'],
            designers=['Riyan Parvez (rini)'],
            copyright='© 2026 Riyan Parvez',
            issue_url='https://github.com/riyaniii/Kaori/issues',
            license='GPL-3.0-or-later',
            website='https://github.com/riyaniii/Kaori',
        ).present(self.props.active_window)

    def on_preferences_action(self, *args) -> None:
        KaoriPreferences().present(self.props.active_window)

    def on_check_updates_action(self, *args) -> None:
        if self.updater.configured and self.updater.state not in ("checking", "downloading"):
            self.updater.toast("Buscando actualizaciones…")
        self.updater.check(quiet=False)

    def on_appearance_action(self, *args) -> None:
        from .widgets.appearance import AppearanceDialog
        AppearanceDialog().present(self.props.active_window)

    def on_shortcuts_action(self, *args) -> None:
        build_shortcuts().present(self.props.active_window)

    def create_action(self, name, callback, shortcuts=None, parameter_type=None) -> None:
        action = Gio.SimpleAction.new(name, parameter_type)
        action.connect('activate', callback)
        self.add_action(action)
        if shortcuts:
            self.set_accels_for_action(f'app.{name}', shortcuts)


def main(version: str) -> int:
    set_version(version)
    return KaoriApplication(version).run(sys.argv)
