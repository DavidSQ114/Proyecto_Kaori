import asyncio
import re

from gi.repository import Gtk, Pango, GLib, GObject, Gio

from ...integrations import models

from .card import MangaCard

CONTENT_LABELS = {"synopsis", "summary", "description", "plot", "overview", "story"}

LABEL_LINE = re.compile(
    r'^(?:#{1,6}\s*)?'
    r'(?:\*{1,2}|_{1,2})?'
    r'([A-Za-z][A-Za-z \-\'&/]{1,40}?)'
    r'(?:\*{1,2}|_{1,2})?'
    r'\s*:\s*(.*)$'
)
BULLET_LINE = re.compile(r'^\s*(?:[•\-\*]|\d+[\.\)])\s+')
SOURCE_LINE = re.compile(r'^\(.*\)$')
MD_LINK = re.compile(r'\[([^\]]*)\]\([^)]*\)')
MD_EMPHASIS = re.compile(r'(\*{1,3}|_{1,3})(.+?)\1')
MD_HEADER = re.compile(r'^#{1,6}\s*')
MD_INLINE_CODE = re.compile(r'`([^`]*)`')


def strip_markdown_inline(text: str) -> str:
    text = MD_HEADER.sub('', text)
    text = MD_LINK.sub(r'\1', text)
    text = MD_INLINE_CODE.sub(r'\1', text)
    text = MD_EMPHASIS.sub(r'\2', text)
    text = MD_EMPHASIS.sub(r'\2', text)
    return text


def split_paragraphs(text: str) -> list[str]:
    return [p.strip() for p in re.split(r'\n\s*\n+', text.strip()) if p.strip()]


def is_bullet_list(paragraph: str) -> bool:
    lines = paragraph.split('\n')
    bulletish = sum(1 for line in lines if BULLET_LINE.match(line))
    return bulletish > 0 and bulletish >= len(lines) / 2


def strip_bullet(line: str) -> str:
    return BULLET_LINE.sub('', line)


def parse_label(raw_line: str) -> tuple[str | None, str]:
    match = LABEL_LINE.match(raw_line.strip())
    if match:
        return match.group(1).strip().lower(), match.group(2)
    return None, raw_line


def strip_labels(lines: list[str]) -> str:
    cleaned = []
    for line in lines:
        _, rest = parse_label(line)
        rest = strip_markdown_inline(strip_bullet(rest)).strip()
        if rest:
            cleaned.append(rest)
    return '\n'.join(cleaned).strip()

def extract_meat(description: str) -> str:
    paragraphs = split_paragraphs(description)
    labeled = []
    unlabeled = []
    fallback_chunks = []

    for para in paragraphs:
        if SOURCE_LINE.match(para) or is_bullet_list(para):
            continue

        lines = para.split('\n')
        first_label, first_rest = parse_label(lines[0])

        if first_label is None:
            cleaned = strip_labels(lines)
            if cleaned:
                unlabeled.append(cleaned)
            continue

        if first_label in CONTENT_LABELS:
            cleaned = strip_labels([first_rest] + lines[1:])
            if cleaned:
                labeled.append(cleaned)
            continue

        cleaned = strip_labels(lines)
        if cleaned:
            fallback_chunks.append(cleaned)

    if labeled:
        return max(labeled, key=len)
    if unlabeled:
        return max(unlabeled, key=len)
    if fallback_chunks:
        return max(fallback_chunks, key=len)
    return strip_labels(description.strip().split('\n'))


@Gtk.Template(resource_path='/io/github/riyaniii/Kaori/manga/overview.ui')
class MangaOverview(Gtk.Box):
    __gtype_name__ = "KaoriMangaOverview"

    model = GObject.Property(type=models.Manga)

    genres = Gtk.Template.Child()
    description = Gtk.Template.Child()
    right = Gtk.Template.Child()

    def __init__(self, model):
        super().__init__()
        self.model = model
        app = Gio.Application.get_default()
        self.suwayomi = app.suwayomi
        self.history = app.history
        self.populate_genres()
        self.add_resume()

        if self.model.paintable is None and self.model.thumbnail_url:
            asyncio.create_task(self.load_thumbnail())
        asyncio.create_task(self.fill_from_anilist())

    def add_resume(self):
        """Where you left it and a button to go on, in the space under the synopsis."""
        entry = self.history.entries.get(str(self.model.id))
        bottom = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, vexpand=True, valign=Gtk.Align.END,
                         css_classes=["overview-resume"])
        self.facts = Gtk.Label(xalign=0, css_classes=["overview-facts"], visible=False)
        bottom.append(self.facts)
        line = Gtk.Box(spacing=14)
        if entry:
            chapter = entry.get('chapter_name', '')
            short = chapter.replace("Capítulo", "Cap.").replace("Capitulo", "Cap.")
            button = Gtk.Button(css_classes=["pill", "suggested-action"], valign=Gtk.Align.CENTER,
                                child=Gtk.Label(label=f"▶  Continuar · {short}"))
            button.connect("clicked", lambda b, e=entry: self.on_continue(e))
            line.append(button)
            texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, valign=Gtk.Align.CENTER, hexpand=True)
            page, count = entry.get('page', 0), entry.get('page_count', 0)
            where = f"Te quedaste en {chapter} · página {page}" + (f" de {count}" if count else "")
            texts.append(Gtk.Label(label=where, xalign=0, css_classes=["overview-where"]))
            texts.append(Gtk.ProgressBar(fraction=min(page / count, 1.0) if count else 0.0,
                                         css_classes=["overview-progress"], width_request=320,
                                         halign=Gtk.Align.START))
            line.append(texts)
        else:
            button = Gtk.Button(label="Ver la serie", css_classes=["pill"], valign=Gtk.Align.CENTER)
            button.connect("clicked", lambda b: self.on_overview_clicked())
            line.append(button)
        bottom.append(line)
        self.right.append(bottom)

    def on_continue(self, entry):
        from ..pages.gallery import open_capture_page  # opens the reader at a chapter and page
        self.history.mark_seen(entry['manga_id'])
        asyncio.create_task(open_capture_page(self.get_root(), entry))

    async def fill_from_anilist(self):
        """AniList's score and years; and the synopsis (in Spanish) and genres when the source has none."""
        from ...integrations import synopsis
        from .similar import shared_anilist
        app = Gio.Application.get_default()
        try:
            entry = await app.identity.identify(self.model.id, self.model.title, self.model.description or "")
            if not (entry and entry.get("anilist_id")):
                return
            media = await shared_anilist().details(entry["anilist_id"])
        except Exception:
            return
        if not media:
            return
        facts = []
        if score := media.get("averageScore"):
            facts.append(f"★ {score} en AniList")
        if (start := (media.get("startDate") or {}).get("year")):
            end = (media.get("endDate") or {}).get("year")
            facts.append(f"Desde {start}" if not end else f"{start}–{end}")
        if facts:
            self.facts.set_label("  ·  ".join(facts))
            self.facts.set_visible(True)
        if not self.model.genre and media.get("genres") and self.genres.get_first_child() is None:
            for genre in media["genres"][:6]:
                self.genres.append(Gtk.Button(child=Gtk.Label(label=synopsis.GENRES_ES.get(genre, genre),
                                                              ellipsize=Pango.EllipsizeMode.END)))
        if synopsis.lacks_description(self.model.description) and media.get("description"):
            text, _ = await synopsis.shared().spanish(entry["anilist_id"], media["description"])
            if text and synopsis.lacks_description(self.model.description):
                self.description.set_label(self.get_shortened_description(None, text))

    async def load_thumbnail(self):
        from ..containers import covers
        paintable = await covers.load(self.suwayomi, self.model.id, self.model.thumbnail_url, identify=True,
                                      max_width=covers.PAGE_WIDTH)
        if paintable:
            self.model.paintable = paintable

    def populate_genres(self):
        for genre in self.model.genre[:6]:
            button = Gtk.Button(
                child=Gtk.Label(
                    label=genre,
                    ellipsize=Pango.EllipsizeMode.END
                )
            )
            self.genres.append(button)

    @Gtk.Template.Callback()
    def get_shortened_description(self, obj, description):
        if not description:
            return ""

        meat = extract_meat(description)

        l = 600
        if len(meat) <= l:
            return meat
        return meat[:l].rstrip() + "…"

    @Gtk.Template.Callback()
    def on_overview_clicked(self, *_args):
        manga_id = self.model.id
        self.activate_action("app.show_manga", GLib.Variant("i", manga_id))
