"""Cover lifetime shared by every list that shows mangas, and sharper covers when a site's are tiny.

The same Manga model can be on screen in several lists at once (a Home row and the source page
it links to, search results...). A list freeing the cover when its card is recycled would blank
it everywhere else, so covers are only dropped once no card shows that manga anymore.

Some sites only give small, blurry covers. When the series is linked to AniList, its large cover
is used instead. Their addresses are asked to AniList for many series at once and cached forever.
"""
import asyncio
import json
import os

import httpx
from gi.repository import Gio, GLib

_views: dict[int, int] = {}

MIN_WIDTH = 300  # px: a site's cover narrower than this looks blurry on a card
PAGE_WIDTH = 1000  # px for the big cover of a series' page
CARD_WIDTH = 480  # px a card's cover is decoded at (it shows ~200 px; room for a high-DPI screen)
BATCH_DELAY = 0.4  # s to gather the covers asked for together (a whole row or grid)
COVERS_QUERY = """
query ($ids: [Int]) {
  Page(perPage: 50) { media(id_in: $ids, type: MANGA) { id coverImage { extraLarge } } }
}
"""


def retain(item):
    _views[id(item)] = _views.get(id(item), 0) + 1


def release(item):
    count = _views.get(id(item), 0) - 1
    if count > 0:
        _views[id(item)] = count
        return
    _views.pop(id(item), None)
    item.paintable = None


class AniListCovers:
    """AniList id -> its large cover's address, many per request."""

    def __init__(self):
        self.path = os.path.join(GLib.get_user_cache_dir(), "kaori", "hd_covers.json")
        try:
            with open(self.path, encoding="utf-8") as file:
                self.cache = json.load(file)
        except (OSError, ValueError):
            self.cache = {}
        self.waiting: dict[int, list[asyncio.Future]] = {}
        self.flush_task = None
        self.http = None

    async def url(self, anilist_id: int) -> str | None:
        key = str(anilist_id)
        if key in self.cache:
            return self.cache[key] or None
        future = asyncio.get_running_loop().create_future()
        self.waiting.setdefault(anilist_id, []).append(future)
        if self.flush_task is None or self.flush_task.done():
            self.flush_task = asyncio.create_task(self.flush())
        return await future

    async def flush(self):
        await asyncio.sleep(BATCH_DELAY)
        from ...integrations.anilist import throttled_post
        if self.http is None:
            self.http = httpx.AsyncClient(timeout=20, headers={"Accept": "application/json"})
        while self.waiting:
            ids = list(self.waiting)[:50]
            found = {}
            try:
                response = await throttled_post(self.http, {"query": COVERS_QUERY, "variables": {"ids": ids}})
                response.raise_for_status()
                for media in response.json()["data"]["Page"]["media"]:
                    found[media["id"]] = (media.get("coverImage") or {}).get("extraLarge") or ""
                for anilist_id in ids:
                    self.cache[str(anilist_id)] = found.get(anilist_id, "")
                self.save()
            except Exception:
                pass  # not cached: tried again next time
            for anilist_id in ids:
                for future in self.waiting.pop(anilist_id, []):
                    if not future.done():
                        future.set_result(found.get(anilist_id) or None)

    def save(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as file:
            json.dump(self.cache, file)
        os.replace(tmp, self.path)


_anilist_covers = None


async def load(suwayomi, manga_id: int, url: str | None, identify: bool = False, max_width: int | None = None):
    """A series' cover: the site's, or AniList's when the site's is small and the series is linked.
    `identify` also looks up series not linked yet (only for your own ones: it asks AniList)."""
    global _anilist_covers
    paintable = None
    if url:
        try:
            paintable = await suwayomi.getPaintableRetrying(url, max_width=max_width)
        except asyncio.CancelledError:
            raise
        except Exception:
            paintable = None
    if paintable is not None and paintable.get_intrinsic_width() >= MIN_WIDTH:
        return paintable
    app = Gio.Application.get_default()
    identity = getattr(app, "identity", None)
    if identity is None:
        return paintable
    entry = identity.known(manga_id)
    if entry is None and identify:
        model = suwayomi.getModel(manga_id, 'Manga')
        try:
            entry = await identity.identify(manga_id, model.title if model else "",
                                            (model.description if model else "") or "")
        except Exception:
            entry = None
    if not (entry and entry.get("anilist_id")):
        return paintable
    if _anilist_covers is None:
        _anilist_covers = AniListCovers()
    hd_url = await _anilist_covers.url(entry["anilist_id"])
    if not hd_url:
        return paintable
    try:
        sharper = await suwayomi.getPaintable(hd_url, max_width)
    except Exception:
        return paintable
    if sharper is not None and (paintable is None or sharper.get_intrinsic_width() > paintable.get_intrinsic_width()):
        return sharper
    return paintable
