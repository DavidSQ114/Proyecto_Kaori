﻿# Number of this Kaori build. scripts\publicar-actualizacion.ps1 raises it on every update it publishes:
# the updater compares it with the published one (latest.json).
RELEASE = 5
