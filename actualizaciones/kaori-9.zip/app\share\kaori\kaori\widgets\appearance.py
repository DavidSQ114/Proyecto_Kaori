"""Apariencia: pick Kaori's colours and background picture, from ready-made themes or your own,
and see them live."""
import asyncio

from gi.repository import Adw, Gdk, Gio, GLib, Gtk

from .. import theme

SWATCH = 22


def swatch(color: str, size=SWATCH):
    """A small square of colour."""
    area = Gtk.DrawingArea(content_width=size, content_height=size, valign=Gtk.Align.CENTER)
    rgba = Gdk.RGBA()
    rgba.parse(color)

    def draw(area, cr, width, height):
        cr.set_source_rgba(rgba.red, rgba.green, rgba.blue, 1)
        cr.rectangle(0, 0, width, height)
        cr.fill()
    area.set_draw_func(draw)
    return area


class AppearanceDialog(Adw.Dialog):
    __gtype_name__ = "KaoriAppearanceDialog"

    def __init__(self):
        super().__init__(title="Apariencia", content_width=620, content_height=760)
        self.settings = Gio.Application.get_default().settings
        self.updating = False  # setting the colour buttons from code isn't a user choice

        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=22, margin_top=12, margin_bottom=24,
                       margin_start=18, margin_end=18)
        page.append(self.preview())

        # Ready-made themes
        page.append(self.section("Temas", "Un clic y toda la app cambia"))
        presets = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, homogeneous=True, column_spacing=8,
                              row_spacing=8, min_children_per_line=2, max_children_per_line=4)
        self.preset_buttons = []
        for name, primary, secondary in theme.PRESETS:
            button = Gtk.Button(css_classes=["theme-preset"], tooltip_text=f"{name}: {primary} y {secondary}")
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, margin_top=6, margin_bottom=6)
            colors = Gtk.Box(spacing=0, halign=Gtk.Align.CENTER)
            colors.append(swatch(primary, 34))
            colors.append(swatch(secondary, 34))
            box.append(colors)
            box.append(Gtk.Label(label=name, css_classes=["caption-heading"]))
            button.set_child(box)
            button.preset = (primary, secondary)
            button.connect("clicked", lambda b: self.choose(*b.preset, self.background))
            presets.append(button)
            self.preset_buttons.append(button)
        page.append(presets)

        # Background (always dark: all of Kaori's text is light)
        page.append(self.section("Fondo", "Tonos oscuros; la barra lateral y las tarjetas se ajustan solas"))
        backgrounds = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, homogeneous=True, column_spacing=8,
                                  row_spacing=8, min_children_per_line=2, max_children_per_line=4)
        self.background_buttons = []
        for name, color in theme.BACKGROUNDS:
            button = Gtk.Button(css_classes=["theme-preset"], tooltip_text=f"{name}: {color}")
            box = Gtk.Box(spacing=8, margin_top=4, margin_bottom=4, margin_start=4)
            box.append(swatch(color, 28))
            box.append(Gtk.Label(label=name, css_classes=["caption-heading"], xalign=0))
            button.set_child(box)
            button.background = color
            button.connect("clicked", lambda b: self.choose(self.primary, self.secondary, b.background))
            backgrounds.append(button)
            self.background_buttons.append(button)
        page.append(backgrounds)

        page.append(self.image_section())

        # Privacy: adult covers blurred until hovered
        page.append(self.section("Contenido para adultos", "Para leer tranquilo cuando hay gente cerca, o no verlo nunca"))
        privacy = Adw.PreferencesGroup()
        adult_row = Adw.ComboRow(title="Contenido +18",
                                 subtitle="Difuminar: se ve al pasar el ratón. Ocultar: no aparece en el Inicio, "
                                          "Explorar ni Buscar. Kaori lo reconoce por sus géneros, su fuente o por "
                                          "haberlo visto como +18 en otra fuente",
                                 model=Gtk.StringList.new(["Mostrar", "Difuminar", "Ocultar"]))
        adult_row.set_selected(2 if self.settings.get_boolean("hide-adult") else
                               1 if self.settings.get_boolean("discreet-mode") else 0)

        def on_adult(row, *args):
            choice = row.get_selected()
            self.settings.set_boolean("discreet-mode", choice == 1)
            self.settings.set_boolean("hide-adult", choice == 2)
        adult_row.connect("notify::selected", on_adult)
        privacy.add(adult_row)
        page.append(privacy)

        # What the lists leave out: BL / GL, and the series hidden with a right click
        from ..integrations.romance import MODES
        page.append(self.section("Qué mostrar", "En el Inicio, Explorar, Buscar y Para ti (tu Biblioteca siempre se ve entera)"))
        content = Adw.PreferencesGroup()
        romance = Adw.ComboRow(title="Series BL / GL", subtitle="Romance entre chicos (yaoi) o entre chicas (yuri)",
                               model=Gtk.StringList.new([label for _, label in MODES]))
        modes = [name for name, _ in MODES]
        current = self.settings.get_string("romance-filter")
        romance.set_selected(modes.index(current) if current in modes else 0)
        romance.connect("notify::selected", lambda row, *_: self.settings.set_string("romance-filter",
                                                                                     modes[row.get_selected()]))
        content.add(romance)
        content_filter = Gio.Application.get_default().content_filter
        hidden = Adw.ActionRow(title="Series ocultas",
                               subtitle="Clic derecho en una portada > «No mostrar esta serie»")
        show_again = Gtk.Button(label="Mostrar de nuevo", valign=Gtk.Align.CENTER, css_classes=["pill"])

        def update_hidden(*args):
            count = content_filter.hidden_count
            hidden.set_title(f"Series ocultas: {count}")
            show_again.set_sensitive(count > 0)
        show_again.connect("clicked", lambda b: content_filter.unhide_all())
        handler = content_filter.connect("changed", update_hidden)
        self.connect("closed", lambda *_: content_filter.disconnect(handler))
        update_hidden()
        hidden.add_suffix(show_again)
        content.add(hidden)
        page.append(content)

        # Your own colours
        page.append(self.section("Personalizado", "Elige tus colores; los tonos se calculan solos"))
        group = Adw.PreferencesGroup()
        self.primary_button = self.color_row(group, "Color principal",
                                             "Botones, enlaces, selección, barras de progreso")
        self.secondary_button = self.color_row(group, "Color de acento",
                                               "Capítulos nuevos, «Aquí vas», recomendaciones, capturas")
        self.background_button = self.color_row(group, "Color de fondo",
                                                "Si eliges uno claro se oscurece, para que el texto se lea")
        page.append(group)

        reset = Gtk.Button(label="Restablecer Cielo y Sakura", halign=Gtk.Align.CENTER, css_classes=["pill"])
        reset.connect("clicked", lambda b: self.choose(theme.DEFAULT_PRIMARY, theme.DEFAULT_SECONDARY,
                                                      theme.DEFAULT_BACKGROUND))
        page.append(reset)

        view = Adw.ToolbarView(content=Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER, child=page))
        view.add_top_bar(Adw.HeaderBar())
        self.set_child(view)
        self.sync(*theme.current(self.settings))

    def image_section(self):
        """A picture behind everything, dimmed with the background colour so text stays readable."""
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        box.append(self.section("Imagen de fondo", "Detrás de toda la app (el lector mantiene su fondo liso)"))
        line = Gtk.Box(spacing=14)
        self.thumb = Gtk.Picture(content_fit=Gtk.ContentFit.COVER, can_shrink=True, width_request=176,
                                 height_request=99, css_classes=["background-thumb"])
        line.append(Adw.Clamp(maximum_size=176, tightening_threshold=176,
                              child=Adw.Clamp(orientation=Gtk.Orientation.VERTICAL, maximum_size=99,
                                              tightening_threshold=99, child=self.thumb)))
        buttons = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, valign=Gtk.Align.CENTER)
        self.pick_button = Gtk.Button(label="Elegir imagen…", css_classes=["pill", "suggested-action"])
        self.pick_button.connect("clicked", self.on_pick_image)
        buttons.append(self.pick_button)
        self.remove_button = Gtk.Button(label="Quitar imagen", css_classes=["pill"])
        self.remove_button.connect("clicked", lambda b: self.set_image(""))
        buttons.append(self.remove_button)
        line.append(buttons)
        box.append(line)

        group = Adw.PreferencesGroup()
        dim_row = Adw.ActionRow(title="Oscurecer", subtitle="Más alto: el texto se lee mejor")
        self.dim = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 30, 95, 5)
        self.dim.set_size_request(220, -1)
        self.dim.set_value(self.settings.get_int("theme-image-dim"))
        self.dim.connect("value-changed", self.on_dim_changed)
        dim_row.add_suffix(self.dim)
        group.add(dim_row)
        self.blur = Adw.SwitchRow(title="Desenfocar", subtitle="Suaviza la imagen para que no distraiga",
                                  active=self.settings.get_boolean("theme-image-blur"))
        self.blur.connect("notify::active", self.on_blur_changed)
        group.add(self.blur)
        self.image_group = group
        box.append(group)
        self.update_image_controls()
        return box

    def update_image_controls(self):
        image = self.settings.get_string("theme-image")
        has_image = bool(image) and GLib.file_test(image, GLib.FileTest.EXISTS)
        self.remove_button.set_sensitive(has_image)
        self.image_group.set_sensitive(has_image)
        self.thumb.set_filename(image if has_image else None)

    def on_pick_image(self, button):
        dialog = Gtk.FileDialog(title="Elige una imagen de fondo")
        images = Gtk.FileFilter(name="Imágenes")
        images.add_pixbuf_formats()
        filters = Gio.ListStore(item_type=Gtk.FileFilter)
        filters.append(images)
        dialog.set_filters(filters)
        dialog.open(self.get_root(), None, self.on_image_chosen)

    def on_image_chosen(self, dialog, result):
        try:
            file = dialog.open_finish(result)
        except GLib.Error:
            return  # cancelled
        if file and file.get_path():
            asyncio.create_task(self.store_image(file.get_path()))

    async def store_image(self, path):
        self.pick_button.set_sensitive(False)
        self.pick_button.set_label("Preparando…")
        try:
            stored = await asyncio.get_running_loop().run_in_executor(None, theme.store_image, path)
        except Exception as error:
            stored = None
            window = Gio.Application.get_default().get_active_window()
            if window is not None:
                window.toast_overlay.add_toast(Adw.Toast(title=f"No se pudo usar esa imagen: {error}", timeout=4))
        finally:
            self.pick_button.set_sensitive(True)
            self.pick_button.set_label("Elegir imagen…")
        if stored:
            self.set_image(stored)

    def set_image(self, path):
        self.settings.set_string("theme-image", path)
        theme.apply_saved(self.settings)
        self.update_image_controls()

    def on_dim_changed(self, scale):
        self.settings.set_int("theme-image-dim", int(round(scale.get_value())))
        theme.apply_saved(self.settings)

    def on_blur_changed(self, row, *args):
        self.settings.set_boolean("theme-image-blur", row.get_active())
        theme.apply_saved(self.settings)

    def section(self, title, subtitle):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        box.append(Gtk.Label(label=title, xalign=0, css_classes=["title-4"]))
        box.append(Gtk.Label(label=subtitle, xalign=0, css_classes=["dim-label", "caption"]))
        return box

    def color_row(self, group, title, subtitle):
        button = Gtk.ColorDialogButton(dialog=Gtk.ColorDialog(with_alpha=False, title=title),
                                       valign=Gtk.Align.CENTER)
        button.connect("notify::rgba", self.on_color_picked)
        row = Adw.ActionRow(title=title, subtitle=subtitle)
        row.add_suffix(button)
        row.set_activatable_widget(button)
        group.add(row)
        return button

    def preview(self):
        """Real pieces of Kaori, so the colours are seen where they're used."""
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, css_classes=["theme-preview"])
        card.append(Gtk.Label(label="VISTA PREVIA", xalign=0, css_classes=["caption-heading", "preview-title"]))
        line = Gtk.Box(spacing=10)
        line.append(Gtk.Button(label="▶  Continuar · Cap. 12", css_classes=["suggested-action"]))
        line.append(Gtk.Button(label="Capítulos"))
        line.append(Gtk.Label(label="NUEVO", css_classes=["chapter-badge", "new"], valign=Gtk.Align.CENTER))
        line.append(Gtk.Label(label="AQUÍ VAS", css_classes=["chapter-badge", "here"], valign=Gtk.Align.CENTER))
        card.append(line)
        reading = Gtk.ProgressBar(fraction=0.62, css_classes=["series-progress"])
        card.append(Gtk.Label(label="Te quedaste en Capítulo 12 · página 9 de 15", xalign=0, css_classes=["dim-label"]))
        card.append(reading)
        card.append(Gtk.Label(label="Porque lees Solo Leveling y Omniscient Reader", xalign=0,
                              css_classes=["caption", "for-you-reason"]))
        toggles = Adw.ToggleGroup()
        for name, label in (("a", "Todos"), ("b", "Sin leer"), ("c", "Descargados")):
            toggles.add(Adw.Toggle(name=name, label=label))
        toggles.set_active_name("a")
        toggles.set_halign(Gtk.Align.START)
        card.append(toggles)
        return card

    def on_color_picked(self, button, *args):
        if self.updating:
            return
        self.save(self.hex_of(self.primary_button), self.hex_of(self.secondary_button),
                  self.hex_of(self.background_button))

    @staticmethod
    def hex_of(button):
        rgba = button.get_rgba()
        return theme.to_hex((rgba.red, rgba.green, rgba.blue))

    def choose(self, primary, secondary, background):
        self.save(primary, secondary, background)
        self.sync(primary, secondary, background)

    def save(self, primary, secondary, background):
        self.primary, self.secondary, self.background = primary, secondary, background
        self.settings.set_string("theme-primary", primary)
        self.settings.set_string("theme-secondary", secondary)
        self.settings.set_string("theme-background", background)
        theme.apply_saved(self.settings)  # keeps the background picture, if there is one
        self.mark_preset(primary, secondary, background)

    def sync(self, primary, secondary, background):
        """Show the current colours in the pickers without counting it as a new choice."""
        self.primary, self.secondary, self.background = primary, secondary, background
        self.updating = True
        for button, color in ((self.primary_button, primary), (self.secondary_button, secondary),
                              (self.background_button, background)):
            rgba = Gdk.RGBA()
            rgba.parse(color)
            button.set_rgba(rgba)
        self.updating = False
        self.mark_preset(primary, secondary, background)

    def mark_preset(self, primary, secondary, background):
        for button in self.preset_buttons:
            mark(button, tuple(c.upper() for c in button.preset) == (primary.upper(), secondary.upper()))
        for button in self.background_buttons:
            mark(button, button.background.upper() == background.upper())


def mark(button, chosen):
    if chosen:
        button.add_css_class("chosen")
    else:
        button.remove_css_class("chosen")
