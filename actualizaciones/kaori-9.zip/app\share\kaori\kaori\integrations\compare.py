"""Compare the same series across sources: how many chapters each has and how good its images are."""
import asyncio
import difflib
import re
import time
import unicodedata

from gi.repository import Gdk, GLib

MIN_TITLE_SIMILARITY = 0.6
SAMPLE_PAGES = 2


def normalize(title: str) -> str:
    return re.sub(r"[^\w]+", " ", (title or "").casefold()).strip()


def similarity(a: str, b: str) -> float:
    a, b = normalize(a), normalize(b)
    if not a or not b:
        return 0.0
    if a in b or b in a:
        return max(0.8, difflib.SequenceMatcher(None, a, b).ratio())
    return difflib.SequenceMatcher(None, a, b).ratio()


def plain_ratio(a: str, b: str) -> float:
    """Title likeness, ignoring word order: "Seré la matriarca en esta vida" = "En esta vida seré la matriarca"."""
    a, b = normalize(a), normalize(b)
    in_order = difflib.SequenceMatcher(None, a, b).ratio()
    any_order = difflib.SequenceMatcher(None, " ".join(sorted(a.split())), " ".join(sorted(b.split()))).ratio()
    return max(in_order, any_order)


def best_match(query, mangas: list):
    """The result from one source that most looks like what was searched, if any is close enough.

    `query` is a title or every name the series goes by ("The Infinite Mage", "Mago Infinito"…).
    Containing a name is enough to qualify, but among several that do ("Solo Leveling" and
    "Solo Leveling: Ragnarok" for "solo leveli") the closest one overall wins.
    """
    names = [query] if isinstance(query, str) else list(query)

    def closeness(manga):
        return max(plain_ratio(name, manga.title) for name in names)

    candidates = [manga for manga in mangas
                  if any(similarity(name, manga.title) >= MIN_TITLE_SIMILARITY or loose_match(name, manga.title)
                         for name in names)]
    return max(candidates, key=closeness) if candidates else None


def webview_stuck(error) -> bool:
    """The source's hidden browser (KCEF) gave up: the extension keeps failing until the server restarts."""
    return "Timed out waiting for WebView" in str(error)


def friendly_error(error) -> str:
    text = str(error)
    if webview_stuck(error):
        return ("Esta fuente usa un navegador oculto para buscar y se quedó trabado (el sitio pidió una "
                "verificación o tardó demasiado). Reiniciar el servidor lo destraba.")
    if isinstance(error, TimeoutError) or not text.strip():
        return "La fuente tardó demasiado en responder; prueba de nuevo más tarde"
    if "No chapters found" in text:
        return "La fuente no devolvió capítulos para esta serie"
    if "Cloudflare" in text:
        return "El sitio está protegido por Cloudflare y bloqueó la consulta"
    if "timeout" in text.lower() or "timed out" in text.lower():
        return "La fuente tardó demasiado en responder"
    if "404" in text:
        return "La fuente ya no tiene esta serie (error 404)"
    return text[:120]


def image_format(raw: bytes) -> str:
    if raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
        return "WEBP"
    if raw[:3] == b"\xff\xd8\xff":
        return "JPG"
    if raw[:8] == b"\x89PNG\r\n\x1a\n":
        return "PNG"
    if raw[4:12] in (b"ftypavif", b"ftypavis"):
        return "AVIF"
    if raw[:3] == b"GIF":
        return "GIF"
    return "?"


def quality_label(width: int) -> str:
    # Webtoon pages are usually 690-800 px wide; HD scans go well above 1000
    if width >= 1200:
        return "Alta"
    if width >= 760:
        return "Media"
    return "Baja" if width else "?"


async def analyze(suwayomi, manga) -> dict:
    """Fetch the chapter list from the source and sample a couple of pages of its newest chapter."""
    model = await suwayomi.fetchManga(manga.id)
    chapters = list(model.chapters)
    result = {"chapters": len(chapters), "latest": 0.0, "updated": 0.0,
              "width": 0, "height": 0, "kb": 0, "format": "?", "quality": "?"}
    if not chapters:
        return result

    numbers = [chapter.chapter_number for chapter in chapters if chapter.chapter_number > 0]
    result["latest"] = max(numbers) if numbers else 0.0
    dates = [int(chapter.upload_date) for chapter in chapters if (chapter.upload_date or "").isdigit()]
    result["updated"] = max(dates) / 1000 if dates else 0.0

    newest = max(chapters, key=lambda chapter: (chapter.chapter_number, chapter.source_order))
    pages = await suwayomi.getChapterPages(newest.id)
    sample = pages[1:1 + SAMPLE_PAGES] or pages[:SAMPLE_PAGES]  # the first page is often a credits banner
    widths, heights, sizes, formats = [], [], [], []
    for page in sample:
        raw = await suwayomi.loadBytes(page.url)
        texture = await asyncio.get_running_loop().run_in_executor(
            None, lambda data=raw: Gdk.Texture.new_from_bytes(GLib.Bytes.new(data)))
        widths.append(texture.get_width())
        heights.append(texture.get_height())
        sizes.append(len(raw))
        formats.append(image_format(raw))

    if widths:
        result["width"] = round(sum(widths) / len(widths))
        result["height"] = round(sum(heights) / len(heights))
        result["kb"] = round(sum(sizes) / len(sizes) / 1024)
        result["format"] = max(set(formats), key=formats.count)
        result["quality"] = quality_label(result["width"])
    return result


def format_updated(timestamp: float) -> str:
    if not timestamp:
        return "fecha desconocida"
    days = int((time.time() - timestamp) // 86400)
    if days <= 0:
        return "actualizado hoy"
    if days == 1:
        return "actualizado ayer"
    if days < 60:
        return f"actualizado hace {days} días"
    return f"actualizado hace {days // 30} meses"


# --- Accent-tolerant search ---
# Sites match the query literally: "operacion" doesn't find "Operación". When a search comes back
# empty, try the query without accents, then a stem of its longest word (cut before the last vowel,
# where Spanish accents sit: "operacion" -> "operaci"), keeping only titles with every word typed.
VOWELS = "aeiou"
MIN_STEM = 4


def strip_accents(text: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", text) if not unicodedata.combining(c))


def stem(word: str) -> str:
    word = strip_accents(word.casefold())
    for i in range(len(word) - 1, -1, -1):
        if word[i] in VOWELS and i >= MIN_STEM:
            return word[:i]
    return word


def loose_queries(query: str) -> list[tuple[str, bool]]:
    """Alternative queries to try, as (query, needs filtering)."""
    query = (query or "").strip()
    alternatives = []
    plain = strip_accents(query)
    if plain != query:
        alternatives.append((plain, False))
    words = [w for w in re.findall(r"\w+", plain) if len(w) > MIN_STEM]
    if words:
        root = stem(max(words, key=len))
        if root and root != plain.casefold():
            alternatives.append((root, True))
    return alternatives


def loose_match(query: str, title: str) -> bool:
    """Every word typed (stemmed, without accents) appears in the title (without accents). Words of
    one or two letters ("a", "un", "al", "de") are skipped: translations vary them."""
    title_words = re.findall(r"\w+", strip_accents((title or "").casefold()))
    words = [word for word in re.findall(r"\w+", query) if len(word) > 2] or re.findall(r"\w+", query)
    # At the start of a word: "log" is in "Job Log", not in "Antalogia"
    return all(any(t.startswith(stem(word)) for t in title_words) for word in words)
