import asyncio
from gi.repository import Adw, Gio, GLib, GObject, Gtk

from ..extension import ExtensionCard


MINE = "mine"  # the languages chosen with the browse "Languages" button
ANY = "any"


@Gtk.Template(resource_path='/io/github/riyaniii/Kaori/pages/extensions.ui')
class ExtensionsPage(Adw.NavigationPage):
    __gtype_name__ = "KaoriExtensionsPage"

    filter_model = Gtk.Template.Child()
    language_dropdown = Gtk.Template.Child()
    nsfw_button = Gtk.Template.Child()
    count_label = Gtk.Template.Child()

    search_text = GObject.Property(type=str)
    extensions = GObject.Property(type=Gio.ListStore)

    def __init__(self):
        super().__init__()
        app = Gio.Application.get_default()
        self.suwayomi = app.suwayomi
        self.settings = app.settings
        self.extensions = self.suwayomi.extensions
        self.language_codes = []
        self.updating = False

        # Name search (from the template) AND language / adult-content filter
        self.extra_filter = Gtk.CustomFilter.new(self.filter_func)
        every = Gtk.EveryFilter()
        every.append(self.filter_model.get_filter())
        every.append(self.extra_filter)
        self.filter_model.set_filter(every)
        self.filter_model.connect("items-changed", lambda *args: self.update_count())

        self.nsfw_button.set_active(self.settings.get_boolean("extensions-hide-nsfw"))
        self.extensions.connect("items-changed", lambda *args: self.rebuild_languages())
        self.rebuild_languages()
        asyncio.create_task(self.suwayomi.refreshExtensions())

    def rebuild_languages(self):
        """Dropdown entries: my languages, every language, then each language by number of extensions."""
        counts = {}
        for extension in self.extensions:
            counts[extension.lang] = counts.get(extension.lang, 0) + 1
        codes = sorted(counts, key=lambda lang: (-counts[lang], lang))
        if codes == self.language_codes[2:]:
            return
        self.language_codes = [MINE, ANY, *codes]
        labels = ["Mis idiomas", "Todos los idiomas"] + [
            f"{self.suwayomi.languageTitle(code)} ({counts[code]})" for code in codes]

        self.updating = True
        self.language_dropdown.set_model(Gtk.StringList.new(labels))
        saved = self.settings.get_string("extensions-language")
        self.language_dropdown.set_selected(self.language_codes.index(saved) if saved in self.language_codes else 0)
        self.updating = False
        self.extra_filter.changed(Gtk.FilterChange.DIFFERENT)

    @property
    def selected_language(self) -> str:
        index = self.language_dropdown.get_selected()
        return self.language_codes[index] if 0 <= index < len(self.language_codes) else MINE

    def filter_func(self, extension) -> bool:
        if self.nsfw_button.get_active() and extension.is_nsfw:
            return False
        language = self.selected_language
        if language == ANY:
            return True
        if language == MINE:
            return extension.lang in self.suwayomi.languages
        return extension.lang == language

    @Gtk.Template.Callback()
    def on_language_selected(self, dropdown, pspec):
        if self.updating:
            return
        self.settings.set_string("extensions-language", self.selected_language)
        self.extra_filter.changed(Gtk.FilterChange.DIFFERENT)

    @Gtk.Template.Callback()
    def on_nsfw_toggled(self, button):
        self.settings.set_boolean("extensions-hide-nsfw", button.get_active())
        self.extra_filter.changed(Gtk.FilterChange.DIFFERENT)

    def refilter(self):
        """Called when the browse languages change, so "Mis idiomas" follows them."""
        self.extra_filter.changed(Gtk.FilterChange.DIFFERENT)

    def update_count(self):
        shown, total = self.filter_model.get_n_items(), self.extensions.get_n_items()
        self.count_label.set_label(f"{shown} de {total} extensiones")

    async def load_icon(self, item):
        if item.icon_url:
            item.paintable = await self.suwayomi.getPaintable(item.icon_url)

    @Gtk.Template.Callback()
    def on_shown(self, *_):
        asyncio.create_task(self.suwayomi.refreshExtensions())

    @Gtk.Template.Callback()
    def get_page(self, obj, count):
        return "extensions" if count > 0 else "greeter"

    @Gtk.Template.Callback()
    def on_setup(self, factory, list_item):
        list_item.set_activatable(True)
        list_item.set_child(ExtensionCard())

    @Gtk.Template.Callback()
    def on_bind(self, factory, list_item):
        card = list_item.get_child()
        card.model = list_item.get_item()

        card.icon_task = asyncio.create_task(self.load_icon(card.model))

    @Gtk.Template.Callback()
    def on_unbind(self, factory, list_item):
        card = list_item.get_child()
        card.icon_task.cancel()
        card.model.paintable = None
        card.model = None

    @Gtk.Template.Callback()
    def on_header_setup(self, factory, header):
        header.set_child(Gtk.Label(
            xalign=0, css_classes=["heading"],
            margin_top=12, margin_bottom=6, margin_start=12,
        ))

    @Gtk.Template.Callback()
    def on_header_bind(self, factory, header):
        header.get_child().set_label(self.suwayomi.languageTitle(header.get_item().lang))

    @Gtk.Template.Callback()
    def on_activate(self, listview, position):
        item = listview.get_model().get_item(position)
        listview.activate_action("app.show_extension", GLib.Variant("s", item.pkg_name))
