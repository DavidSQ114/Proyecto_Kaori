import asyncio

from gi.repository import Gtk, GObject, Gio, GLib, Adw, Gdk
from ..manga import MangaCard
from . import covers
from ...integrations import models

DRAG_THRESHOLD = 8  # px of movement before a press on a row counts as dragging instead of a click


def show_hide_menu(card):
    """Right click on a cover outside the Biblioteca: leave that series out of the lists."""
    manga = card.model
    content_filter = Gio.Application.get_default().content_filter
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, margin_top=6, margin_bottom=6,
                  margin_start=6, margin_end=6)
    box.append(Gtk.Label(label=manga.title, xalign=0, max_width_chars=28, wrap=True, css_classes=["heading"],
                         margin_bottom=4))
    popover = Gtk.Popover(child=box)
    hide = Gtk.Button(css_classes=["flat"], tooltip_text="En el Inicio, Explorar y Buscar, en todas las fuentes. "
                                                         "Se deshace en Menú > Apariencia")
    hide.set_child(Gtk.Label(label="No mostrar esta serie", xalign=0))
    hide.connect("clicked", lambda b: (popover.popdown(), content_filter.hide(manga)))
    box.append(hide)
    popover.set_parent(card)
    popover.connect("closed", lambda p: GLib.idle_add(lambda: p.unparent() or GLib.SOURCE_REMOVE))
    popover.popup()


@Gtk.Template(resource_path='/io/github/riyaniii/Kaori/containers/row.ui')
class MangaRow(Gtk.Box):
    __gtype_name__ = 'KaoriMangaRow'

    listview = Gtk.Template.Child()
    scrolled = Gtk.Template.Child()
    title_button = Gtk.Template.Child()
    title_arrow = Gtk.Template.Child()

    title = GObject.Property(type=str, default="")

    def __init__(self, title, source_id: str | None = None, **kwargs):
        super().__init__(**kwargs)
        self.title = title
        self.source_id = source_id
        # The title opens the whole source (with infinite scroll and filters) when we know which one it is
        self.title_button.set_can_target(source_id is not None)
        self.title_arrow.set_visible(source_id is not None)

        # Grab-and-drag the row sideways with the left mouse button
        self.drag_origin = 0.0
        self.dragging = False
        drag = Gtk.GestureDrag(button=Gdk.BUTTON_PRIMARY, propagation_phase=Gtk.PropagationPhase.CAPTURE)
        drag.connect("drag-begin", self.on_drag_begin)
        drag.connect("drag-update", self.on_drag_update)
        drag.connect("drag-end", self.on_drag_end)
        self.scrolled.add_controller(drag)

        self.suwayomi = Gio.Application.get_default().suwayomi

        self.store = Gio.ListStore(item_type=models.Manga)
        # Without the series hidden (BL / GL if chosen, and the ones you hid)
        self.content_filter = Gio.Application.get_default().content_filter
        self.filter = Gtk.CustomFilter.new(lambda manga: not self.content_filter.blocked(manga))
        self.filtered = Gtk.FilterListModel(model=self.store, filter=self.filter)
        self.all_items, self.limit = [], None
        self.content_filter.connect("changed", self.on_filter_changed)

        selection = Gtk.NoSelection(model=self.filtered)
        self.listview.set_model(selection)
        self.listview.connect('activate', self.on_activate)

        factory = Gtk.SignalListItemFactory()
        factory.connect('setup', self.on_setup)
        factory.connect('bind', self.on_bind)
        factory.connect('unbind', self.on_unbind)
        self.listview.set_factory(factory)

    def on_setup(self, factory, list_item):
        card = MangaCard()
        # In a horizontal row the width comes from the cover, so without one the card collapses
        card.set_size_request(206, -1)
        card.thumbnail_task = None
        right_click = Gtk.GestureClick(button=3)
        right_click.connect("pressed", lambda gesture, n, x, y, c=card: show_hide_menu(c) if c.model else None)
        card.add_controller(right_click)
        list_item.set_child(card)

    def on_bind(self, factory, list_item):
        item = list_item.get_item()
        card = list_item.get_child()
        card.model = item
        covers.retain(item)

        if item.paintable is None and item.thumbnail_url:
            card.thumbnail_task = asyncio.create_task(self.load_thumbnail(item))

    def on_unbind(self, factory, list_item):
        card = list_item.get_child()
        if card.thumbnail_task:
            card.thumbnail_task.cancel()
            card.thumbnail_task = None

        covers.release(list_item.get_item())

        card.model = None

    async def load_thumbnail(self, item):
        try:
            paintable = await covers.load(self.suwayomi, item.id, item.thumbnail_url, identify=item.in_library)
        except asyncio.CancelledError:
            raise
        except Exception:
            paintable = None
        if paintable:
            item.paintable = paintable
        item.cover_failed = paintable is None

    @Gtk.Template.Callback()
    def on_title_clicked(self, button):
        if self.source_id is not None:
            self.activate_action("app.show_source", GLib.Variant("s", self.source_id))

    def on_drag_begin(self, gesture, x, y):
        if gesture.get_device() and gesture.get_device().get_source() == Gdk.InputSource.TOUCHSCREEN:
            gesture.set_state(Gtk.EventSequenceState.DENIED)  # touch already scrolls natively
            return
        self.drag_origin = self.scrolled.get_hadjustment().get_value()
        self.dragging = False

    def on_drag_update(self, gesture, offset_x, offset_y):
        if not self.dragging:
            if abs(offset_x) < DRAG_THRESHOLD:
                return
            # A real drag, not a click: keep the card from opening on release
            self.dragging = True
            gesture.set_state(Gtk.EventSequenceState.CLAIMED)
            self.set_cursor_from_name("grabbing")
        self.scrolled.get_hadjustment().set_value(self.drag_origin - offset_x)

    def on_drag_end(self, gesture, offset_x, offset_y):
        self.dragging = False
        self.set_cursor(None)

    def on_activate(self, listview, position):
        item = self.filtered.get_item(position)
        listview.activate_action("app.show_manga", GLib.Variant("i", item.id))

    def remove_all(self):
        self.all_items, self.limit = [], None
        self.store.remove_all()

    def set_items(self, items: list, limit: int | None = None):
        """Show `items`; with `limit`, the first that many the content filter lets through (a row
        that loses its BL series fills up with the next ones of the same page)."""
        self.all_items, self.limit = list(items), limit
        self.refill()

    def refill(self):
        items = self.all_items
        if self.limit:
            items = [manga for manga in items if not self.content_filter.blocked(manga)][:self.limit]
        self.store.splice(0, self.store.get_n_items(), items)
        if self.limit:
            self.set_visible(bool(items))  # everything hidden (an adult-only source): no empty row

    def on_filter_changed(self, *args):
        if self.limit:
            self.refill()
        else:
            self.filter.changed(Gtk.FilterChange.DIFFERENT)

