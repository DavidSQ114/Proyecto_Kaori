import asyncio

from gi.repository import Adw, Gio, GLib, Gtk, Pango

from ...integrations import compare

MAX_CONCURRENT = 3
COVER_WIDTH = 64
COVER_HEIGHT = 92
CHAPTER_TOLERANCE = 0.97  # within 3% of the most chapters counts as "complete"
# Below this vs. the most common title a result is flagged as another series: "Solo L3vel1ng" (0.85)
# is the same series under a mangled name, "Solo Leveling: Ragnarok" (0.74) is the sequel.
OTHER_SERIES_SIMILARITY = 0.80


class CompareRow(Gtk.ListBoxRow):
    __gtype_name__ = "KaoriCompareRow"

    def __init__(self, source, manga):
        super().__init__(activatable=True)
        self.source = source
        self.manga = manga
        self.result = None
        self.other_series = False
        self.set_tooltip_text(f"Abrir «{manga.title}» en {source.name}")

        box = Gtk.Box(spacing=14, margin_top=8, margin_bottom=8, margin_start=10, margin_end=10)
        self.cover = Gtk.Picture(content_fit=Gtk.ContentFit.COVER, can_shrink=True,
                                 width_request=COVER_WIDTH, height_request=COVER_HEIGHT, css_classes=["poster"])
        # A Picture asks for its image's natural size; clamp both ways so every cover is the same size
        box.append(Adw.Clamp(maximum_size=COVER_WIDTH, tightening_threshold=COVER_WIDTH, valign=Gtk.Align.CENTER,
                             child=Adw.Clamp(orientation=Gtk.Orientation.VERTICAL, maximum_size=COVER_HEIGHT,
                                             tightening_threshold=COVER_HEIGHT, child=self.cover)))

        info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3, hexpand=True, valign=Gtk.Align.CENTER)
        header = Gtk.Box(spacing=8)
        header.append(Gtk.Label(label=source.name, css_classes=["heading"], xalign=0))
        self.badges = Gtk.Box(spacing=6)
        header.append(self.badges)
        info.append(header)
        info.append(Gtk.Label(label=manga.title, xalign=0, ellipsize=Pango.EllipsizeMode.END, css_classes=["dim-label"]))
        self.chapters_label = Gtk.Label(label="Analizando…", xalign=0)
        info.append(self.chapters_label)
        self.quality_label = Gtk.Label(label="", xalign=0, css_classes=["dim-label", "caption"])
        info.append(self.quality_label)
        box.append(info)

        self.spinner = Adw.Spinner(width_request=24, height_request=24, valign=Gtk.Align.CENTER)
        box.append(self.spinner)
        self.set_child(box)

    async def load_cover(self, suwayomi):
        if self.manga.thumbnail_url:
            try:
                self.cover.set_paintable(await suwayomi.getPaintable(self.manga.thumbnail_url))
            except Exception:
                pass

    def show_result(self, result):
        self.result = result
        self.spinner.set_visible(False)
        latest = f"{result['latest']:g}" if result["latest"] else "?"
        self.chapters_label.set_label(
            f"{result['chapters']} capítulos · último: {latest} · {compare.format_updated(result['updated'])}")
        if result["width"]:
            self.quality_label.set_label(
                f"Calidad {result['quality']} · {result['width']} px de ancho · {result['format']} · "
                f"~{result['kb']} KB por página")
        else:
            self.quality_label.set_label("No se pudo medir la calidad de imagen")

    def show_error(self, error):
        self.spinner.set_visible(False)
        self.chapters_label.set_label("No se pudo analizar esta fuente")
        self.quality_label.set_label(compare.friendly_error(error))

    def add_badge(self, text, warning=False, sakura=False):
        classes = ["compare-badge"] + (["warning-badge"] if warning else []) + (["sakura"] if sakura else [])
        self.badges.append(Gtk.Label(label=text, css_classes=classes))


class ComparePage(Adw.NavigationPage):
    """Same series in every source that has it: chapter count, freshness and image quality side by side."""
    __gtype_name__ = "KaoriComparePage"

    def __init__(self, query: str, results: list, names: list | None = None):
        super().__init__(title=f"Comparar: {query}")
        self.suwayomi = Gio.Application.get_default().suwayomi
        self.query = query
        self.names = list(names or [])  # every name the series goes by, when known
        self.tasks = []

        self.list = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE, css_classes=["boxed-list"])
        self.list.connect("row-activated", self.on_row_activated)
        self.status = Gtk.Label(xalign=0, css_classes=["dim-label"])

        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12,
                          margin_top=12, margin_bottom=24, margin_start=12, margin_end=12)
        content.append(self.status)
        content.append(self.list)
        content.append(Gtk.Label(
            label="La calidad se mide descargando 2 páginas del capítulo más reciente de cada fuente. "
                  "Más ancho = imagen más nítida.",
            xalign=0, wrap=True, css_classes=["dim-label", "caption"]))

        self.stack = Gtk.Stack()
        self.stack.add_named(Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER,
                                                child=Adw.Clamp(maximum_size=1000, child=content)), "list")
        self.stack.add_named(Adw.StatusPage(icon_name="system-search-symbolic", title="Ninguna fuente lo tiene",
                                            description="No hubo resultados parecidos al título buscado."), "empty")
        view = Adw.ToolbarView(content=self.stack)
        view.add_top_bar(Adw.HeaderBar())
        self.set_child(view)

        self.rows = []
        for source, mangas in results:
            if manga := compare.best_match(names or query, mangas):
                row = CompareRow(source, manga)
                self.rows.append(row)
                self.list.append(row)
                self.tasks.append(asyncio.create_task(row.load_cover(self.suwayomi)))
        self.flag_other_series()

        self.stack.set_visible_child_name("list" if self.rows else "empty")
        self.done = 0
        self.update_status()
        if self.rows:
            self.tasks.append(asyncio.create_task(self.analyze_all()))
        self.connect("unrealize", lambda page: [task.cancel() for task in self.tasks])

    def flag_other_series(self):
        """Mark results whose title differs from what most sources call it (sequels, spin-offs...)."""
        titles = [compare.normalize(row.manga.title) for row in self.rows]
        if len(titles) < 3:
            return
        common = max(set(titles), key=titles.count)
        if titles.count(common) < 2:
            return
        for row, title in zip(self.rows, titles):
            # A different language isn't a different series: "Mago Infinito" is one of the names
            if any(compare.plain_ratio(row.manga.title, name) >= OTHER_SERIES_SIMILARITY
                   or compare.loose_match(name, row.manga.title) for name in self.names):
                continue
            if compare.plain_ratio(title, common) < OTHER_SERIES_SIMILARITY:
                row.other_series = True
                row.add_badge("Otra serie", warning=True)
                row.set_tooltip_text(f"Esta fuente devolvió «{row.manga.title}», que podría ser otra serie "
                                     f"(secuela, spin-off…)")

    def update_status(self):
        total = len(self.rows)
        if self.done < total:
            self.status.set_label(f"Analizando {total} fuentes… ({self.done}/{total})")
        else:
            self.status.set_label(f"{total} fuentes tienen «{self.query}» · primero las más completas, "
                                  "y entre ellas la de mejor calidad")

    async def analyze_all(self):
        semaphore = asyncio.Semaphore(MAX_CONCURRENT)

        async def one(row):
            async with semaphore:
                try:
                    row.show_result(await compare.analyze(self.suwayomi, row.manga))
                except asyncio.CancelledError:
                    raise
                except Exception as error:
                    row.show_error(error)
            self.done += 1
            self.update_status()

        await asyncio.gather(*(one(row) for row in self.rows))
        self.rank()

    def rank(self):
        """Best first: most chapters, then sharpest images; and mark the winners."""
        analyzed = [row for row in self.rows if row.result and not row.other_series]
        if not analyzed:
            return
        most = max(row.result["chapters"] for row in analyzed)
        sharpest = max(row.result["width"] for row in analyzed)
        newest = max(row.result["updated"] for row in analyzed)
        for row in analyzed:
            if row.result["chapters"] == most:
                row.add_badge("Más capítulos")
            if sharpest and row.result["width"] == sharpest:
                row.add_badge("Mejor calidad")
            if newest and row.result["updated"] == newest:
                row.add_badge("Más actualizado")

        # A few chapters of difference shouldn't beat twice the resolution: sources within
        # CHAPTER_TOLERANCE of the most complete one count as complete, then sharpness and freshness decide.
        def key(row):
            if not row.result or row.other_series:
                return (False, row.result is not None, 0, 0, 0)
            r = row.result
            return (True, r["chapters"] >= most * CHAPTER_TOLERANCE, r["width"], r["updated"], r["chapters"])

        order = sorted(self.rows, key=key, reverse=True)
        if order and order[0].result and order[0].result["chapters"] and not order[0].other_series:
            order[0].add_badge("Recomendada", sakura=True)
        for row in self.rows:
            self.list.remove(row)
        for row in order:
            self.list.append(row)

    def on_row_activated(self, listbox, row):
        self.activate_action("app.show_manga", GLib.Variant("i", row.manga.id))
