"""Which series are for adults, for the discreet mode (their covers blurred until hovered).

Sites mark it unevenly, so several signs count:
- Adult genres ("+18", "Adulto", "Smut", "Ecchi"…).
- Adult-only sources (Manhwa18, ManhwaClub, WebtoonScan).
- The title: once a series is seen as adult anywhere, the same title is blurred in the sources
  that list it without genres. Remembered in <cache>/kaori/adult_titles.json.
- The source: lists often come without genres. When most series of a source whose genres are known
  are adult (DragonTranslation's popular ones), its series without genres count as adult too.
"""
import json
import os
import re
import unicodedata

from gi.repository import GLib

ADULT_GENRES = re.compile(r"(^|\b)(\+18|18\+|adult[oa]?|mature|madur[oa]|smut|hentai|ecchi|milf|netorare|netori|"
                          r"er[oó]tic[oa]?|fetiche?s?|rape|violaci[oó]n|nsfw|sexual)(\b|$)", re.IGNORECASE)
ADULT_SOURCES = re.compile(r"18|hentai|manhwaclub|webtoonscan", re.IGNORECASE)
MIN_KNOWN = 10  # series with known genres a source needs before its share counts
MOSTLY_ADULT = 0.5  # share of adult series above which a source's unknown ones are blurred

_source_stats: dict[str, list[int]] = {}  # source id -> [adult, with genres]
stats_state = "none"  # none / loading / ready

_titles = None
_path = None


def normalize(title: str) -> str:
    plain = "".join(c for c in unicodedata.normalize("NFD", title or "") if not unicodedata.combining(c))
    return re.sub(r"[^a-z0-9]+", " ", plain.casefold()).strip()


def _load():
    global _titles, _path
    if _titles is None:
        _path = os.path.join(GLib.get_user_cache_dir(), "kaori", "adult_titles.json")
        try:
            with open(_path, encoding="utf-8") as file:
                _titles = set(json.load(file))
        except (OSError, ValueError):
            _titles = set()
    return _titles


def _remember(key: str):
    titles = _load()
    if key and key not in titles:
        titles.add(key)
        try:
            os.makedirs(os.path.dirname(_path), exist_ok=True)
            with open(_path, "w", encoding="utf-8") as file:
                json.dump(sorted(titles), file, ensure_ascii=False)
        except OSError:
            pass


async def load_stats(suwayomi):
    """How adult each source is, from every series the server knows the genres of (one query)."""
    global stats_state
    from .queries import GET_GENRES
    stats_state = "loading"
    try:
        result = await suwayomi.query(GET_GENRES)
    except Exception:
        stats_state = "none"
        return
    _source_stats.clear()
    for node in result["mangas"]["nodes"]:
        if node.get("genre"):
            counts = _source_stats.setdefault(str(node["sourceId"]), [0, 0])
            counts[1] += 1
            counts[0] += any(ADULT_GENRES.search(genre or "") for genre in node["genre"])
    stats_state = "ready"


def mostly_adult(source_id: str) -> bool:
    adult, known = _source_stats.get(str(source_id), (0, 0))
    return known >= MIN_KNOWN and adult / known > MOSTLY_ADULT


def is_adult(title: str, genres, source_name: str = "", source_id: str = "") -> bool:
    key = normalize(title)
    if any(ADULT_GENRES.search(genre or "") for genre in genres or []):
        _remember(key)
        return True
    if source_name and ADULT_SOURCES.search(source_name.replace(" ", "")):
        _remember(key)
        return True
    if bool(key) and key in _load():
        return True
    return not genres and bool(source_id) and mostly_adult(source_id)
