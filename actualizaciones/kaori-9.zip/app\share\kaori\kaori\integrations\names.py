"""Names to look a series up by in the Spanish sources.

AniList knows a series by its English / romaji names, but Spanish scans list it under their own
("I Killed the Main Player" is "Yo maté al jugador de la Academia"). We gather:
- the English names AniList and MangaUpdates know,
- the Spanish names MangaUpdates has (when someone added them),
- the Spanish titles MangaDex lists (the scans' own names, e.g. "Boarding Diary" is "Dueña de la
  Pensión": no translation gets there),
- a machine translation of the English names (MyMemory, free and keyless), cached.
"""
import json
import os
import re

import httpx
from gi.repository import GLib

from .compare import normalize, plain_ratio

TRANSLATE_URL = "https://api.mymemory.translated.net/get"
MANGADEX_URL = "https://api.mangadex.org/manga"
SAME_SERIES = 0.86  # a MangaDex entry is this series if one of its titles is this close to one of ours
MU_SERIES = "https://api.mangaupdates.com/v1/series/{}"
MAX_NAMES = 7
ENGLISH_WORDS = set("the of a an i my to in is and with for who from your me on at be".split())
MAX_TRANSLATIONS = 3
SPANISH_WORDS = set("el la los las de del y en un una mi tu su que con por para al lo es se no".split())
LATIN = re.compile(r"^[\x00-ɏ\s\W\d]+$")  # Latin script only (skips Korean, Japanese, Thai...)


ROMANIZED_ENDINGS = ("eu", "reul", "eul", "neun", "eun", "yeo", "seyo", "hae", "dda", "tda")


def looks_english(title: str) -> bool:
    """Worth translating: Latin script and not romanized Korean ("Ijik Logeu", "Player-reul Jugyeotda")."""
    words = normalize(title).split()
    return bool(words) and not any(w.endswith(ROMANIZED_ENDINGS) for w in words)


def core_phrase(translated: str) -> str | None:
    """"Registro de cambios de trabajo" -> "cambios de trabajo": machine translations of
    "Noun-Noun Log"-style titles put a head noun first that the scans usually drop."""
    words = translated.split()
    if len(words) >= 4 and " de " in translated:
        head, tail = translated.split(" de ", 1)
        # Only a one-word head ("Registro de…"): "Maté a un jugador de la academia" -> "la academia"
        # would match half the catalogue
        if len(head.split()) == 1 and len(tail.split()) >= 2:
            return tail
    return None


def looks_spanish(title: str) -> bool:
    if re.search(r"[áéíóúñ¿¡]", title.casefold()):
        return True
    return len(set(normalize(title).split()) & SPANISH_WORDS) >= 1


class SeriesNames:
    def __init__(self, identity):
        self.identity = identity
        self.http = httpx.AsyncClient(timeout=15, headers={"User-Agent": "Kaori/1.0 (manga reader)"})
        self.path = os.path.join(GLib.get_user_cache_dir(), "kaori", "names.json")
        try:
            with open(self.path, encoding="utf-8") as file:
                self.cache = json.load(file)
        except (OSError, ValueError):
            self.cache = {"translations": {}, "associated": {}}

    async def for_entry(self, entry: dict) -> list[str]:
        """Names to search for an AniList entry (from the ranking, Para ti, recommendations)."""
        main = entry['title']
        english = [t for t in entry.get('search_titles', []) if LATIN.match(t)]
        associated = await self.associated(main)
        # Other alternative names only in plain ASCII: MangaUpdates also lists Turkish,
        # Vietnamese… names in Latin script (ı, ş, ơ), noise to search and garbage to translate
        english += [t for t in associated if t.isascii() and not looks_spanish(t)]
        spanish = await self.mangadex_spanish(main, entry.get('id'), [main, *english])
        spanish += [t for t in associated if LATIN.match(t) and looks_spanish(t)]
        # Translations go after the names people recorded (MangaDex, MangaUpdates), and only of titles
        # of 3+ words: a one- or two-word title translates to something generic ("SET UP" ->
        # "PREPARACIÓN"), while "Job-Change Log" -> "cambios de trabajo" is how the scans find it
        to_translate = [t for t in dict.fromkeys(english)
                        if looks_english(t) and len([w for w in normalize(t).split() if len(w) > 2]) >= 3]
        for title in to_translate[:MAX_TRANSLATIONS]:
            if translated := await self.translate(title):
                spanish.append(translated)
                if core := core_phrase(translated):
                    spanish.append(core)
        ordered = [main, *spanish, *english]
        unique = list(dict.fromkeys(t for t in ordered if t))
        # Drop near-duplicates ("I Killed the Academy Player" / "I Killed an Academy Player")
        kept = []
        for title in unique:
            if all(normalize(title) != normalize(other) for other in kept):
                kept.append(title)
        return kept[:MAX_NAMES]

    async def for_typed(self, text: str) -> list[str]:
        """What the user typed, plus the series' other names when MangaUpdates recognises it as a
        known series ("Ctrl+Alt+Resign" -> "Cambio de trabajo"…). Just [text] otherwise."""
        key = normalize(text)
        if key in self.cache.setdefault("typed", {}):
            return self.cache["typed"][key]
        errors = self.identity.errors
        found = await self.identity.by_mangaupdates(text)
        names = await self.for_entry({"title": text, "search_titles": [text, found["title"]]}) if found else [text]
        if self.identity.errors == errors:  # don't remember an answer a network failure produced
            self.cache["typed"][key] = names
            self.save()
        return names

    async def mangadex_spanish(self, title: str, anilist_id, known: list[str]) -> list[str]:
        """Spanish titles MangaDex has for this series. Its entry must be the same series: the same
        AniList id when we know it, else one of its titles close to one of ours."""
        key = f"{anilist_id or ''}|{normalize(title)}"
        cache = self.cache.setdefault("mangadex", {})
        if key in cache:
            return cache[key]
        try:
            response = await self.http.get(MANGADEX_URL, params={
                "title": title, "limit": 5,
                "contentRating[]": ["safe", "suggestive", "erotica", "pornographic"]})
            response.raise_for_status()
            results = response.json().get("data", [])
        except Exception:
            return []  # not cached: try again next time
        spanish = []
        # Several entries can share a short name: the one AniList links, else a Korean one first
        results.sort(key=lambda m: (str((m.get("attributes") or {}).get("links", {}) and
                                        (m["attributes"]["links"] or {}).get("al") or "") != str(anilist_id or "-"),
                                    (m.get("attributes") or {}).get("originalLanguage") != "ko"))
        for manga in results:
            attributes = manga.get("attributes") or {}
            titles = list((attributes.get("title") or {}).values())
            alternatives = attributes.get("altTitles") or []
            titles += [value for alt in alternatives for value in alt.values()]
            linked = str((attributes.get("links") or {}).get("al") or "")
            same = (anilist_id and str(anilist_id) == linked) or                 any(plain_ratio(ours, theirs) >= SAME_SERIES for ours in known for theirs in titles if theirs)
            if same:
                spanish = [value for alt in alternatives for lang, value in alt.items() if lang in ("es", "es-la")]
                break
        cache[key] = spanish
        self.save()
        return spanish

    async def associated(self, title: str) -> list[str]:
        key = normalize(title)
        if key in self.cache["associated"]:
            return self.cache["associated"][key]
        names = []
        try:
            # The best match only (ties go to the manhwa): mixing the names of every series called
            # "Set Up" would search for all of them
            matches = await self.identity.mangaupdates_matches(title)
            if matches:
                data = await self.identity.request("mu", "GET", MU_SERIES.format(matches[0]["series_id"]))
                names = [a["title"] for a in data.get("associated", []) if a.get("title")]
        except Exception:
            return []  # not cached: try again next time
        self.cache["associated"][key] = names
        self.save()
        return names

    async def translate(self, title: str) -> str | None:
        if title in self.cache["translations"]:
            return self.cache["translations"][title]
        try:
            response = await self.http.get(TRANSLATE_URL, params={"q": title, "langpair": "en|es"})
            data = response.json()
        except Exception:
            return None
        if data.get("responseStatus") != 200:
            return None
        text = (data.get("responseData") or {}).get("translatedText") or ""
        result = text if text and normalize(text) != normalize(title) else None
        self.cache["translations"][title] = result
        self.save()
        return result

    def save(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as file:
            json.dump(self.cache, file, ensure_ascii=False)
        os.replace(tmp, self.path)
