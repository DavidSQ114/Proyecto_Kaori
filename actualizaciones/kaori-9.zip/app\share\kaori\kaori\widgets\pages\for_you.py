"""Para ti: recommendations from everything you read, the authors and artists behind it, and what's
trending among manhwa in Korea. One tab each, with the +18 filter shared by all three."""
import asyncio

from ...integrations.synopsis import GENRES_ES
from gi.repository import Adw, Gio, GLib, Gtk, Pango

from ..manga.backdrop import Backdrop
from ..manga.similar import shared_anilist
from ...integrations import for_you

COVER_WIDTH = 160
COVER_HEIGHT = 230
HERO_COVER_WIDTH = 190
HERO_COVER_HEIGHT = 272
HERO_HEIGHT = 330
MAX_CONCURRENT = 4
RECS_BATCH = 30  # recommendations added each time the end of the tab is reached
CREATORS_BATCH = 5
ADULT_MODES = (("no", "Sin +18"), ("all", "Incluir +18"), ("only", "Solo +18"))
# Tendencias: which country's rising series (AniList's countries)
TREND_COUNTRIES = (
    ("manhwa", "Corea", "En tendencia en Corea", "Los manhwa que más están subiendo en AniList estos días"),
    ("manga", "Japón", "En tendencia en Japón", "Los manga que más están subiendo en AniList estos días"),
    ("manhua", "China", "En tendencia en China", "Los manhua que más están subiendo en AniList estos días"),
    ("all", "Todo", "En tendencia en todo el mundo", "Manga, manhwa y manhua que más están subiendo en AniList"),
)
ROMANCE_MODES = (("all", "BL y GL: todo"), ("no-bl", "Sin BL (yaoi)"), ("none", "Sin BL ni GL"))


def because(titles: list[str]) -> str:
    if not titles:
        return ""
    if len(titles) == 1:
        return f"Porque lees {titles[0]}"
    if len(titles) == 2:
        return f"Porque lees {titles[0]} y {titles[1]}"
    return f"Porque lees {titles[0]}, {titles[1]} y {len(titles) - 2} más"


def fixed_picture(width, height, *classes):
    """A cover of exactly width x height (a Picture alone asks for its image's size)."""
    picture = Gtk.Picture(content_fit=Gtk.ContentFit.COVER, can_shrink=True, css_classes=["poster", *classes],
                          width_request=width, height_request=height)
    frame = Adw.Clamp(maximum_size=width, tightening_threshold=width,
                      child=Adw.Clamp(orientation=Gtk.Orientation.VERTICAL, maximum_size=height,
                                      tightening_threshold=height, child=picture))
    return picture, frame


def card_content(entry: dict, rank: int | None = None):
    """(box, cover picture) of a series card: cover with badges, title, kind / score, reason."""
    reason = entry.get('note') or because(entry.get('reasons', []))
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5, width_request=COVER_WIDTH,
                  halign=Gtk.Align.CENTER, valign=Gtk.Align.START, margin_top=4, margin_bottom=4)
    cover, frame = fixed_picture(COVER_WIDTH, COVER_HEIGHT)
    overlay = Gtk.Overlay(child=frame)
    if rank:
        overlay.add_overlay(Gtk.Label(label=f"#{rank}", halign=Gtk.Align.START, valign=Gtk.Align.START,
                                      css_classes=["trend-rank"]))
    if entry.get('adult'):
        overlay.add_overlay(Gtk.Label(label="+18", halign=Gtk.Align.END, valign=Gtk.Align.START,
                                      css_classes=["compare-badge", "sakura"], margin_top=6, margin_end=6))
    for key, label, tooltip in (("bl", "BL", "Boys' Love (yaoi): romance entre chicos"),
                                ("gl", "GL", "Girls' Love (yuri): romance entre chicas")):
        if entry.get(key):
            overlay.add_overlay(Gtk.Label(label=label, tooltip_text=tooltip, halign=Gtk.Align.END,
                                          valign=Gtk.Align.END, css_classes=["compare-badge", "sakura"],
                                          margin_bottom=6, margin_end=6))
    box.append(overlay)
    box.append(Gtk.Label(label=entry['title'], xalign=0, wrap=True, lines=2, max_width_chars=1,
                         ellipsize=Pango.EllipsizeMode.END, css_classes=["heading"]))
    details = [entry['kind']] + ([f"★ {entry['score']}"] if entry.get('score') else [])
    box.append(Gtk.Label(label="  ·  ".join(details), xalign=0, css_classes=["dim-label", "caption"]))
    if reason:
        box.append(Gtk.Label(label=reason, xalign=0, wrap=True, lines=2, max_width_chars=1,
                             ellipsize=Pango.EllipsizeMode.END, css_classes=["caption", "for-you-reason"]))
    return box, cover, reason


async def load_cover(picture, url, suwayomi, semaphore, backdrop=None):
    if not url:
        return
    async with semaphore:
        try:
            paintable = await suwayomi.getPaintable(url)
        except Exception:
            return
    picture.set_paintable(paintable)
    if backdrop is not None:
        backdrop.set_paintable(paintable)


class ForYouCard(Gtk.FlowBoxChild):
    """A card in a wrapping grid."""
    __gtype_name__ = "KaoriForYouCard"

    def __init__(self, entry: dict, rank: int | None = None):
        super().__init__()
        self.entry = entry
        box, self.cover, reason = card_content(entry, rank)
        self.set_tooltip_text(entry['title'] + (f"\n{reason}" if reason else ""))
        self.set_child(box)

    async def load_cover(self, suwayomi, semaphore):
        await load_cover(self.cover, self.entry.get('cover_url'), suwayomi, semaphore)


class ForYouCardButton(Gtk.Button):
    """A card in a horizontal row (authors' works)."""
    __gtype_name__ = "KaoriForYouCardButton"

    def __init__(self, entry: dict):
        super().__init__(css_classes=["flat", "for-you-card"])
        self.entry = entry
        box, self.cover, reason = card_content(entry)
        self.set_tooltip_text(entry['title'] + (f"\n{reason}" if reason else ""))
        self.set_child(box)

    async def load_cover(self, suwayomi, semaphore):
        await load_cover(self.cover, self.entry.get('cover_url'), suwayomi, semaphore)


def open_details(widget, entry):
    from .ranking_detail import RankingDetailPage
    nav = widget.get_ancestor(Adw.NavigationView)
    if nav is not None:
        nav.push(RankingDetailPage(entry, shared_anilist()))


class ForYouPage(Adw.NavigationPage):
    __gtype_name__ = "KaoriForYouPage"

    def __init__(self):
        super().__init__(title="Para ti", tag="foryou")
        app = Gio.Application.get_default()
        self.app = app
        self.suwayomi = app.suwayomi
        self.history = app.history
        self.settings = app.settings
        self.identified = None  # [(history entry, identity)] from the last analysis
        self.dirty = True
        self.task = None
        self.cover_tasks = []
        self.more = {}  # tab -> what's left to show when its end is reached
        self.loading_more = set()
        self.reading = set()
        self.semaphore = asyncio.Semaphore(MAX_CONCURRENT)

        self.adult = Adw.ToggleGroup(tooltip_text="Series para adultos en las tres pestañas")
        for name, label in ADULT_MODES:
            self.adult.add(Adw.Toggle(name=name, label=label))
        self.adult.set_active_name(self.settings.get_string("foryou-adult"))
        self.adult.connect("notify::active-name", self.on_adult_changed)
        # Not everyone wants yaoi / yuri recommended
        self.romance = Gtk.DropDown.new_from_strings([label for _, label in ROMANCE_MODES])
        self.romance.set_tooltip_text("Series de romance entre chicos (BL, yaoi) o entre chicas (GL, yuri)")
        saved = self.settings.get_string("romance-filter")
        self.romance.set_selected(next((i for i, (name, _) in enumerate(ROMANCE_MODES) if name == saved), 0))
        self.romance.connect("notify::selected", self.on_romance_changed)
        # Also chosen in Apariencia (it hides BL / GL everywhere): follow it
        self.settings.connect("changed::romance-filter", self.on_romance_setting)
        refresh = Gtk.Button(icon_name="view-refresh-symbolic", tooltip_text="Volver a analizar tus lecturas")
        refresh.connect("clicked", lambda button: self.reload(full=True))

        # One tab per kind of discovery
        self.views = Adw.ViewStack()
        self.recs_box = self.add_view("recs", "Para ti", "heart-filled-symbolic")
        self.creators_box = self.add_view("creators", "Autores y artistas", "system-users-symbolic")
        self.trends_box = self.add_view("trends", "Tendencias", "power-profile-performance-symbolic")
        switcher = Adw.ViewSwitcher(stack=self.views, policy=Adw.ViewSwitcherPolicy.WIDE)

        header = Adw.HeaderBar(title_widget=switcher)
        header.pack_start(self.adult)
        header.pack_start(self.romance)
        header.pack_end(refresh)

        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE)
        loading = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16, valign=Gtk.Align.CENTER)
        loading.append(Adw.Spinner(width_request=48, height_request=48, halign=Gtk.Align.CENTER))
        self.progress = Gtk.Label(label="Analizando tus lecturas…", css_classes=["dim-label"])
        loading.append(self.progress)
        self.stack.add_named(loading, "loading")
        self.stack.add_named(Adw.StatusPage(
            icon_name="document-open-recent-symbolic", title="Aún no hay recomendaciones",
            description="Lee algunas series: Kaori las reconoce en AniList y te recomienda otras parecidas. "
                        "Si una serie no se reconoce, ábrela y usa «Vincular serie»."), "empty")
        self.stack.add_named(self.views, "content")

        view = Adw.ToolbarView(content=self.stack)
        view.add_top_bar(header)
        self.set_child(view)

        self.history.connect("changed", lambda *_: setattr(self, "dirty", True))
        self.connect("map", lambda page: self.dirty and self.reload())

    def to_start(self):
        """Clicking Para ti again in the sidebar: back to its first tab (the window scrolls it up)."""
        self.views.set_visible_child_name("recs")

    def add_view(self, name, title, icon):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14,
                      margin_top=16, margin_bottom=30, margin_start=24, margin_end=24)
        scrolled = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER, child=box)
        # Reaching the end loads the next batch (more recommendations, authors, trending pages)
        scrolled.connect("edge-reached", self.on_edge_reached, name)
        self.views.add_titled_with_icon(scrolled, name, title, icon)
        return box

    def on_edge_reached(self, scrolled, position, name):
        if position == Gtk.PositionType.BOTTOM:
            self.load_more(name)

    def load_more(self, name):
        if name in self.loading_more or not self.more.get(name):
            return
        self.loading_more.add(name)
        loaders = {"recs": self.more_recs, "creators": self.more_creators, "trends": self.more_trends}
        task = asyncio.create_task(loaders[name]())
        task.add_done_callback(lambda t: self.loading_more.discard(name))
        self.cover_tasks.append(task)

    def loading_row(self, box):
        row = Gtk.Box(spacing=10, halign=Gtk.Align.CENTER, margin_top=10)
        row.append(Adw.Spinner(width_request=20, height_request=20))
        row.append(Gtk.Label(label="Cargando más…", css_classes=["dim-label"]))
        box.append(row)
        return row

    def on_adult_changed(self, *args):
        self.settings.set_string("foryou-adult", self.adult.get_active_name())
        self.reload()

    @property
    def romance_mode(self) -> str:
        return ROMANCE_MODES[self.romance.get_selected()][0]

    def on_romance_setting(self, *args):
        index = next((i for i, (name, _) in enumerate(ROMANCE_MODES) if name == self.settings.get_string("romance-filter")), 0)
        if index != self.romance.get_selected():
            self.romance.set_selected(index)

    def on_romance_changed(self, *args):
        self.settings.set_string("romance-filter", self.romance_mode)
        self.reload()

    def keep(self, entries):
        return [entry for entry in entries if for_you.romance_ok(entry, self.romance_mode)]

    def keep_group(self, group):
        """An author's panel without the filtered series (None if nothing is left)."""
        if not group:
            return None
        works = self.keep(group['works'])
        return {**group, 'works': works} if works else None

    def reload(self, full=False):
        if full:
            self.identified = None
        self.dirty = False
        if self.task:
            self.task.cancel()
        self.task = asyncio.create_task(self.load())

    def set_progress(self, done, total):
        self.progress.set_label(f"Reconociendo tus series en AniList y MangaUpdates… {done + 1} de {total}")

    async def load(self):
        for task in self.cover_tasks:
            task.cancel()
        self.cover_tasks = []
        mode = self.adult.get_active_name()
        anilist = shared_anilist()
        if self.identified is None or len(self.identified) != len(self.history.items()):
            self.stack.set_visible_child_name("loading")
            self.identified = await for_you.identify_history(self.history.items(), self.app.identity,
                                                             self.suwayomi, self.set_progress)
        if self.stack.get_visible_child_name() == "loading":
            self.progress.set_label("Buscando recomendaciones…")
        recommendations = self.keep(await for_you.recommend(self.identified, anilist, mode))
        reading = {found['anilist_id'] for _, found in self.identified if found and found.get('anilist_id')}
        self.reading = reading
        trending, trends_more = await for_you.trending_korea(anilist, mode, reading, country=self.trend_country)
        trending = self.keep(trending)
        self.more = {"recs": recommendations[1 + RECS_BATCH:], "creators": [],
                     "trends": 2 if trends_more else None}

        for box in (self.recs_box, self.creators_box, self.trends_box):
            while child := box.get_first_child():
                box.remove(child)
        semaphore = self.semaphore
        if recommendations or trending:
            # Show these right away; the authors (many slow AniList lookups) fill their tab after
            self.fill_recommendations(recommendations[:1 + RECS_BATCH], semaphore, trending)
            self.fill_trends(trending, semaphore)
            self.stack.set_visible_child_name("content")
            spinner = self.loading_row(self.creators_box)
        elif self.stack.get_visible_child_name() == "loading":
            self.progress.set_label("Buscando a los autores y artistas de lo que lees…")

        people = await for_you.creator_candidates(self.identified, anilist)
        creators = []
        while people and len(creators) < CREATORS_BATCH:
            if group := self.keep_group(await for_you.creator_group(people.pop(0), self.identified, anilist, mode)):
                creators.append(group)
        self.more["creators"] = people
        if not recommendations and not trending:
            if not creators:
                self.stack.set_visible_child_name("empty")
                return
            self.fill_recommendations([], semaphore)
            self.fill_trends([], semaphore)
            self.stack.set_visible_child_name("content")
        else:
            self.creators_box.remove(spinner)
        self.fill_creators(creators, semaphore)
        self.prefetch_creators()

    def prefetch_creators(self):
        """Look up the next authors in the background, so scrolling down shows them at once."""
        upcoming = list(self.more.get("creators") or [])[:CREATORS_BATCH * 2]

        async def warm():
            for person in upcoming:
                try:
                    await shared_anilist().works_of(person['id'])
                except Exception:
                    pass
        self.cover_tasks.append(asyncio.create_task(warm()))

    # --- Para ti ---

    def fill_recommendations(self, recommendations, semaphore, trending=()):
        box = self.recs_box
        box.append(self.summary())
        if not recommendations:
            known = any(found and found.get('anilist_id') for _, found in self.identified)
            note = ("Sin recomendaciones con este filtro." if known else
                    "Aún no reconocemos ninguna de tus lecturas: sigue leyendo, o abre la serie y usa "
                    "«Vincular serie».")
            if not trending:
                box.append(self.empty_note(note))
                return
            # Never an empty tab (a friend's first days): what's trending meanwhile
            box.append(Gtk.Label(label=note, xalign=0, wrap=True, css_classes=["dim-label"]))
            box.append(self.section_title("Mientras tanto", next(c[2] for c in TREND_COUNTRIES if c[0] == self.trend_country)))
            box.append(self.grid(trending[:RECS_BATCH], semaphore, ranked=True))
            return
        box.append(self.hero(recommendations[0], semaphore))
        box.append(self.section_title("Más para ti", "Lo que más recomiendan los lectores de lo que tú lees"))
        self.recs_grid = self.grid(recommendations[1:], semaphore)
        box.append(self.recs_grid)

    async def more_recs(self):
        batch, self.more["recs"] = self.more["recs"][:RECS_BATCH], self.more["recs"][RECS_BATCH:]
        self.add_to_grid(self.recs_grid, batch, self.semaphore)

    def hero(self, entry, semaphore):
        """The best match, big: blurred cover behind, the reasons, and what to do with it."""
        backdrop = Backdrop(height=HERO_HEIGHT)
        overlay = Gtk.Overlay(child=backdrop, css_classes=["for-you-hero"])
        overlay.add_overlay(Gtk.Box(css_classes=["hero-side-fade"], can_target=False))

        content = Gtk.Box(spacing=24, margin_top=24, margin_bottom=24, margin_start=24, margin_end=24,
                          valign=Gtk.Align.CENTER)
        cover, frame = fixed_picture(HERO_COVER_WIDTH, HERO_COVER_HEIGHT)
        content.append(frame)
        info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, valign=Gtk.Align.CENTER, hexpand=True)
        info.append(Gtk.Label(label="TU MEJOR COINCIDENCIA", xalign=0, css_classes=["caption-heading", "hero-kicker"]))
        info.append(Gtk.Label(label=entry['title'], xalign=0, wrap=True, css_classes=["title-1"]))
        details = [entry['kind']] + ([f"★ {entry['score']}"] if entry.get('score') else []) + \
                  (["+18"] if entry.get('adult') else [])
        info.append(Gtk.Label(label="  ·  ".join(details), xalign=0, css_classes=["title-4"]))
        if entry.get('genres'):
            info.append(Gtk.Label(label=", ".join(GENRES_ES.get(g, g) for g in entry['genres'][:5]), xalign=0,
                                  css_classes=["dim-label"]))
        if reason := because(entry.get('reasons', [])):
            info.append(Gtk.Label(label=reason, xalign=0, wrap=True, css_classes=["for-you-reason"]))
        buttons = Gtk.Box(spacing=10, margin_top=10)
        search = Gtk.Button(label="Buscar en mis fuentes", css_classes=["pill", "suggested-action"])
        search.connect("clicked", lambda b: asyncio.create_task(self.search_entry(b, entry)))
        buttons.append(search)
        details_button = Gtk.Button(label="Ver ficha", css_classes=["pill"])
        details_button.connect("clicked", lambda b: open_details(self, entry))
        buttons.append(details_button)
        info.append(buttons)
        content.append(info)
        overlay.add_overlay(content)
        self.cover_tasks.append(asyncio.create_task(
            load_cover(cover, entry.get('cover_url'), self.suwayomi, semaphore, backdrop)))
        return overlay

    async def search_entry(self, button, entry):
        from .ranking_detail import search_in_sources
        button.set_sensitive(False)
        button.set_label("Preparando nombres…")
        try:
            titles = await self.app.names.for_entry(entry)
        except Exception:
            titles = entry.get('search_titles') or [entry['title']]
        finally:
            button.set_sensitive(True)
            button.set_label("Buscar en mis fuentes")
        search_in_sources(self.get_root(), titles, entry['title'])

    def summary(self):
        known = [entry for entry, found in self.identified if found and found.get('anilist_id')]
        unknown = [entry for entry, found in self.identified if not (found and found.get('anilist_id'))]
        box = Gtk.Box(spacing=10)
        box.append(Gtk.Label(label=f"Según {len(known)} de tus {len(self.identified)} lecturas", xalign=0,
                             css_classes=["dim-label"]))
        if unknown:
            button = Gtk.MenuButton(label=f"{len(unknown)} sin reconocer", css_classes=["flat"],
                                    tooltip_text="Ábrelas y usa «Vincular serie» para que cuenten")
            menu = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, margin_top=6, margin_bottom=6)
            menu.append(Gtk.Label(label="Ábrela y pulsa «Vincular serie»:", xalign=0, margin_start=8,
                                  margin_bottom=4, css_classes=["dim-label", "caption"]))
            popover = Gtk.Popover(child=menu)
            for entry in unknown:
                item = Gtk.Button(label=entry['title'], css_classes=["flat"])
                item.get_child().set_xalign(0)
                item.connect("clicked", lambda b, mid=entry['manga_id']: (
                    popover.popdown(), b.activate_action("app.show_manga", GLib.Variant("i", mid))))
                menu.append(item)
            button.set_popover(popover)
            box.append(button)
        return box

    # --- Autores y artistas ---

    def fill_creators(self, groups, semaphore):
        box = self.creators_box
        if not groups:
            box.append(self.empty_note("Aún no conocemos a los autores de lo que lees (vincula tus series en AniList)."))
            return
        box.append(Gtk.Label(label="Otras obras de quienes escribieron o dibujaron tus series. Pulsa un nombre "
                                   "para ver todas sus obras.", xalign=0, wrap=True, css_classes=["dim-label"]))
        for group in groups:
            box.append(self.creator_panel(group, semaphore))

    async def more_creators(self):
        """The next people, skipping those with nothing new of theirs to show."""
        box = self.creators_box
        spinner = self.loading_row(box)
        added = 0
        try:
            while self.more["creators"] and added < CREATORS_BATCH:
                person = self.more["creators"].pop(0)
                group = self.keep_group(await for_you.creator_group(person, self.identified, shared_anilist(),
                                                                    self.adult.get_active_name()))
                if group:
                    box.insert_child_after(self.creator_panel(group, self.semaphore), spinner.get_prev_sibling())
                    added += 1
        finally:
            box.remove(spinner)
        self.prefetch_creators()

    def creator_panel(self, group, semaphore):
        panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, css_classes=["creator-panel"])
        line = Gtk.Box(spacing=10)
        initial = Gtk.Label(label=(group['name'] or "?")[:1].upper(), css_classes=["creator-initial"],
                            valign=Gtk.Align.CENTER)
        line.append(initial)
        texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, valign=Gtk.Align.CENTER)
        name = Gtk.Button(label=group['name'], css_classes=["flat", "series-link"], halign=Gtk.Align.START,
                          tooltip_text="Ver todas sus obras")
        name.get_child().add_css_class("title-4")
        name.connect("clicked", lambda b, g=group: self.open_creator(g['id'], g['name']))
        texts.append(name)
        texts.append(Gtk.Label(label=f"{group['role']}  ·  {because(group['because'])}", xalign=0,
                               ellipsize=Pango.EllipsizeMode.END, css_classes=["caption", "for-you-reason"]))
        line.append(texts)
        panel.append(line)

        row = Gtk.Box(spacing=6)
        for entry in group['works']:
            card = ForYouCardButton({**entry, 'reasons': []})
            card.connect("clicked", lambda b: open_details(self, b.entry))
            row.append(card)
            self.cover_tasks.append(asyncio.create_task(card.load_cover(self.suwayomi, semaphore)))
        panel.append(Gtk.ScrolledWindow(vscrollbar_policy=Gtk.PolicyType.NEVER, propagate_natural_height=True,
                                        child=row))
        return panel

    def open_creator(self, staff_id, name):
        nav = self.get_ancestor(Adw.NavigationView)
        if nav is not None:
            nav.push(CreatorPage(staff_id, name, self.adult.get_active_name(), self.romance_mode))

    # --- Tendencias ---

    @property
    def trend_country(self) -> str:
        country = self.settings.get_string("trends-country")
        return country if country in [c for c, *_ in TREND_COUNTRIES] else "manhwa"

    def trends_header(self):
        """Corea · Japón · China · Todo, then the title of what is shown."""
        header = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        countries = Adw.ToggleGroup(halign=Gtk.Align.START, tooltip_text="De dónde son las series en tendencia")
        for country, label, _, _ in TREND_COUNTRIES:
            countries.add(Adw.Toggle(name=country, label=label))
        countries.set_active_name(self.trend_country)
        countries.connect("notify::active-name", self.on_trend_country_changed)
        header.append(countries)
        _, _, title, subtitle = next(c for c in TREND_COUNTRIES if c[0] == self.trend_country)
        header.append(self.section_title(title, subtitle))
        return header

    def on_trend_country_changed(self, toggles, *args):
        country = toggles.get_active_name()
        if not country or country == self.trend_country:
            return
        self.settings.set_string("trends-country", country)
        task = asyncio.create_task(self.reload_trends())
        self.cover_tasks.append(task)

    async def reload_trends(self):
        """Only this tab, for another country."""
        box = self.trends_box
        while child := box.get_first_child():
            box.remove(child)
        spinner = self.loading_row(box)
        trending, has_next = await for_you.trending_korea(shared_anilist(), self.adult.get_active_name(),
                                                         self.reading, country=self.trend_country)
        box.remove(spinner)
        self.more["trends"] = 2 if has_next else None
        self.fill_trends(self.keep(trending), self.semaphore)

    def fill_trends(self, trending, semaphore):
        box = self.trends_box
        box.append(self.trends_header())
        if not trending:
            box.append(self.empty_note("No se pudieron cargar las tendencias."))
            return
        self.trends_grid = self.grid(trending, semaphore, ranked=True)
        box.append(self.trends_grid)

    async def more_trends(self):
        page = self.more["trends"]
        spinner = self.loading_row(self.trends_box)
        try:
            entries, has_next = await for_you.trending_korea(shared_anilist(), self.adult.get_active_name(),
                                                             self.reading, page, country=self.trend_country)
        finally:
            self.trends_box.remove(spinner)
        self.more["trends"] = page + 1 if has_next else None
        self.add_to_grid(self.trends_grid, self.keep(entries), self.semaphore, ranked=True)

    # --- shared ---

    def section_title(self, title, subtitle):
        header = Gtk.Box(spacing=10, margin_top=6)
        header.append(Gtk.Label(label=title, css_classes=["title-3"], xalign=0))
        header.append(Gtk.Label(label=subtitle, css_classes=["dim-label", "caption"], valign=Gtk.Align.BASELINE_CENTER))
        return header

    def empty_note(self, text):
        return Gtk.Label(label=text, css_classes=["dim-label"], margin_top=40, wrap=True)

    def grid(self, entries, semaphore, ranked=False):
        grid = Gtk.FlowBox(homogeneous=True, min_children_per_line=2, max_children_per_line=12,
                           column_spacing=10, row_spacing=14, selection_mode=Gtk.SelectionMode.NONE,
                           activate_on_single_click=True, valign=Gtk.Align.START)
        grid.connect("child-activated", lambda flowbox, card: open_details(self, card.entry))
        grid.count = 0
        self.add_to_grid(grid, entries, semaphore, ranked)
        return grid

    def add_to_grid(self, grid, entries, semaphore, ranked=False):
        for entry in entries:
            grid.count += 1
            card = ForYouCard(entry, rank=grid.count if ranked else None)
            grid.append(card)
            self.cover_tasks.append(asyncio.create_task(card.load_cover(self.suwayomi, semaphore)))


class CreatorPage(Adw.NavigationPage):
    """Everything an author or artist made (AniList), to find more from someone you like."""
    __gtype_name__ = "KaoriCreatorPage"

    def __init__(self, staff_id: int, name: str, adult_mode: str = "no", romance_mode: str = "all"):
        super().__init__(title=name)
        self.suwayomi = Gio.Application.get_default().suwayomi
        self.staff_id = staff_id
        self.adult_mode = adult_mode
        self.romance_mode = romance_mode
        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE)
        self.stack.add_named(Adw.Spinner(width_request=48, height_request=48, halign=Gtk.Align.CENTER,
                                         valign=Gtk.Align.CENTER), "loading")
        self.stack.add_named(Adw.StatusPage(icon_name="network-error-symbolic",
                                            title="No se pudieron cargar sus obras"), "error")
        self.content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin_top=12,
                               margin_bottom=30, margin_start=24, margin_end=24)
        self.stack.add_named(Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER, child=self.content),
                             "content")
        view = Adw.ToolbarView(content=self.stack)
        view.add_top_bar(Adw.HeaderBar())
        self.set_child(view)
        self.tasks = []
        asyncio.create_task(self.load())

    async def load(self):
        try:
            name, works = await shared_anilist().works_of(self.staff_id, include_adult=self.adult_mode != "no")
        except Exception:
            self.stack.set_visible_child_name("error")
            return
        works = [w for w in works if (for_you.adult_ok(w, self.adult_mode) or self.adult_mode == "all")
                 and for_you.romance_ok(w, self.romance_mode)]
        self.content.append(Gtk.Label(label=name, css_classes=["title-1"], xalign=0))
        self.content.append(Gtk.Label(label=f"{len(works)} obras en AniList · de la más popular a la menos",
                                      css_classes=["dim-label"], xalign=0))
        grid = Gtk.FlowBox(homogeneous=True, min_children_per_line=2, max_children_per_line=12,
                           column_spacing=10, row_spacing=14, selection_mode=Gtk.SelectionMode.NONE,
                           activate_on_single_click=True, valign=Gtk.Align.START)
        grid.connect("child-activated", self.on_card_activated)
        semaphore = asyncio.Semaphore(MAX_CONCURRENT)
        for entry in works:
            card = ForYouCard({**entry, 'reasons': [], 'note': entry['role']})
            grid.append(card)
            self.tasks.append(asyncio.create_task(card.load_cover(self.suwayomi, semaphore)))
        self.content.append(grid)
        self.stack.set_visible_child_name("content")

    def on_card_activated(self, flowbox, card):
        from .ranking_detail import RankingDetailPage
        self.get_ancestor(Adw.NavigationView).push(RankingDetailPage(card.entry, shared_anilist()))
