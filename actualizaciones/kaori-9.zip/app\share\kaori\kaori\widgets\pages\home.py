import asyncio
import time
from gi.repository import Adw, Gio, GLib, GObject, Gtk

from ..manga import MangaOverview
from ..containers import MangaRow

from ...integrations.suwayomi import LOCAL_SOURCE_ID, SourceMangaType, watch

ROW_SIZE = 12
RECENT_BONUS = 1800  # seconds: a source read this week counts as if read 30 more minutes
MAX_CONCURRENT = 3
CAROUSEL_SIZE = 6
CAROUSEL_INTERVAL = 6  # seconds between automatic slides


@Gtk.Template(resource_path='/io/github/riyaniii/Kaori/pages/home.ui')
class HomePage(Adw.NavigationPage):
    __gtype_name__ = "KaoriHomePage"

    manga_carousel = Gtk.Template.Child()
    carousel_stack = Gtk.Template.Child()
    main_box = Gtk.Template.Child()
    row_mode = Gtk.Template.Child()

    state = GObject.Property(type=str, default="home")

    def __init__(self):
        super().__init__()
        self.suwayomi = Gio.Application.get_default().suwayomi
        self.rows = []
        self.rows_task = None

        watch(self, self.suwayomi.library, self.on_library_changed)
        watch(self, self.suwayomi.sources, self.reload_rows)

        self.sync_carousel()
        asyncio.create_task(self.load())

        # Auto-advance the featured carousel; hovering it pauses, so it never moves under the pointer
        self.carousel_hovered = False
        hover = Gtk.EventControllerMotion()
        hover.connect("enter", lambda *args: setattr(self, "carousel_hovered", True))
        hover.connect("leave", lambda *args: setattr(self, "carousel_hovered", False))
        self.manga_carousel.add_controller(hover)
        GLib.timeout_add_seconds(CAROUSEL_INTERVAL, self.on_carousel_tick)

    def on_carousel_tick(self):
        if self.get_mapped() and not self.carousel_hovered:
            self.step_carousel(1)
        return GLib.SOURCE_CONTINUE

    def step_carousel(self, direction: int):
        pages = self.manga_carousel.get_n_pages()
        if pages < 2:
            return
        index = (round(self.manga_carousel.get_position()) + direction) % pages
        self.manga_carousel.scroll_to(self.manga_carousel.get_nth_page(index), True)

    @Gtk.Template.Callback()
    def on_carousel_previous(self, button):
        self.step_carousel(-1)

    @Gtk.Template.Callback()
    def on_carousel_next(self, button):
        self.step_carousel(1)

    async def load(self):
        await asyncio.gather(self.suwayomi.refreshLibrary(), self.suwayomi.refreshSources())
        self.reload_rows()

    def update_state(self):
        self.state = "home" if self.rows or self.suwayomi.library.get_n_items() else "greeter"

    def on_library_changed(self):
        self.sync_carousel()
        self.update_state()

    def sync_carousel(self):
        while self.manga_carousel.get_n_pages():
            self.manga_carousel.remove(self.manga_carousel.get_nth_page(0))
        for manga in list(self.suwayomi.library)[:CAROUSEL_SIZE]:
            self.manga_carousel.append(MangaOverview(manga))
        self.carousel_stack.set_visible_child_name(
            "carousel" if self.manga_carousel.get_n_pages() else "empty"
        )

    async def source_usage(self) -> dict[str, float]:
        """Reading time per source from Tus Lecturas, plus a bonus for sources used in the last week."""
        history = Gio.Application.get_default().history.items()
        try:
            sources = await self.suwayomi.getMangaSourceIds([entry['manga_id'] for entry in history])
        except Exception:
            return {}
        usage = {}
        recent = set()
        week_ago = time.time() - 7 * 86400
        for entry in history:
            source_id = sources.get(entry['manga_id'])
            if source_id is None:
                continue
            usage[source_id] = usage.get(source_id, 0) + entry.get('seconds', 0)
            if entry.get('last_read', 0) > week_ago:
                recent.add(source_id)
        for source_id in recent:
            usage[source_id] += RECENT_BONUS
        return usage

    async def pick_sources(self) -> list:
        """One source per installed extension (in the browse languages): the ones you read most first,
        then the Spanish ones, then the rest, alphabetically. (Not by the +18 flag: almost every Spanish
        source has it; the English/Korean ones are the adult-only sites a fresh copy shouldn't open on.)"""
        by_extension = {}
        for source in self.suwayomi.sources:
            if source.id != LOCAL_SOURCE_ID:
                by_extension.setdefault(source.extension_pkg_name, source)
        usage = await self.source_usage()
        return sorted(by_extension.values(), key=lambda source: (-usage.get(source.id, 0), not source.lang.startswith('es'),
                                                                 source.name.casefold()))

    @Gtk.Template.Callback()
    def on_row_mode_changed(self, *args):
        self.reload_rows()

    def reload_rows(self):
        if self.rows_task:
            self.rows_task.cancel()
        self.rows_task = asyncio.create_task(self.load_rows())

    async def load_rows(self):
        for row in self.rows:
            self.main_box.remove(row)
        self.rows = []
        latest = self.row_mode.get_active_name() == "latest"
        fetch_type = SourceMangaType.LATEST if latest else SourceMangaType.POPULAR
        semaphore = asyncio.Semaphore(MAX_CONCURRENT)

        # Rows go in usage order right away (hidden) and show up as each source answers
        sources = await self.pick_sources()
        rows = []
        for source in sources:
            row = MangaRow(source.name, source.id)
            row.set_visible(False)
            self.main_box.append(row)
            rows.append(row)
        self.rows = rows

        async def fill(source, row):
            async with semaphore:
                mangas = await self.suwayomi.getSourceManga(source.id, fetch_type=fetch_type)
            if mangas:
                row.set_items(mangas, limit=ROW_SIZE)  # also hides it if everything is filtered out

        await asyncio.gather(*(fill(source, row) for source, row in zip(sources, rows)), return_exceptions=True)
        self.update_state()
