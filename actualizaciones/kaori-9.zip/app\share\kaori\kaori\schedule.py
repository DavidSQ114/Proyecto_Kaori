"""When each series comes out: learned from its own chapter dates, for the Calendario.

No service lists the weekday each Spanish scan publishes on, so Kaori works it out:

- The release dates are the chapters' upload dates when the source really gives them. Sources
  without dates get stamped with the moment the server fetched the list: those chapters count by
  when Kaori first saw them (`fetchedAt`), except the ones that were already there on the very
  first fetch, whose date is unknown.
- Chapters on the same day are one release (scans often upload a batch).
- The weekday is the one most recent releases fell on, the newest weighing more, so a scan that
  moves from Tuesday to Thursday is followed after a couple of chapters; a neighbouring day that
  also happens often is kept as "a veces" (a scan running a day late).
- Then the state today: on time, late, paused (it missed several releases), finished, or no
  fixed day (it publishes, but with no pattern).
"""
import statistics
from datetime import date, datetime, timedelta, timezone

FETCH_TOLERANCE = 5  # s between the fetch and a date stamped on by the server (no real date)
FIRST_FETCH_WINDOW = 3600  # s: chapters fetched this close to the first fetch were already there
RECENT_RELEASES = 8  # releases the pattern is learned from
MAX_AGE_DAYS = 240  # older releases say nothing about today's schedule
RECENCY = 0.75  # weight of each release relative to the next newer one
MIN_RELEASES = 3
SECOND_DAY_SHARE = 0.25  # a neighbouring day this frequent is "a veces"
MIN_DAY_SHARE = 0.5  # below this (main day + its neighbour) the series has no fixed day
USUAL_DAY_SHARE = 0.75  # an irregular series this often on one day still "suele salir" that day
LATE_AFTER = 1  # days past the expected one that still count as on time
PAUSE_MISSED = 3  # missed releases in a row before it counts as paused
MIN_PAUSE_DAYS = 21

DAY_NAMES = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
FINISHED = {"COMPLETED": "Finalizada", "PUBLISHING_FINISHED": "Finalizada", "CANCELLED": "Cancelada"}
CADENCES = [  # (name, min days, max days) between releases
    ("semanal", 5, 9),
    ("quincenal", 12, 16),
    ("mensual", 26, 35),
]


def site_date(upload_ms: int) -> date:
    """The day the source says. Many give only a date, which arrives as midnight UTC (shown here,
    in America, as 19:00 the day before) or midnight local: keep that date as is."""
    utc = datetime.fromtimestamp(upload_ms / 1000, timezone.utc)
    if (utc.hour, utc.minute, utc.second) == (0, 0, 0):
        return utc.date()
    return datetime.fromtimestamp(upload_ms / 1000).date()


def release_dates(chapters: list[dict]) -> list[tuple[date, list[float]]]:
    """[(day, chapter numbers)] oldest first. Each chapter: {number, upload_date (ms str), fetched_at (s str)}."""
    fetched = [int(c["fetched_at"]) for c in chapters if str(c.get("fetched_at") or "").isdigit()]
    first_fetch = min(fetched) if fetched else 0
    days: dict[date, list[float]] = {}
    for chapter in chapters:
        upload = str(chapter.get("upload_date") or "")
        seen = str(chapter.get("fetched_at") or "")
        when = None
        if upload.isdigit() and int(upload) > 0 and not (
                seen.isdigit() and abs(int(upload) / 1000 - int(seen)) < FETCH_TOLERANCE):
            when = site_date(int(upload))  # the date the source published
        elif seen.isdigit() and int(seen) > first_fetch + FIRST_FETCH_WINDOW:
            when = datetime.fromtimestamp(int(seen)).date()  # no date: when Kaori first saw it
        if when is not None:
            days.setdefault(when, []).append(chapter.get("number", 0))
    return sorted(days.items())


def cadence_of(interval: float) -> str | None:
    for name, low, high in CADENCES:
        if low <= interval <= high:
            return name
    return None


def analyze(chapters: list[dict], status: str = "", today: date | None = None) -> dict:
    """The schedule of one series: {state, label, cadence, day, also, next, late_days, since_days,
    interval, last, releases, confidence}. state: a_tiempo / retrasada / en_pausa / sin_dia_fijo /
    finalizada / sin_datos."""
    today = today or date.today()
    all_releases = release_dates(chapters)
    releases = [(day, numbers) for day, numbers in all_releases if (today - day).days <= MAX_AGE_DAYS]
    releases = releases[-RECENT_RELEASES:]
    last = all_releases[-1][0] if all_releases else None
    result = {"state": "sin_datos", "label": "Sin datos suficientes", "cadence": None, "day": None,
              "also": None, "next": None, "late_days": 0, "since_days": (today - last).days if last else None,
              "interval": None, "last": last, "releases": len(releases), "confidence": 0.0}

    if status in FINISHED:
        result.update(state="finalizada", label=FINISHED[status])
        return result
    if len(releases) < MIN_RELEASES:
        if last is not None and (today - last).days > 60:
            result.update(state="en_pausa", label=f"Sin capítulos desde hace {(today - last).days} días")
        return result

    days = [day for day, _ in releases]
    intervals = [(b - a).days for a, b in zip(days, days[1:])]
    interval = statistics.median(intervals)
    steady = sum(abs(gap - interval) <= 2 for gap in intervals) / len(intervals)
    cadence = cadence_of(interval) if steady >= 0.5 else None
    result.update(interval=interval, cadence=cadence)

    # Which weekday: the newest releases weigh more
    weights = [0.0] * 7
    for age, day in enumerate(reversed(days)):
        weights[day.weekday()] += RECENCY ** age
    total = sum(weights)
    main = max(range(7), key=lambda d: weights[d])
    neighbours = [(main - 1) % 7, (main + 1) % 7]
    also = max(neighbours, key=lambda d: weights[d])
    if weights[also] / total < SECOND_DAY_SHARE:
        also = None
    confidence = (weights[main] + (weights[also] if also is not None else 0)) / total
    result["confidence"] = round(confidence, 2)

    since = (today - days[-1]).days
    pause_after = max(PAUSE_MISSED * interval, MIN_PAUSE_DAYS)
    if since >= pause_after:
        result.update(state="en_pausa", label=f"En pausa · sin capítulos desde hace {since} días")
        return result

    if cadence and confidence >= MIN_DAY_SHARE:
        # Next time it falls on its day, about one interval after the last release
        expected = days[-1] + timedelta(days=max(1, round(interval) - 2))
        while expected.weekday() != main:
            expected += timedelta(days=1)
        day_label = DAY_NAMES[main].capitalize() + (f" (a veces {DAY_NAMES[also]})" if also is not None else "")
        result.update(day=main, also=also, next=expected)
        slack = LATE_AFTER + (1 if also == (main + 1) % 7 else 0)  # it often runs a day late
        late = (today - expected).days
        if late > slack:
            result.update(state="retrasada", late_days=late,
                          label=f"{day_label}, {cadence} · retrasada {late} días")
        else:
            result.update(state="a_tiempo", label=f"{day_label}, {cadence}")
        return result

    # It publishes, but not regularly or not on a fixed day: only an estimate of the next one
    expected = days[-1] + timedelta(days=round(interval))
    every = f"cada ~{round(interval)} días" if interval >= 1 else "varias veces por semana"
    if confidence >= USUAL_DAY_SHARE:
        # Irregular, but always on the same day when it does come out ("Secret Class": Tuesdays)
        while expected.weekday() != main:
            expected += timedelta(days=1)
        result.update(state="sin_dia_fijo", next=expected, day=main,
                      label=f"Suele salir {DAY_NAMES[main]} · {every}, irregular")
    else:
        result.update(state="sin_dia_fijo", next=expected, label=f"Sin día fijo · {every}")
    return result
