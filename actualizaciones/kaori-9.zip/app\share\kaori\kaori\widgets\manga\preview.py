import asyncio

from gi.repository import Adw, Gdk, GLib, Gtk

PREVIEW_PAGES = 10
TILE_WIDTH = 170  # each page is a fixed tile in a horizontal strip, cropped to fill it
TILE_HEIGHT = 250
MIN_PAGE_WIDTH = 300  # smaller images are usually credit stamps, not art
MAX_CONCURRENT = 2
DRAG_THRESHOLD = 8  # px the pointer must move before a press counts as dragging, not a click


class ChapterPreview(Gtk.Box):
    """A peek at the first chapter's art: its first pages as a strip of tiles that scrolls sideways."""
    __gtype_name__ = "KaoriChapterPreview"

    def __init__(self, suwayomi, on_open, expanded: bool):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.suwayomi = suwayomi
        self.on_open = on_open  # on_open(chapter, page_index)
        self.chapter = None
        self.loaded = False
        self.tasks = []

        header = Gtk.Box(spacing=10)
        self.title = Gtk.Label(label="VISTA PREVIA", xalign=0, hexpand=True, css_classes=["caption-heading", "preview-title"])
        header.append(self.title)
        self.toggle = Gtk.Button(css_classes=["flat"])
        self.toggle.connect("clicked", lambda button: self.set_expanded(not self.revealer.get_reveal_child()))
        header.append(self.toggle)
        self.append(header)

        self.pages = Gtk.Box(spacing=8)
        scrolled = Gtk.ScrolledWindow(vscrollbar_policy=Gtk.PolicyType.NEVER, child=self.pages,
                                      height_request=TILE_HEIGHT + 14, hexpand=True)
        self.scrolled = scrolled

        # Hold the left button and drag to scroll; a press that moves isn't a click on a page
        self.drag_origin = 0.0
        self.dragging = False
        self.dragged = False
        drag = Gtk.GestureDrag(button=Gdk.BUTTON_PRIMARY, propagation_phase=Gtk.PropagationPhase.CAPTURE)
        drag.connect("drag-begin", self.on_drag_begin)
        drag.connect("drag-update", self.on_drag_update)
        drag.connect("drag-end", self.on_drag_end)
        scrolled.add_controller(drag)
        overlay = Gtk.Overlay(child=scrolled)
        self.status = Gtk.Label(label="Cargando vista previa…", css_classes=["dim-label"],
                                valign=Gtk.Align.CENTER, can_target=False)
        overlay.add_overlay(self.status)

        start = Gtk.Button(label="Leer desde el inicio", css_classes=["flat"])
        start.connect("clicked", lambda button: self.chapter and self.on_open(self.chapter, 0))
        header.insert_child_after(start, self.title)

        self.revealer = Gtk.Revealer(child=overlay, transition_type=Gtk.RevealerTransitionType.SLIDE_DOWN)
        self.append(self.revealer)

        # No cancelling on unrealize: the manga page moves this widget between its wide and narrow
        # layouts, which unrealizes it; the few page downloads simply finish.
        self.set_expanded(expanded)

    def on_drag_begin(self, gesture, x, y):
        device = gesture.get_device()
        if device is not None and device.get_source() == Gdk.InputSource.TOUCHSCREEN:
            gesture.set_state(Gtk.EventSequenceState.DENIED)  # touch already scrolls natively
            return
        self.drag_origin = self.scrolled.get_hadjustment().get_value()
        self.dragging = False
        self.dragged = False

    def on_page_released(self, index):
        if not self.dragged:
            self.on_open(self.chapter, index)

    def on_drag_update(self, gesture, offset_x, offset_y):
        if not self.dragging:
            if abs(offset_x) < DRAG_THRESHOLD:
                return
            self.dragging = True
            self.dragged = True  # stays set until the next press, whatever order the events arrive in
            gesture.set_state(Gtk.EventSequenceState.CLAIMED)  # cancels the page's click
            self.set_cursor_from_name("grabbing")
        self.scrolled.get_hadjustment().set_value(self.drag_origin - offset_x)

    def on_drag_end(self, gesture, offset_x, offset_y):
        self.dragging = False
        self.set_cursor(None)

    def set_expanded(self, expanded: bool):
        self.revealer.set_reveal_child(expanded)
        self.toggle.set_label("Ocultar" if expanded else "Ver vista previa")
        if expanded and not self.loaded:
            self.loaded = True
            self.tasks.append(asyncio.create_task(self.load()))

    def set_chapter(self, chapter):
        self.chapter = chapter
        self.title.set_label(f"VISTA PREVIA · {chapter.name}".upper())

    def cancel(self):
        for task in self.tasks:
            task.cancel()
        self.tasks = []

    async def load(self):
        try:
            pages = await self.suwayomi.getChapterPages(self.chapter.id)
        except Exception:
            self.status.set_label("No se pudo cargar la vista previa")
            return
        if not pages:
            self.status.set_label("Este capítulo no tiene páginas")
            return
        self.status.set_visible(False)

        pictures = []
        for index, page in enumerate(pages[:PREVIEW_PAGES]):
            picture = Gtk.Picture(content_fit=Gtk.ContentFit.COVER, can_shrink=True, width_request=TILE_WIDTH,
                                  height_request=TILE_HEIGHT, css_classes=["poster", "preview-tile"],
                                  tooltip_text=f"Abrir en la página {index + 1}")
            picture.set_cursor_from_name("pointer")
            click = Gtk.GestureClick()
            click.connect("released", lambda gesture, n, x, y, i=index: self.on_page_released(i))
            picture.add_controller(click)
            # A Picture asks for its image's size; clamp it so every tile is the same
            self.pages.append(Adw.Clamp(maximum_size=TILE_WIDTH, tightening_threshold=TILE_WIDTH,
                                        child=Adw.Clamp(orientation=Gtk.Orientation.VERTICAL,
                                                        maximum_size=TILE_HEIGHT, tightening_threshold=TILE_HEIGHT,
                                                        child=picture)))
            pictures.append((picture, page))

        semaphore = asyncio.Semaphore(MAX_CONCURRENT)
        shapes = {}

        async def fill(picture, page):
            async with semaphore:
                try:
                    paintable = await self.suwayomi.getPaintable(page.url)
                except Exception:
                    picture.get_parent().get_parent().set_visible(False)
                    return
            width, height = paintable.get_intrinsic_width(), paintable.get_intrinsic_height()
            if width < MIN_PAGE_WIDTH or not height:
                picture.get_parent().get_parent().set_visible(False)
                return
            shapes[picture] = height / width
            picture.set_paintable(paintable)

        await asyncio.gather(*(fill(picture, page) for picture, page in pictures), return_exceptions=True)

        # Scanlation groups open chapters with landscape credit / recruiting banners; art pages are
        # portrait (manga) or very tall (webtoon). Skip the leading landscape ones, keep at least one page.
        visible = [picture for picture, _ in pictures if picture in shapes]
        for picture in visible[:-1]:
            if shapes[picture] >= 1.0:
                break
            picture.get_parent().get_parent().set_visible(False)
