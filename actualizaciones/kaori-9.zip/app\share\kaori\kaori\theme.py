"""Kaori's colours: a main colour (buttons, links, selection) and an accent (new chapters, your
place in a series, recommendations). Every other tone the styles use is worked out from those two:
hover, soft backgrounds, borders, muted text, and the text colour that reads well on each."""
import os
import time

from gi.repository import Gdk, GdkPixbuf, GLib, Gtk

DEFAULT_PRIMARY = "#87CEEB"
DEFAULT_SECONDARY = "#F4B6C8"
DEFAULT_BACKGROUND = "#12151B"

# (name, colour): Kaori's design is for dark backgrounds (all its text is light)
BACKGROUNDS = (
    ("Noche azul", "#12151B"),
    ("Negro", "#0B0B0D"),
    ("Grafito", "#18181B"),
    ("Ciruela", "#1A1220"),
    ("Bosque", "#0F1A15"),
    ("Vino", "#1E1013"),
    ("Abismo", "#0B1620"),
    ("Café", "#1C1611"),
)
MAX_BACKGROUND_LUMINANCE = 0.025  # lighter than this and the light text stops reading well
# Offsets from the background (in 0-255 steps) that give the other surfaces; they reproduce the
# original design exactly for its #12151B: sidebar #0C0E13, cards #1A1F28, dialogs #181C24
FRAME_OFFSET = (-6, -7, -8)
CARD_OFFSET = (8, 10, 13)
SURFACE_OFFSET = (6, 7, 9)

# (name, main, accent)
PRESETS = (
    ("Cielo y Sakura", "#87CEEB", "#F4B6C8"),
    ("Menta y Lavanda", "#7FD8BE", "#C3A6F5"),
    ("Atardecer", "#FFA36C", "#FF6F91"),
    ("Océano", "#4FA3FF", "#5EEAD4"),
    ("Bosque", "#8BC98A", "#F2D27A"),
    ("Uva", "#B18CFF", "#FF8FC8"),
    ("Coral", "#FF7A7A", "#FFC58A"),
    ("Nieve", "#D7DEE8", "#9FB4CC"),
)

DARK_TEXT = (0.055, 0.10, 0.15)  # #0E1A26
LIGHT_TEXT = (0.96, 0.97, 0.98)
MUTED_GRAY = (0.56, 0.62, 0.66)
DEFAULT_DIM = 75  # % of the background colour over the picture
MAX_IMAGE_WIDTH = 2560
BLUR_WIDTH = 48
ALPHAS = (10, 12, 14, 16, 25, 50, 90)

_provider = None


def parse(color: str) -> tuple[float, float, float]:
    rgba = Gdk.RGBA()
    if not rgba.parse(color or ""):
        rgba.parse(DEFAULT_PRIMARY)
    return rgba.red, rgba.green, rgba.blue


def to_hex(rgb) -> str:
    return "#" + "".join(f"{round(max(0, min(1, c)) * 255):02X}" for c in rgb)


def rgba(rgb, alpha) -> str:
    r, g, b = (round(max(0, min(1, c)) * 255) for c in rgb)
    return f"rgba({r}, {g}, {b}, {round(alpha, 3)})"


def mix(a, b, amount):
    """a moved `amount` of the way towards b."""
    return tuple(x + (y - x) * amount for x, y in zip(a, b))


def luminance(rgb) -> float:
    def channel(c):
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (channel(c) for c in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def text_on(rgb):
    """Dark text on light colours, light text on dark ones."""
    return DARK_TEXT if luminance(rgb) > 0.30 else LIGHT_TEXT


def darkened(rgb):
    """The same hue, dark enough for Kaori's light text."""
    while luminance(rgb) > MAX_BACKGROUND_LUMINANCE:
        rgb = tuple(c * 0.9 for c in rgb)
    return rgb


def offset(rgb, steps):
    return tuple(c + s / 255 for c, s in zip(rgb, steps))


def background_palette(background: str) -> dict[str, str]:
    bg = darkened(parse(background))
    frame, card, surface = offset(bg, FRAME_OFFSET), offset(bg, CARD_OFFSET), offset(bg, SURFACE_OFFSET)
    values = {
        "--bg": to_hex(bg), "--bg-frame": to_hex(frame), "--bg-card": to_hex(card),
        "--window-bg-color": to_hex(bg), "--view-bg-color": to_hex(bg),
        "--headerbar-bg-color": to_hex(bg), "--headerbar-backdrop-color": to_hex(bg),
        "--sidebar-bg-color": to_hex(frame), "--sidebar-backdrop-color": to_hex(frame),
        "--secondary-sidebar-bg-color": to_hex(frame),
        "--card-bg-color": to_hex(card), "--thumbnail-bg-color": to_hex(card),
        "--dialog-bg-color": to_hex(surface), "--popover-bg-color": to_hex(surface),
    }
    for alpha in (15, 20, 55, 92):
        values[f"--bg-{alpha}"] = rgba(bg, alpha / 100)
    for alpha in (70, 75, 85):
        values[f"--card-{alpha}"] = rgba(card, alpha / 100)
    for alpha in (85, 92):
        values[f"--frame-{alpha}"] = rgba(frame, alpha / 100)
    values["--surface-95"] = rgba(surface, 0.95)
    return values


def palette(primary: str, secondary: str, background: str = DEFAULT_BACKGROUND) -> dict[str, str]:
    main, accent = parse(primary), parse(secondary)
    ink, on_accent = text_on(main), text_on(accent)
    values = {
        "--sky": to_hex(main),
        "--sky-hover": to_hex(mix(main, (1, 1, 1), 0.25)),
        "--sky-soft": rgba(main, 0.16),
        "--sakura": to_hex(accent),
        "--sakura-soft": rgba(accent, 0.18),
        "--sakura-10": rgba(accent, 0.10),
        "--ink": to_hex(ink),
        "--on-sakura": to_hex(on_accent),
        "--muted": to_hex(mix(main, MUTED_GRAY, 0.55)),
        "--accent-bg-color": to_hex(main),
        "--accent-fg-color": to_hex(ink),
        "--accent-color": to_hex(main),
        "--headerbar-border-color": rgba(main, 0.14),
    }
    for alpha in ALPHAS:
        values[f"--sky-{alpha}"] = rgba(main, alpha / 100)
    values.update(background_palette(background))
    return values


def css(primary: str, secondary: str, background: str = DEFAULT_BACKGROUND) -> str:
    values = palette(primary, secondary, background)
    return ":root {\n" + "".join(f"  {name}: {value};\n" for name, value in values.items()) + "}\n"


def image_css(background: str, image: str, dim: int) -> str:
    """The picture behind everything, under a layer of the background colour (`dim` %) so the light
    text keeps reading well; the window's surfaces turn see-through to let it show."""
    bg = darkened(parse(background))
    frame, card = offset(bg, FRAME_OFFSET), offset(bg, CARD_OFFSET)
    surface = offset(bg, SURFACE_OFFSET)
    layer = rgba(bg, dim / 100)
    uri = GLib.filename_to_uri(image)
    return f"""
:root {{
  --window-bg-color: transparent;
  --view-bg-color: transparent;
  --headerbar-bg-color: {rgba(bg, min(1, dim / 100 * 0.6))};
  --headerbar-backdrop-color: {rgba(bg, min(1, dim / 100 * 0.6))};
  --sidebar-bg-color: {rgba(frame, min(1, dim / 100 + 0.1))};
  --sidebar-backdrop-color: {rgba(frame, min(1, dim / 100 + 0.1))};
  --secondary-sidebar-bg-color: {rgba(frame, min(1, dim / 100 + 0.1))};
  --card-bg-color: {rgba(card, 0.82)};
}}
/* Dialogs and popovers stay solid: they sit over the picture and must read like before */
sheet, dialog sheet, dialog .dialog-contents, window.dialog, popover > contents {{
  background-color: {to_hex(surface)};
}}
window.kaori-main {{
  background-image: linear-gradient({layer}, {layer}), url("{uri}");
  background-size: cover, cover;
  background-position: center, center;
  background-repeat: no-repeat;
}}
"""


def apply(primary: str, secondary: str, background: str = DEFAULT_BACKGROUND,
          image: str = "", dim: int = DEFAULT_DIM, blur: bool = False):
    """Restyle the whole app now (the provider overrides style.css's default :root)."""
    global _provider
    display = Gdk.Display.get_default()
    if display is None:
        return
    if _provider is None:
        _provider = Gtk.CssProvider()
        Gtk.StyleContext.add_provider_for_display(display, _provider, Gtk.STYLE_PROVIDER_PRIORITY_USER)
    text = css(primary, secondary, background)
    shown = blurred_path(image) if blur and image else image
    if shown and os.path.exists(shown):
        text += image_css(background, shown, dim)
    _provider.load_from_string(text)


def current(settings) -> tuple[str, str, str]:
    return (settings.get_string("theme-primary") or DEFAULT_PRIMARY,
            settings.get_string("theme-secondary") or DEFAULT_SECONDARY,
            settings.get_string("theme-background") or DEFAULT_BACKGROUND)


def image_settings(settings) -> tuple[str, int, bool]:
    return (settings.get_string("theme-image"), settings.get_int("theme-image-dim"),
            settings.get_boolean("theme-image-blur"))


def apply_saved(settings):
    apply(*current(settings), *image_settings(settings))


# --- background picture ---

def images_dir() -> str:
    return os.path.join(GLib.get_user_data_dir(), "kaori", "fondo")


def blurred_path(image: str) -> str:
    root, _ = os.path.splitext(image)
    return root + "-desenfocado.png"


def store_image(source: str) -> str:
    """Copy the chosen picture into Kaori's data folder (the original can then move or go) and
    prepare its blurred version. Returns the stored path."""
    folder = images_dir()
    os.makedirs(folder, exist_ok=True)
    for old in os.listdir(folder):  # only the current picture is kept
        try:
            os.remove(os.path.join(folder, old))
        except OSError:
            pass
    pixbuf = GdkPixbuf.Pixbuf.new_from_file(source)
    # Big pictures are scaled to screen size: sharper isn't visible behind the dimming, only slower
    width, height = pixbuf.get_width(), pixbuf.get_height()
    if width > MAX_IMAGE_WIDTH:
        pixbuf = pixbuf.scale_simple(MAX_IMAGE_WIDTH, round(height * MAX_IMAGE_WIDTH / width),
                                     GdkPixbuf.InterpType.HYPER)
    stored = os.path.join(folder, f"fondo-{int(time.time())}.jpg")
    pixbuf.savev(stored, "jpeg", ["quality"], ["90"])
    # Blur: shrink a lot, then grow back smoothly (no blur shader needed)
    small = pixbuf.scale_simple(BLUR_WIDTH, max(1, round(pixbuf.get_height() * BLUR_WIDTH / pixbuf.get_width())),
                                GdkPixbuf.InterpType.HYPER)
    soft = small.scale_simple(pixbuf.get_width(), pixbuf.get_height(), GdkPixbuf.InterpType.BILINEAR)
    soft.savev(blurred_path(stored), "png", [], [])
    return stored


def primary_rgba(settings) -> Gdk.RGBA:
    color = Gdk.RGBA()
    color.parse(current(settings)[0])
    return color
