import asyncio

from gi.repository import Adw, Gio, GLib, Gtk, Pango

from ...integrations import compare, health

MAX_CONCURRENT = 3
ICON_SIZE = 40


class HealthRow(Gtk.ListBoxRow):
    __gtype_name__ = "KaoriHealthRow"

    def __init__(self, source):
        super().__init__(activatable=True)
        self.source = source
        self.result = None
        self.set_tooltip_text(f"Abrir {source.name}")

        box = Gtk.Box(spacing=14, margin_top=8, margin_bottom=8, margin_start=10, margin_end=14)
        self.rank_label = Gtk.Label(label="", width_chars=3, css_classes=["title-4", "dim-label"])
        box.append(self.rank_label)
        self.icon = Gtk.Picture(content_fit=Gtk.ContentFit.COVER, can_shrink=True,
                                width_request=ICON_SIZE, height_request=ICON_SIZE)
        box.append(Adw.Clamp(maximum_size=ICON_SIZE, tightening_threshold=ICON_SIZE, valign=Gtk.Align.CENTER,
                             child=Adw.Clamp(orientation=Gtk.Orientation.VERTICAL, maximum_size=ICON_SIZE,
                                             tightening_threshold=ICON_SIZE, child=self.icon)))

        info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3, hexpand=True, valign=Gtk.Align.CENTER)
        info.append(Gtk.Label(label=f"{source.name}  ·  {source.lang}", xalign=0, css_classes=["heading"]))
        self.line1 = Gtk.Label(label="Midiendo…", xalign=0, ellipsize=Pango.EllipsizeMode.END)
        info.append(self.line1)
        self.line2 = Gtk.Label(label="", xalign=0, css_classes=["dim-label", "caption"],
                               ellipsize=Pango.EllipsizeMode.END)
        info.append(self.line2)
        box.append(info)

        self.score_label = Gtk.Label(label="…", css_classes=["title-2"])
        box.append(self.score_label)
        self.set_child(box)

    async def load_icon(self, suwayomi):
        if self.source.icon_url:
            try:
                self.icon.set_paintable(await suwayomi.getPaintable(self.source.icon_url))
            except Exception:
                pass

    def show(self, result):
        self.result = result
        if not result["ok"]:
            self.score_label.set_label("✕")
            self.line1.set_label(f"No funciona: {result['error']}")
            self.line2.set_label("")
            return
        self.score_label.set_label(str(result["score"]))
        self.line1.set_label(f"Funciona · {result['seconds']} s en cargar · {health.describe_catalog(result)}")
        quality = (f"Calidad {result['quality']} ({result['width']} px)" if result["width"]
                   else "Calidad sin medir")
        self.line2.set_label(f"{quality} · último capítulo: {compare.format_updated(result['updated'])}")


class SourceHealthPage(Adw.NavigationPage):
    """Installed sources ranked by Kaori's own measurements (works, speed, catalog, quality, activity)."""
    __gtype_name__ = "KaoriSourceHealthPage"

    def __init__(self):
        super().__init__(title="Ranking de fuentes")
        self.suwayomi = Gio.Application.get_default().suwayomi
        self.tasks = []

        self.status = Gtk.Label(xalign=0, wrap=True, css_classes=["dim-label"])
        self.list = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE, css_classes=["boxed-list"])
        self.list.connect("row-activated", self.on_row_activated)

        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12,
                          margin_top=12, margin_bottom=24, margin_start=12, margin_end=12)
        content.append(self.status)
        content.append(self.list)
        content.append(Gtk.Label(
            label="Puntaje de 0 a 100 medido por Kaori: velocidad (20), tamaño del catálogo (25), "
                  "calidad de imagen (30) y actividad (25). Se guarda un día; «Volver a medir» lo actualiza.",
            xalign=0, wrap=True, css_classes=["dim-label", "caption"]))

        remeasure = Gtk.Button(label="Volver a medir", tooltip_text="Ignorar las mediciones guardadas")
        remeasure.connect("clicked", lambda button: self.start(force=True))
        header = Adw.HeaderBar()
        header.pack_end(remeasure)

        view = Adw.ToolbarView(content=Gtk.ScrolledWindow(
            hscrollbar_policy=Gtk.PolicyType.NEVER, child=Adw.Clamp(maximum_size=1000, child=content)))
        view.add_top_bar(header)
        self.set_child(view)

        self.connect("unrealize", lambda page: [task.cancel() for task in self.tasks])
        self.start(force=False)

    def start(self, force: bool):
        for task in self.tasks:
            task.cancel()
        self.tasks = []
        self.list.remove_all()
        self.rows = []
        self.tasks.append(asyncio.create_task(self.run(force)))

    async def run(self, force: bool):
        await self.suwayomi.refreshSources()
        sources = [source for source in self.suwayomi.sources if source.id != "0"]
        for source in sources:
            row = HealthRow(source)
            self.rows.append(row)
            self.list.append(row)
            self.tasks.append(asyncio.create_task(row.load_icon(self.suwayomi)))

        self.done = 0
        self.update_status()
        semaphore = asyncio.Semaphore(MAX_CONCURRENT)

        async def one(row):
            result = None if force else health.cached(row.source.id)
            if result is None:
                async with semaphore:
                    result = await health.measure(self.suwayomi, row.source)
            row.show(result)
            self.done += 1
            self.update_status()

        await asyncio.gather(*(one(row) for row in self.rows), return_exceptions=True)
        self.rank()

    def update_status(self):
        total = len(self.rows)
        if self.done < total:
            self.status.set_label(f"Midiendo tus fuentes… ({self.done}/{total}). "
                                  "Cada una tarda unos segundos la primera vez.")
        else:
            self.status.set_label(f"{total} fuentes instaladas en tus idiomas, de mejor a peor.")

    def rank(self):
        def key(row):
            r = row.result
            if not r:
                return (-1, 0)
            return (r["score"], -r["seconds"])

        order = sorted(self.rows, key=key, reverse=True)
        for row in self.rows:
            self.list.remove(row)
        for position, row in enumerate(order, start=1):
            row.rank_label.set_label(f"#{position}" if row.result and row.result["ok"] else "")
            self.list.append(row)

    def on_row_activated(self, listbox, row):
        self.activate_action("app.show_source", GLib.Variant("s", row.source.id))
