import asyncio

from gi.repository import Adw, GObject, Gtk


class SourcePreferencesDialog(Adw.PreferencesDialog):
    """The extension's own settings for one source (NSFW content, custom domain...)."""
    __gtype_name__ = "KaoriSourcePreferencesDialog"

    @GObject.Signal
    def changed(self):
        """A preference was saved: the source page reloads its lists."""

    def __init__(self, suwayomi, source):
        # Fixed size: the rows arrive after the dialog is shown, so it can't size itself to them
        super().__init__(title=f"Ajustes de {source.name}", search_enabled=False,
                         content_width=560, content_height=460)
        self.suwayomi = suwayomi
        self.source = source

        self.page = Adw.PreferencesPage()
        self.group = Adw.PreferencesGroup(
            description="Opciones propias de esta extensión. Se guardan en el servidor y se aplican al instante.")
        self.page.add(self.group)
        self.add(self.page)
        self.status = Adw.ActionRow(title="Cargando ajustes…")
        self.group.add(self.status)
        asyncio.create_task(self.load())

    async def load(self):
        try:
            prefs = await self.suwayomi.getSourcePreferences(self.source.id)
        except Exception as error:
            self.status.set_title("No se pudieron cargar los ajustes")
            self.status.set_subtitle(str(error)[:200])
            return
        self.group.remove(self.status)
        shown = [pref for pref in prefs if pref['visible']]
        if not shown:
            self.group.add(Adw.ActionRow(title="Esta fuente no tiene ajustes"))
        for pref in shown:
            if row := self.make_row(pref):
                self.group.add(row)

    def make_row(self, pref):
        kind, title, summary = pref['kind'], pref['title'], pref['summary']
        if kind in ('SwitchPreference', 'CheckBoxPreference'):
            row = Adw.SwitchRow(title=title, subtitle=summary, active=bool(pref['value']))
            row.connect("notify::active", lambda row, _: self.save(pref, row.get_active()))
            return row
        if kind == 'ListPreference':
            row = Adw.ComboRow(title=title, subtitle=summary, model=Gtk.StringList.new(pref['entries']))
            if pref['value'] in pref['entry_values']:
                row.set_selected(pref['entry_values'].index(pref['value']))
            row.connect("notify::selected",
                        lambda row, _: self.save(pref, pref['entry_values'][row.get_selected()]))
            return row
        if kind == 'EditTextPreference':
            row = Adw.EntryRow(title=title, text=pref['value'] or '', show_apply_button=True)
            row.connect("apply", lambda row: self.save(pref, row.get_text()))
            return row
        if kind == 'MultiSelectListPreference':
            row = Adw.ExpanderRow(title=title, subtitle=summary)
            selected = set(pref['value'] or [])
            switches = []
            for label, value in zip(pref['entries'], pref['entry_values']):
                switch = Adw.SwitchRow(title=label, active=value in selected)
                switches.append((switch, value))
                switch.connect("notify::active", lambda *_: self.save(
                    pref, [value for switch, value in switches if switch.get_active()]))
                row.add_row(switch)
            return row
        return None

    def save(self, pref, value):
        asyncio.create_task(self.store(pref, value))

    async def store(self, pref, value):
        try:
            await self.suwayomi.setSourcePreference(self.source.id, pref['position'], pref['kind'], value)
        except Exception as error:
            self.add_toast(Adw.Toast(title=f"No se pudo guardar: {str(error)[:80]}", timeout=4))
            return
        pref['value'] = value
        self.add_toast(Adw.Toast(title=f"«{pref['title']}» guardado", timeout=2))
        self.emit("changed")
