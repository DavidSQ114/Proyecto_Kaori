"""Measure how well each installed source works, to rank them: Kaori's own numbers, since no
extension repository publishes ratings."""
import json
import os
import time

from gi.repository import GLib

from . import compare
from .suwayomi import SourceMangaType

CACHE_TTL = 24 * 3600
CATALOG_PROBES = (5, 20)  # pages probed to estimate the catalog size


def cache_path():
    return os.path.join(GLib.get_user_cache_dir(), "kaori", "source-health.json")


def load_cache() -> dict:
    try:
        with open(cache_path(), encoding="utf-8") as file:
            return json.load(file)
    except (OSError, ValueError):
        return {}


def save_cache(data: dict):
    os.makedirs(os.path.dirname(cache_path()), exist_ok=True)
    with open(cache_path(), "w", encoding="utf-8") as file:
        json.dump(data, file, ensure_ascii=False)


def cached(source_id: str) -> dict | None:
    entry = load_cache().get(source_id)
    if entry and time.time() - entry.get("measured", 0) < CACHE_TTL:
        return entry
    return None


async def measure(suwayomi, source) -> dict:
    """Popular page speed, rough catalog size, image quality and activity of the newest update."""
    result = {"ok": False, "error": "", "seconds": 0.0, "catalog": 0, "catalog_more": False,
              "width": 0, "quality": "?", "updated": 0.0, "measured": time.time()}
    start = time.monotonic()
    try:
        popular, has_next = await suwayomi.getSourceMangaPage(source.id, SourceMangaType.POPULAR, 1)
    except Exception as error:
        result["error"] = compare.friendly_error(error)
        return finish(source, result)
    result["seconds"] = round(time.monotonic() - start, 1)
    result["ok"] = bool(popular)
    if not popular:
        result["error"] = "La fuente no devolvió ningún manga"
        return finish(source, result)

    # Catalog size: how deep the popular list goes (stops at the first probe that comes back empty)
    result["catalog"] = 1
    result["catalog_more"] = has_next
    for page in CATALOG_PROBES:
        if not result["catalog_more"]:
            break
        try:
            mangas, more = await suwayomi.getSourceMangaPage(source.id, SourceMangaType.POPULAR, page)
        except Exception:
            break
        if not mangas:
            result["catalog_more"] = False
            break
        result["catalog"], result["catalog_more"] = page, more

    # Quality and activity from two series: the most recently updated and the most popular one.
    # Each series has its own scan, so one sample alone is too noisy; keep the best of the two.
    try:
        latest = await suwayomi.getSourceManga(source.id, SourceMangaType.LATEST, 1)
    except Exception:
        latest = []
    samples = list({manga.id: manga for manga in (latest[:1] + popular[:1])}.values())
    for manga in samples:
        try:
            sample = await compare.analyze(suwayomi, manga)
        except Exception:
            continue
        if sample["width"] > result["width"]:
            result.update(width=sample["width"], quality=sample["quality"])
        result["updated"] = max(result["updated"], sample["updated"])
    return finish(source, result)


def finish(source, result: dict) -> dict:
    result["score"] = score(result)
    data = load_cache()
    data[source.id] = result
    save_cache(data)
    return result


def score(r: dict) -> int:
    """0-100: works (required) + speed 20 + catalog 25 + image quality 30 + activity 25."""
    if not r["ok"]:
        return 0
    seconds = r["seconds"]
    speed = 20 if seconds < 2 else 14 if seconds < 4 else 8 if seconds < 8 else 3
    catalog = 25 if r["catalog"] >= 20 and r["catalog_more"] else 20 if r["catalog"] >= 20 else \
        12 if r["catalog"] >= 5 else 5
    quality = {"Alta": 30, "Media": 20, "Baja": 10}.get(r["quality"], 5)
    if r["updated"]:
        days = (time.time() - r["updated"]) / 86400
        activity = 25 if days <= 7 else 18 if days <= 30 else 10 if days <= 180 else 3
    else:
        activity = 3
    return speed + catalog + quality + activity


def describe_catalog(r: dict) -> str:
    if r["catalog"] >= 20:
        return "catálogo grande (+20 páginas)" if r["catalog_more"] else "catálogo grande (~20 páginas)"
    if r["catalog"] >= 5:
        return "catálogo mediano (5–20 páginas)"
    return "catálogo pequeño (menos de 5 páginas)"
