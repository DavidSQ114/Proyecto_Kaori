"""Which real series a manga from a source is, whatever the scan called it.

Spanish scans rename series freely ("Ricky ricon coreano" is Reborn Rich), so the title alone often
says nothing. In order of reliability:

1. MangaUpdates title search: it keeps many alternative names, including Spanish scan titles.
   Also tried with the "Alternative: ..." names some synopses carry.
2. Character names from the synopsis ("Jin Dojun"), looked up in AniList's characters: names don't
   change between scans. Only full names (2-3 words) that match the character exactly count.

The result links the manga to AniList and MangaUpdates ids, cached per manga in
<cache>/kaori/identity.json (misses are retried after a week).
"""
import asyncio
import json
import os
import re
import time
import unicodedata

import httpx
from gi.repository import GLib

from .anilist import throttled_post
from .compare import plain_ratio

MU_SEARCH = "https://api.mangaupdates.com/v1/series/search"
ANILIST = "https://graphql.anilist.co"
MIN_TITLE_MATCH = 0.86
MIN_SHORT_MATCH = 0.95  # titles under 20 letters: "Electricidad" is not "Bielectricidad"
SHORT_TITLE = 20
MISS_RETRY = 7 * 86400
LOOKUP_VERSION = 2  # a better lookup retries what the last one missed (2: AniList by alternative names)
REQUEST_GAP = 0.7  # s between requests to the same service (both rate-limit)

ALT_LINE = re.compile(r"(?:alternativ[eo]s?(?:\s+(?:names?|titles?|nombres?|t[ií]tulos?))?|"
                      r"nombres? alternativos?|otros nombres|t[ií]tulos? alternativos?|also known as|aka)"
                      r"\s*[:：]\s*(.+)", re.IGNORECASE)
NAME = re.compile(r"\b([A-ZÁÉÍÓÚÑ][a-záéíóúñ]+(?:[\s-][A-ZÁÉÍÓÚÑ]?[a-záéíóúñ]+){1,2})\b")
NOT_NAMES = set("""el la los las un una pero cuando sin con para por que qué su sus este esta ese esa del al y en de
es lo le se si mi tu yo él ella hoy ahora después antes tras como cómo dónde quién así todo toda nada sólo solo grupo
academia imperio reino ciudad mundo torre casa familia corea japón seúl""".split())

CHARACTER_QUERY = """
query ($search: String) {
  Page(perPage: 4) {
    characters(search: $search) {
      name { full native alternative }
      media(perPage: 4, type: MANGA) { nodes { id title { english romaji } } }
    }
  }
}
"""

ANILIST_BY_TITLE = """
query ($search: String) {
  Page(perPage: 5) {
    media(search: $search, type: MANGA) { id title { english romaji native } synonyms }
  }
}
"""


def squash(name: str) -> str:
    """Name for comparing people: no accents, case, hyphens or spaces, words sorted ("Do-Jun Jin" = "Jin Dojun")."""
    plain = "".join(c for c in unicodedata.normalize("NFD", name or "") if not unicodedata.combining(c))
    words = re.findall(r"[a-z]+", plain.casefold().replace("-", ""))
    return "".join(sorted(words))


def alternative_titles(description: str) -> list[str]:
    titles = []
    for match in ALT_LINE.finditer(description or ""):
        for part in re.split(r"[,;/|]| - ", match.group(1)):
            part = part.strip(" .\"'«»")
            if 3 <= len(part) <= 120:
                titles.append(part)
    return titles


def is_native(name: str) -> bool:
    """Written in Korean, Japanese or Chinese: the series' original title."""
    return any("぀" <= c <= "ヿ" or "㐀" <= c <= "鿿" or "가" <= c <= "힯" for c in name)


def character_names(description: str) -> list[str]:
    names = []
    for name in NAME.findall(description or ""):
        words = re.split(r"[\s-]", name)
        if any(w.casefold() in NOT_NAMES for w in words):
            continue
        names.append(name)
    return list(dict.fromkeys(names))[:5]


class SeriesIdentity:
    def __init__(self):
        self.http = httpx.AsyncClient(timeout=20, headers={"Accept": "application/json"})
        self.path = os.path.join(GLib.get_user_cache_dir(), "kaori", "identity.json")
        self.locks = {"mu": asyncio.Lock(), "anilist": asyncio.Lock()}
        self.last = {"mu": 0.0, "anilist": 0.0}
        self.pending: dict[int, asyncio.Future] = {}
        self.errors = 0  # failed requests: a miss after errors isn't a real miss
        try:
            with open(self.path, encoding="utf-8") as file:
                self.cache = json.load(file)
        except (OSError, ValueError):
            self.cache = {}

    def known(self, manga_id: int) -> dict | None:
        """The cached identity, if a lookup already found one."""
        entry = self.cache.get(str(manga_id)) or {}
        return entry if entry.get("anilist_id") or entry.get("mu_id") else None

    async def identify(self, manga_id: int, title: str, description: str) -> dict | None:
        """{anilist_id, mu_id, title, method} or None. Concurrent calls for one manga share the lookup."""
        entry = self.cache.get(str(manga_id))
        if entry and (entry.get("anilist_id") or (entry.get("version") == LOOKUP_VERSION and (
                entry.get("mu_id") or time.time() - entry["checked"] < MISS_RETRY))):
            return entry if entry.get("anilist_id") or entry.get("mu_id") else None
        if manga_id not in self.pending:
            self.pending[manga_id] = asyncio.ensure_future(self.lookup(manga_id, title, description))
        try:
            return await asyncio.shield(self.pending[manga_id])
        finally:
            self.pending.pop(manga_id, None)

    def link(self, manga_id: int, anilist_id: int, title: str):
        """Set by hand (the user picked the series in AniList)."""
        self.cache[str(manga_id)] = {"checked": time.time(), "anilist_id": anilist_id, "mu_id": None,
                                     "title": title, "method": "manual"}
        self.save()

    async def lookup(self, manga_id, title, description):
        errors_before = self.errors
        found = None
        for candidate in [title, *alternative_titles(description)]:
            found = await self.by_mangaupdates(candidate)
            if found:
                break
        if not found:
            found = await self.by_characters(description)
        if found and not found.get("anilist_id"):
            # MangaUpdates' name isn't always AniList's ("Private Debtors"): the synopsis' alternative
            # names too, the original one (사채지간) first, the least ambiguous
            alternatives = alternative_titles(description)
            for candidate in dict.fromkeys([*[a for a in alternatives if is_native(a)], found["title"],
                                            *found.get("names", []), *alternatives]):
                found["anilist_id"] = await self.anilist_for(candidate, [])
                if found["anilist_id"]:
                    break
        if found and not found.get("mu_id"):
            mu = await self.by_mangaupdates(found["title"], strict=True)
            found["mu_id"] = mu["mu_id"] if mu else None
            found["mu_url"] = mu.get("mu_url") if mu else None
        if self.errors > errors_before and not (found and found.get("anilist_id")):
            # The services failed (offline, rate limit): use what was found, but look again next time
            return {k: found.get(k) for k in ("anilist_id", "mu_id", "mu_url", "title", "method")} if found else None
        entry = {"checked": time.time(), "version": LOOKUP_VERSION, **({k: found.get(k) for k in ("anilist_id", "mu_id", "mu_url", "title", "method")}
                                            if found else {})}
        self.cache[str(manga_id)] = entry
        self.save()
        return entry if found else None

    async def request(self, service, method, url, **kwargs):
        if service == "anilist":
            response = await throttled_post(self.http, kwargs["json"])
            if response.status_code != 200:
                self.errors += 1
            response.raise_for_status()
            return response.json()
        async with self.locks[service]:
            wait = self.last[service] + REQUEST_GAP - time.monotonic()
            if wait > 0:
                await asyncio.sleep(wait)
            try:
                response = await self.http.request(method, url, **kwargs)
            except httpx.HTTPError:
                self.errors += 1
                raise
            finally:
                self.last[service] = time.monotonic()
        if response.status_code != 200:
            self.errors += 1
        response.raise_for_status()
        return response.json()

    async def mangaupdates_matches(self, title) -> list[dict]:
        """Every MangaUpdates series whose name matches, best first. Short names are ambiguous:
        "Set Up" is a series and so is "Set Up (Kim Mundo)" (the author in brackets), the manhwa."""
        data = await self.request("mu", "POST", MU_SEARCH, json={"search": title, "perpage": 8})
        needed = MIN_SHORT_MATCH if len(title) < SHORT_TITLE else MIN_TITLE_MATCH
        matches = []
        for hit in data.get("results", []):
            record = hit["record"]
            names = [hit.get("hit_title") or "", record.get("title") or ""]
            names += [re.sub(r"\s*\(.*?\)", "", name) for name in names]
            score = max(plain_ratio(title, name) for name in names if name)
            if score >= needed:
                matches.append((score, record))
        # Same name, same score: the manhwa first (what the Spanish scans publish most)
        matches.sort(key=lambda item: (-round(item[0], 2), item[1].get("type") != "Manhwa"))
        return [record for _, record in matches]

    async def by_mangaupdates(self, title, strict=False):
        try:
            matches = await self.mangaupdates_matches(title)
        except Exception:
            return None
        if not matches:
            return None
        record = matches[0]
        return {"mu_id": record["series_id"], "mu_url": record.get("url"), "title": record["title"],
                "names": [record["title"]], "method": "mangaupdates"}

    async def by_characters(self, description):
        votes = {}
        for name in character_names(description):
            try:
                data = await self.request("anilist", "POST", ANILIST,
                                          json={"query": CHARACTER_QUERY, "variables": {"search": name}})
            except Exception:
                continue
            for character in data["data"]["Page"]["characters"]:
                names = [character["name"].get("full")] + (character["name"].get("alternative") or [])
                if not any(n and squash(n) == squash(name) for n in names):
                    continue
                for media in character["media"]["nodes"]:
                    key = media["id"]
                    title = media["title"].get("english") or media["title"].get("romaji")
                    votes.setdefault(key, [0, title])[0] += 1
                break  # the first exact character is the one
        if not votes:
            return None
        anilist_id, (count, title) = max(votes.items(), key=lambda item: item[1][0])
        return {"anilist_id": anilist_id, "title": title, "method": "personajes"}

    async def anilist_for(self, title, names):
        try:
            data = await self.request("anilist", "POST", ANILIST,
                                      json={"query": ANILIST_BY_TITLE, "variables": {"search": title}})
        except Exception:
            return None
        for media in data["data"]["Page"]["media"]:
            titles = [media["title"].get(k) for k in ("english", "romaji", "native")] + (media.get("synonyms") or [])
            if any(t and plain_ratio(title, t) >= MIN_TITLE_MATCH for t in titles):
                return media["id"]
        return None

    def save(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as file:
            json.dump(self.cache, file, ensure_ascii=False)
        os.replace(tmp, self.path)
