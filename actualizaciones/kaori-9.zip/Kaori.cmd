@echo off
rem Lanza Kaori en Windows usando el MSYS2 portable de esta carpeta.
rem Todos los datos (biblioteca, extensiones, cache, ajustes) quedan en .\data
setlocal
set "ROOT=%~dp0"
set "ROOT=%ROOT:~0,-1%"
set "DATA=%ROOT%\data"

rem Java: el incluido en .\jre si existe (paquete para compartir); si no, el del sistema (21 o superior)
if exist "%ROOT%\jre\bin\java.exe" set "JAVA_DIR=%ROOT%\jre\bin\"
for /f "delims=" %%J in ('where java 2^>nul') do if not defined JAVA_DIR set "JAVA_DIR=%%~dpJ"

set "PATH=%ROOT%\msys64\ucrt64\bin;%JAVA_DIR%;%SystemRoot%\system32;%SystemRoot%"
set "XDG_DATA_DIRS=%ROOT%\app\share;%ROOT%\msys64\ucrt64\share"
set "GSETTINGS_SCHEMA_DIR=%ROOT%\app\share\glib-2.0\schemas"
set "GSETTINGS_BACKEND=keyfile"
set "PYTHONUTF8=1"
set "XDG_CONFIG_HOME=%DATA%\config"
set "XDG_CACHE_HOME=%DATA%\cache"
set "XDG_DATA_HOME=%DATA%\share"

rem Render con la GPU (OpenGL). Sin Direct Composition GTK cae a Cairo por software:
rem el lector webtoon baja de ~80 FPS a ~4 FPS.
set "GDK_DEBUG=dcomp"
set "GSK_RENDERER=gl"

rem Suwayomi solo accesible desde este PC. Sus datos y los temporales de Java (cache de paginas,
rem varios GB) van a .\data: Kaori se los pasa como argumentos al iniciar el servidor.
rem Si la ruta de esta carpeta tiene tildes, usa Kaori.exe (Java no arranca desde ella).
cd /d "%ROOT%"
set "JAVA_TOOL_OPTIONS=-Dsuwayomi.tachidesk.config.server.ip=127.0.0.1"

if not exist "%DATA%" mkdir "%DATA%"
if not exist "%DATA%\tmp" mkdir "%DATA%\tmp"
"%ROOT%\msys64\ucrt64\bin\python.exe" "%ROOT%\app\bin\kaori" %*
