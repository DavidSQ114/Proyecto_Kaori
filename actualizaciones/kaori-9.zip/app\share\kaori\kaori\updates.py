"""Periodically look for new chapters of the series in "Tus Lecturas" and tell the user inside Kaori."""
import asyncio
import time

from gi.repository import Adw, GLib, GObject

FIRST_CHECK_DELAY = 120  # seconds after startup, so launching Kaori stays fast
MAX_SERIES = 30  # most recently read series that get checked
MAX_CONCURRENT = 2  # gentle with the sources' websites


class UpdateChecker(GObject.Object):
    __gtype_name__ = 'KaoriUpdateChecker'

    checking = GObject.Property(type=bool, default=False)
    last_check = GObject.Property(type=float, default=0.0)

    def __init__(self, app):
        super().__init__()
        self.app = app
        self.task = None
        GLib.timeout_add_seconds(FIRST_CHECK_DELAY, self.on_first_check)

    @property
    def interval_hours(self) -> int:
        return self.app.settings.get_int('updates-interval-hours')

    def on_first_check(self):
        self.start()
        if self.interval_hours > 0:
            GLib.timeout_add_seconds(self.interval_hours * 3600, self.on_timer)
        return GLib.SOURCE_REMOVE

    def on_timer(self):
        self.start()
        return GLib.SOURCE_CONTINUE

    def start(self):
        if self.interval_hours <= 0 and self.last_check:  # 0 = only on startup / when asked
            return
        self.check_now()

    def check_now(self):
        if self.task is None or self.task.done():
            self.task = asyncio.create_task(self.check())

    async def check(self):
        history = self.app.history
        suwayomi = self.app.suwayomi
        self.checking = True
        found = []
        semaphore = asyncio.Semaphore(MAX_CONCURRENT)

        async def one(entry):
            async with semaphore:
                try:
                    manga = await suwayomi.fetchManga(entry['manga_id'])
                except Exception:
                    return
            chapters = list(manga.chapters)
            if not chapters:
                return
            newest = max(chapters, key=lambda chapter: (chapter.chapter_number, chapter.source_order))
            added = history.update_chapters(entry['manga_id'], len(chapters), newest.name)
            if added:
                found.append((entry['title'], added, newest.name))

        try:
            await asyncio.gather(*(one(entry) for entry in history.items()[:MAX_SERIES]))
        finally:
            self.checking = False
            self.last_check = time.time()
        if found:
            self.notify(found)

    def notify(self, found):
        if len(found) == 1:
            title, added, latest = found[0]
            heading = f"Nuevo capítulo de {title}" if added == 1 else f"{added} capítulos nuevos de {title}"
            body = f"Ya salió: {latest}"
        else:
            heading = f"Capítulos nuevos en {len(found)} series"
            body = ", ".join(f"{title} (+{added})" for title, added, _ in found[:4])
            if len(found) > 4:
                body += "…"

        # Only inside Kaori: a toast in the window (the sidebar badge and row tags come from the history)
        window = self.app.get_active_window()
        if window is None or not hasattr(window, "toast_overlay"):
            return
        toast = Adw.Toast(title=f"{heading} · {body}", timeout=10, button_label="Ver", use_markup=False)
        toast.connect("button-clicked", lambda toast: window.main_stack.set_visible_child_name("history"))
        window.toast_overlay.add_toast(toast)
