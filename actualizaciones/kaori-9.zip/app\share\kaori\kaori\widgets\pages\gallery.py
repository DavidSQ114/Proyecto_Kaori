"""Galería: every panel captured while reading, grouped by series (newest capture first)."""
import asyncio
import time
from datetime import datetime

from gi.repository import Adw, Gdk, GdkPixbuf, Gio, GLib, Gtk, Pango

TILE_WIDTH = 190
TILE_HEIGHT = 250
THUMB_SIZE = 380  # px the thumbnails are decoded at (sharp on the tile, light on memory)

_thumbs: dict[str, Gdk.Texture] = {}


def short_chapter(name: str) -> str:
    return (name or "").replace("Capítulo", "Cap.").replace("Capitulo", "Cap.")


def capture_caption(entry: dict) -> str:
    parts = [short_chapter(entry.get('chapter_name')) or "Capítulo desconocido"]
    if entry.get('page'):
        parts.append(f"pág. {entry['page']}")
    return " · ".join(parts)


async def load_thumb(path: str) -> Gdk.Texture | None:
    if path in _thumbs:
        return _thumbs[path]

    def decode():
        return GdkPixbuf.Pixbuf.new_from_file_at_scale(path, THUMB_SIZE, THUMB_SIZE, True)

    try:
        pixbuf = await asyncio.get_running_loop().run_in_executor(None, decode)
    except Exception:
        return None
    texture = Gdk.Texture.new_for_pixbuf(pixbuf)
    _thumbs[path] = texture
    return texture


class CaptureTile(Gtk.Button):
    """One capture: the image cropped to a tile, with chapter and page underneath."""
    __gtype_name__ = "KaoriCaptureTile"

    def __init__(self, entry: dict, show_title=False):
        super().__init__(css_classes=["flat", "capture-tile"], tooltip_text="Ver en grande")
        self.entry = entry
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.picture = Gtk.Picture(content_fit=Gtk.ContentFit.COVER, can_shrink=True, css_classes=["poster"],
                                   width_request=TILE_WIDTH, height_request=TILE_HEIGHT)
        box.append(Adw.Clamp(maximum_size=TILE_WIDTH, tightening_threshold=TILE_WIDTH,
                             child=Adw.Clamp(orientation=Gtk.Orientation.VERTICAL, maximum_size=TILE_HEIGHT,
                                             tightening_threshold=TILE_HEIGHT, child=self.picture)))
        if show_title:
            box.append(Gtk.Label(label=entry['title'], xalign=0, ellipsize=Pango.EllipsizeMode.END,
                                 max_width_chars=1, css_classes=["caption-heading"]))
        box.append(Gtk.Label(label=capture_caption(entry), xalign=0, ellipsize=Pango.EllipsizeMode.END,
                             max_width_chars=1, css_classes=["dim-label", "caption"]))
        self.set_child(box)
        self.connect("clicked", lambda button: CaptureViewer(self.entry).present(self.get_root()))
        asyncio.create_task(self.load())

    async def load(self):
        captures = Gio.Application.get_default().captures
        texture = await load_thumb(captures.path_of(self.entry))
        if texture is not None:
            self.picture.set_paintable(texture)


class CaptureViewer(Adw.Dialog):
    """A capture at full size, with where it came from and what to do with it."""
    __gtype_name__ = "KaoriCaptureViewer"

    def __init__(self, entry: dict):
        super().__init__(title=entry['title'], content_width=900, content_height=860)
        self.entry = entry
        app = Gio.Application.get_default()
        self.captures = app.captures
        self.suwayomi = app.suwayomi
        self.path = self.captures.path_of(entry)
        self.texture = None

        header = Adw.HeaderBar()
        taken = datetime.fromtimestamp(entry['created']).strftime("%d/%m/%Y %H:%M")
        header.set_title_widget(Adw.WindowTitle(title=entry['title'], subtitle=f"{capture_caption(entry)} · {taken}"))

        self.picture = Gtk.Picture(content_fit=Gtk.ContentFit.CONTAIN, can_shrink=True, vexpand=True,
                                   hexpand=True, margin_start=12, margin_end=12, margin_top=6, margin_bottom=6)
        try:
            self.texture = Gdk.Texture.new_from_filename(self.path)
            self.picture.set_paintable(self.texture)
        except GLib.Error:
            self.picture = Adw.StatusPage(icon_name="image-missing-symbolic", title="No se encontró la imagen")

        bar = Gtk.Box(spacing=8, halign=Gtk.Align.CENTER, margin_top=6, margin_bottom=12)
        for label, callback, classes in (("Ir a la página", self.on_open_clicked, ["pill", "suggested-action"]),
                                         ("Copiar", self.on_copy_clicked, ["pill"]),
                                         ("Abrir carpeta", self.on_folder_clicked, ["pill"]),
                                         ("Borrar", self.on_delete_clicked, ["pill", "destructive-action"])):
            button = Gtk.Button(label=label, css_classes=classes)
            button.connect("clicked", callback)
            bar.append(button)

        view = Adw.ToolbarView(content=self.picture)
        view.add_top_bar(header)
        view.add_bottom_bar(bar)
        self.set_child(view)

    def toast(self, message):
        window = Gio.Application.get_default().get_active_window()
        if window is not None:
            window.toast_overlay.dismiss_all()
            window.toast_overlay.add_toast(Adw.Toast(title=message, timeout=2))

    def on_copy_clicked(self, button):
        if self.texture is not None:
            self.get_clipboard().set_texture(self.texture)
            self.toast("Imagen copiada al portapapeles")

    def on_folder_clicked(self, button):
        launcher = Gtk.FileLauncher(file=Gio.File.new_for_path(self.path))
        launcher.open_containing_folder(self.get_root(), None, None)

    def on_delete_clicked(self, button):
        alert = Adw.AlertDialog(heading="¿Borrar esta captura?", body="La imagen se elimina de tu disco.")
        alert.add_response("cancel", "Cancelar")
        alert.add_response("delete", "Borrar")
        alert.set_response_appearance("delete", Adw.ResponseAppearance.DESTRUCTIVE)
        alert.connect("response", self.on_delete_response)
        alert.present(self)

    def on_delete_response(self, alert, response):
        if response == "delete":
            _thumbs.pop(self.path, None)
            self.captures.remove(self.entry['id'])
            self.close()
            self.toast("Captura borrada")

    def on_open_clicked(self, button):
        window = self.get_root()
        self.close()
        asyncio.create_task(open_capture_page(Gio.Application.get_default().get_active_window(), self.entry))


async def open_capture_page(window, entry: dict):
    """Open the reader on the chapter and page a capture was taken from."""
    from ..reader import ReaderPage

    suwayomi = Gio.Application.get_default().suwayomi
    try:
        manga = await suwayomi.getManga(entry['manga_id'])
        chapter = suwayomi.getModel(entry['chapter_id'], 'Chapter')
        if chapter is None:
            manga = await suwayomi.fetchManga(entry['manga_id'])
            chapter = suwayomi.getModel(entry['chapter_id'], 'Chapter')
    except Exception as error:
        window.toast_overlay.add_toast(Adw.Toast(title=f"No se pudo abrir: {error}", timeout=3))
        return
    if chapter is None:
        window.toast_overlay.add_toast(Adw.Toast(title="Ese capítulo ya no existe en la fuente", timeout=3))
        return
    window.chapter_panel.set_manga_model(manga)
    reader = ReaderPage(manga, chapter)
    reader.start_load(chapter, resume_position=max(0, entry.get('page', 1) - 1))
    window.main_nav_view.push(reader)


RECENT = 12  # newest captures shown on top, from any series
ALBUM_TILE = (118, 150)  # each of the 2x2 thumbnails of a series' album
ALBUM_SINGLE = (240, 304)  # an album with a single capture shows it whole


def plural(count: int, word: str) -> str:
    return f"{count} {word}{'s' if count != 1 else ''}"


def tile_grid():
    return Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, homogeneous=True, column_spacing=10,
                       row_spacing=12, max_children_per_line=30, min_children_per_line=1, valign=Gtk.Align.START)


def section_header(title, subtitle):
    box = Gtk.Box(spacing=10)
    box.append(Gtk.Label(label=title, css_classes=["title-3"], xalign=0))
    box.append(Gtk.Label(label=subtitle, css_classes=["dim-label", "caption"], valign=Gtk.Align.BASELINE_CENTER))
    return box


class SeriesAlbum(Gtk.Button):
    """A series in the Galería: its newest captures as a mosaic, its name and how many there are."""
    __gtype_name__ = "KaoriSeriesAlbum"

    def __init__(self, manga_id, entries):
        super().__init__(css_classes=["flat", "gallery-album"], tooltip_text="Ver todas sus capturas")
        self.manga_id = manga_id
        self.entries = entries
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, halign=Gtk.Align.CENTER)
        self.pictures = []
        if len(entries) == 1:
            box.append(self.picture(ALBUM_SINGLE, entries[0]))
        else:
            mosaic = Gtk.Grid(column_spacing=4, row_spacing=4, css_classes=["gallery-mosaic"])
            for index, entry in enumerate(entries[:4]):
                mosaic.attach(self.picture(ALBUM_TILE, entry), index % 2, index // 2, 1, 1)
            box.append(mosaic)
        box.append(Gtk.Label(label=entries[0]['title'], xalign=0, ellipsize=Pango.EllipsizeMode.END,
                             max_width_chars=1, css_classes=["heading"]))
        newest = max(e['created'] for e in entries)
        box.append(Gtk.Label(label=f"{plural(len(entries), 'captura')} · {time_ago(newest)}", xalign=0,
                             css_classes=["dim-label", "caption"]))
        self.set_child(box)
        self.connect("clicked", self.on_clicked)
        asyncio.create_task(self.load())

    def picture(self, size, entry):
        width, height = size
        picture = Gtk.Picture(content_fit=Gtk.ContentFit.COVER, can_shrink=True, css_classes=["poster"],
                              width_request=width, height_request=height)
        self.pictures.append((picture, entry))
        return Adw.Clamp(maximum_size=width, tightening_threshold=width,
                         child=Adw.Clamp(orientation=Gtk.Orientation.VERTICAL, maximum_size=height,
                                         tightening_threshold=height, child=picture))

    async def load(self):
        captures = Gio.Application.get_default().captures
        for picture, entry in self.pictures:
            texture = await load_thumb(captures.path_of(entry))
            if texture is not None:
                picture.set_paintable(texture)

    def on_clicked(self, button):
        nav = self.get_ancestor(Adw.NavigationView)
        if nav is not None:
            nav.push(SeriesCapturesPage(self.manga_id, self.entries[0]['title']))


class SeriesCapturesPage(Adw.NavigationPage):
    """Every capture of one series, in reading order."""
    __gtype_name__ = "KaoriSeriesCapturesPage"

    def __init__(self, manga_id, title):
        super().__init__(title=title)
        self.manga_id = manga_id
        self.captures = Gio.Application.get_default().captures
        self.grid = tile_grid()
        self.grid.set_margin_top(14)
        self.grid.set_margin_bottom(30)
        self.grid.set_margin_start(24)
        self.grid.set_margin_end(24)
        series = Gtk.Button(label="Ver la serie", css_classes=["pill"])
        series.connect("clicked", lambda b: b.activate_action("app.show_manga", GLib.Variant("i", manga_id)))
        header = Adw.HeaderBar()
        header.pack_end(series)
        view = Adw.ToolbarView(content=Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER, child=self.grid))
        view.add_top_bar(header)
        self.set_child(view)
        self.handler = self.captures.connect("changed", self.on_changed)
        self.fill()

    def on_changed(self, captures):
        if self.get_parent() is None:  # already closed (back to the Galería): stop following
            captures.disconnect(self.handler)
            return
        self.fill()

    def fill(self):
        self.grid.remove_all()
        entries = self.captures.for_manga(self.manga_id)
        for entry in entries:
            self.grid.append(CaptureTile(entry))
        if not entries:  # the last one was deleted
            nav = self.get_ancestor(Adw.NavigationView)
            if nav is not None and nav.get_visible_page() is self:
                nav.pop()


class GalleryPage(Adw.NavigationPage):
    __gtype_name__ = "KaoriGalleryPage"

    def __init__(self):
        super().__init__(title="Galería", tag="gallery")
        self.captures = Gio.Application.get_default().captures
        self.dirty = True

        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE)
        self.stack.add_named(Adw.StatusPage(
            icon_name="camera-photo-symbolic", title="Tu Galería está vacía",
            description="Mientras lees, pulsa C (o el botón de cámara) y arrastra sobre una viñeta para guardarla aquí"),
            "empty")
        self.sections = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14,
                                margin_top=14, margin_bottom=30, margin_start=24, margin_end=24)
        self.stack.add_named(Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER, child=self.sections),
                             "content")

        self.summary = Gtk.Label(css_classes=["dim-label"])
        header = Adw.HeaderBar()
        header.pack_end(self.summary)
        view = Adw.ToolbarView(content=self.stack)
        view.add_top_bar(header)
        self.set_child(view)

        self.captures.connect("changed", self.on_changed)
        self.connect("map", lambda page: self.refresh())

    def on_changed(self, captures):
        self.dirty = True
        if self.get_mapped():
            self.refresh()

    def refresh(self):
        if not self.dirty:
            return
        self.dirty = False
        while child := self.sections.get_first_child():
            self.sections.remove(child)

        groups = self.captures.by_series()
        total = sum(len(entries) for _, entries in groups)
        self.summary.set_label(f"{plural(total, 'captura')} · {plural(len(groups), 'serie')}" if total else "")
        self.stack.set_visible_child_name("content" if groups else "empty")
        if not groups:
            return

        # The newest captures, whatever the series
        newest = sorted((e for _, entries in groups for e in entries), key=lambda e: e['created'], reverse=True)
        self.sections.append(section_header("Recientes", "Tus últimas capturas"))
        recent = tile_grid()
        for entry in newest[:RECENT]:
            recent.append(CaptureTile(entry, show_title=True))
        self.sections.append(recent)

        # One album per series
        self.sections.append(section_header("Por serie", "Pulsa una para ver todas sus capturas"))
        albums = tile_grid()
        albums.set_column_spacing(18)
        albums.set_row_spacing(18)
        for manga_id, entries in groups:
            latest_first = sorted(entries, key=lambda e: e['created'], reverse=True)
            albums.append(SeriesAlbum(manga_id, latest_first))
        self.sections.append(albums)


def time_ago(timestamp: float) -> str:
    minutes = int((time.time() - timestamp) // 60)
    if minutes < 1:
        return "ahora"
    if minutes < 60:
        return f"hace {minutes} min"
    if minutes < 1440:
        return f"hace {minutes // 60} h"
    days = minutes // 1440
    return "ayer" if days == 1 else f"hace {days} días"
