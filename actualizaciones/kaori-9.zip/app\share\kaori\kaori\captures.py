"""Galería: panels the user cut out of pages while reading, with where they came from.

Images live in <data>/kaori/capturas/<manga id>/, the index (series, chapter, page, date) in
<data>/kaori/capturas/captures.json. Everything stays inside Kaori's data folder (drive D).
"""
import json
import os
import time

from gi.repository import Gdk, GLib, GObject

JPEG_QUALITY = "92"


class Captures(GObject.Object):
    __gtype_name__ = 'KaoriCaptures'

    @GObject.Signal
    def changed(self):
        pass

    def __init__(self):
        super().__init__()
        self.folder = os.path.join(GLib.get_user_data_dir(), 'kaori', 'capturas')
        self.index_path = os.path.join(self.folder, 'captures.json')
        self.entries: list[dict] = []
        try:
            with open(self.index_path, encoding='utf-8') as file:
                self.entries = json.load(file)
        except (OSError, ValueError):
            self.entries = []

    def path_of(self, entry: dict) -> str:
        return os.path.join(self.folder, entry['file'])

    def add(self, texture: Gdk.Texture, manga, chapter, page: int) -> dict:
        """Save a cut-out as JPEG and remember where it came from (page is 1-based)."""
        created = time.time()
        capture_id = f"{int(created * 1000)}"
        relative = os.path.join(str(manga.id), f"{capture_id}.jpg")
        path = os.path.join(self.folder, relative)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        pixbuf = Gdk.pixbuf_get_from_texture(texture)
        pixbuf.savev(path, "jpeg", ["quality"], [JPEG_QUALITY])

        entry = {
            'id': capture_id,
            'file': relative,
            'manga_id': manga.id,
            'title': manga.title,
            'thumbnail_url': manga.thumbnail_url,
            'chapter_id': chapter.id if chapter else 0,
            'chapter_name': chapter.name if chapter else "",
            'chapter_number': chapter.chapter_number if chapter else 0.0,
            'page': page,
            'width': texture.get_width(),
            'height': texture.get_height(),
            'created': created,
        }
        self.entries.append(entry)
        self.save()
        self.emit('changed')
        return entry

    def remove(self, capture_id: str):
        for entry in [e for e in self.entries if e['id'] == capture_id]:
            try:
                os.remove(self.path_of(entry))
            except OSError:
                pass
            self.entries.remove(entry)
        self.save()
        self.emit('changed')

    def for_manga(self, manga_id: int) -> list[dict]:
        """One series' captures in reading order: by chapter, then page, then when taken."""
        return sorted((e for e in self.entries if e['manga_id'] == manga_id),
                      key=lambda e: (e['chapter_number'], e['page'], e['created']))

    def by_series(self) -> list[tuple[int, list[dict]]]:
        """[(manga id, captures in reading order)], the series with the newest capture first."""
        groups: dict[int, list[dict]] = {}
        for entry in self.entries:
            groups.setdefault(entry['manga_id'], []).append(entry)
        order = sorted(groups, key=lambda mid: max(e['created'] for e in groups[mid]), reverse=True)
        return [(mid, self.for_manga(mid)) for mid in order]

    def save(self):
        os.makedirs(self.folder, exist_ok=True)
        tmp = self.index_path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as file:
            json.dump(self.entries, file, ensure_ascii=False, indent=1)
        os.replace(tmp, self.index_path)
