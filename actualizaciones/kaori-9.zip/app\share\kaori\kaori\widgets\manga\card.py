import asyncio
import weakref

from gi.repository import Gtk, Adw, Gio, GObject

from ...integrations import adult, models

# Every card on screen, to blur / unblur them all when the discreet mode is switched
_cards = weakref.WeakSet()
_settings_handler = None


def _source_name(source_id: str) -> str:
    app = Gio.Application.get_default()
    for source in getattr(getattr(app, "suwayomi", None), "all_sources", []) or []:
        if source.id == source_id:
            return source.name
    return ""


async def _load_stats(suwayomi):
    await adult.load_stats(suwayomi)
    _on_discreet_changed()  # now the sources' share counts too


def _on_discreet_changed(*args):
    for card in list(_cards):
        card.update_discreet()


@Gtk.Template(resource_path='/io/github/riyaniii/Kaori/manga/card.ui')
class MangaCard(Gtk.Box):
    __gtype_name__ = "KaoriMangaCard"

    model = GObject.Property(type=models.Manga)
    show_title = GObject.Property(type=bool, default=True)

    poster = Gtk.Template.Child()

    def __init__(self, model=None, **kwargs):
        super().__init__(**kwargs)
        global _settings_handler
        self.add_css_class("manga-card")
        # The blur of the discreet mode stays inside the cover's rounded corners
        self.poster.get_parent().set_overflow(Gtk.Overflow.HIDDEN)
        # Chapters not read yet, for the series in your library
        self.unread = Gtk.Label(halign=Gtk.Align.END, valign=Gtk.Align.START, margin_top=6, margin_end=6,
                                css_classes=["compare-badge", "sakura", "unread-badge"], visible=False,
                                can_target=False)
        self.poster.get_parent().add_overlay(self.unread)
        self.watched = None
        self.watch_handler = 0
        _cards.add(self)
        app = Gio.Application.get_default()
        if _settings_handler is None and app is not None and hasattr(app, "settings"):
            _settings_handler = app.settings.connect("changed::discreet-mode", _on_discreet_changed)
        self.connect("notify::model", self.on_model_changed)
        if model is not None:
            self.model = model

    def on_model_changed(self, *args):
        if self.watched is not None:
            self.watched.disconnect(self.watch_handler)
            self.watched, self.watch_handler = None, 0
        if self.model is not None:
            self.watched = self.model
            self.watch_handler = self.model.connect("notify", self.on_model_notify)
        self.update_discreet()
        self.update_unread()

    def on_model_notify(self, model, pspec):
        # Genres often arrive later (when the series' details load); the unread count changes as you read
        if pspec.name == "genre":
            self.update_discreet()
        elif pspec.name in ("chapters-ahead", "in-library"):
            self.update_unread()

    def update_unread(self):
        count = self.model.chapters_ahead if self.model is not None and self.model.in_library else 0
        self.unread.set_label(str(count) if count < 100 else "99+")
        self.unread.set_tooltip_text(f"{count} capítulo{'s' if count != 1 else ''} por leer después de donde te quedaste")
        self.unread.set_visible(count > 0)

    def update_discreet(self):
        """Discreet mode: covers of adult series blurred until the pointer is over them."""
        app = Gio.Application.get_default()
        enabled = app is not None and hasattr(app, "settings") and app.settings.get_boolean("discreet-mode")
        if enabled and adult.stats_state == "none" and hasattr(app, "suwayomi"):
            adult.stats_state = "loading"  # once, however many cards ask at the same time
            asyncio.ensure_future(_load_stats(app.suwayomi))
        on = bool(enabled and self.model is not None
                  and adult.is_adult(self.model.title, self.model.genre, _source_name(self.model.source_id),
                                     self.model.source_id))
        if on:
            self.poster.add_css_class("discreet")
        else:
            self.poster.remove_css_class("discreet")
