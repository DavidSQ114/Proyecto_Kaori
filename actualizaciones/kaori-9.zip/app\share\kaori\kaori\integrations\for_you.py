"""'Para ti': recommendations from everything in Tus Lecturas, not just one series.

Every series you read (once identified in AniList) votes for its community recommendations. A vote
weighs more the longer you read that series and if you read it lately, and more readers backing a
recommendation make it stronger. What you already read is left out.
"""
import asyncio
import math
import re
import time

from .compare import plain_ratio

MAX_HOURS = 6  # reading time stops adding weight after this: one binge shouldn't drown the rest
RECENT_DAYS = 14
SAME_TITLE = 0.9


def series_weight(entry: dict) -> float:
    hours = min(entry.get('seconds', 0) / 3600, MAX_HOURS)
    recent = time.time() - entry.get('last_read', 0) < RECENT_DAYS * 86400
    return 1 + hours + (1 if recent else 0)


def adult_ok(entry: dict, mode: str) -> bool:
    if mode == "only":
        return entry.get('adult', False)
    if mode == "no":
        return not entry.get('adult', False)
    return True


def romance_ok(entry: dict, mode: str) -> bool:
    """The BL / GL filter: "all", "no-bl" (no yaoi) or "none" (no yaoi nor yuri)."""
    if mode == "no-bl":
        return not entry.get('bl', False)
    if mode == "none":
        return not (entry.get('bl', False) or entry.get('gl', False))
    return True


async def identify_history(history: list[dict], identity, suwayomi, progress=None) -> list[tuple[dict, dict | None]]:
    """[(history entry, identity or None)], identifying the ones not looked up yet (rate-limited)."""
    try:
        descriptions = await suwayomi.getMangaDescriptions([e['manga_id'] for e in history])
    except Exception:
        descriptions = {}
    results = []
    for index, entry in enumerate(history):
        if progress:
            progress(index, len(history))
        try:
            found = await identity.identify(entry['manga_id'], entry['title'], descriptions.get(entry['manga_id'], ""))
        except Exception:
            found = None
        results.append((entry, found))
    return results


async def recommend(identified: list[tuple[dict, dict | None]], anilist, adult_mode: str) -> list[dict]:
    """Ranked recommendations, each with `reasons`: the titles of your series that led to it."""
    reading = {found['anilist_id'] for _, found in identified if found and found.get('anilist_id')}
    # Series known only by MangaUpdates (no AniList id) are excluded by their English title
    reading_titles = [re.sub(r"\s*\(.*?\)", "", found['title']) for _, found in identified
                      if found and found.get('title')]  # "Brave New World (GOSONJAK)" -> "Brave New World"
    sources = [(entry, found) for entry, found in identified if found and found.get('anilist_id')]

    async def fetch(found):
        try:
            return await anilist.recommendations_for(found['anilist_id'], include_adult=adult_mode != "no")
        except Exception:
            return []

    lists = await asyncio.gather(*(fetch(found) for _, found in sources))
    scores, entries, reasons = {}, {}, {}
    for (entry, _), recs in zip(sources, lists):
        weight = series_weight(entry)
        for rec in recs:
            if rec['id'] in reading or not adult_ok(rec, adult_mode):
                continue
            if any(plain_ratio(rec['title'], title) >= SAME_TITLE for title in reading_titles):
                continue
            scores[rec['id']] = scores.get(rec['id'], 0) + weight * math.log2(2 + max(rec.get('rating', 0), 0))
            entries[rec['id']] = rec
            reasons.setdefault(rec['id'], []).append((weight, entry['title']))

    ranked = []
    for media_id, score in scores.items():
        rec = entries[media_id]
        quality = 0.6 + (rec.get('score') or 60) / 150  # a well-rated series edges out a weak one
        why = [title for _, title in sorted(reasons[media_id], reverse=True)]
        ranked.append({**rec, 'reasons': why, 'points': score * quality})
    ranked.sort(key=lambda rec: rec['points'], reverse=True)
    return ranked


async def trending_korea(anilist, adult_mode: str, reading: set, page: int = 1,
                         country: str = "manhwa") -> tuple[list[dict], bool]:
    """(what's rising right now in a country: "manhwa" Korea, "manga" Japan, "manhua" China or "all";
    more pages?) from AniList trending, minus what you read."""
    try:
        entries, has_next = await anilist.ranking("trending", country, page, adult=adult_mode)
    except Exception:
        return [], False
    return [e for e in entries if e['id'] not in reading], has_next


CREATORS_PER_SERIES = 2  # story + art: one long series shouldn't fill the whole section
WORKS_PER_CREATOR = 10


async def creator_candidates(identified, anilist) -> list[dict]:
    """Everyone who wrote or drew your recognised series, the ones behind what you read most first:
    [{id, weight, because, roles}]."""
    sources = sorted(((entry, found) for entry, found in identified if found and found.get('anilist_id')),
                     key=lambda pair: series_weight(pair[0]), reverse=True)
    people = {}
    for entry, found in sources:
        try:
            staff = await anilist.creators_of(found['anilist_id'])
        except Exception:
            continue
        for person in staff[:CREATORS_PER_SERIES]:
            info = people.setdefault(person['id'], {"id": person['id'], "weight": 0, "because": [], "roles": set()})
            info["weight"] += series_weight(entry)
            info["because"].append(entry['title'])
            info["roles"].add(person['role'])
    return sorted(people.values(), key=lambda info: info["weight"], reverse=True)


async def creator_group(person, identified, anilist, adult_mode: str) -> dict | None:
    """{name, role, because, works, id} for one person, or None when they made nothing else to show."""
    reading = {found['anilist_id'] for _, found in identified if found and found.get('anilist_id')}
    reading_titles = [re.sub(r"\s*\(.*?\)", "", found['title']) for _, found in identified
                      if found and found.get('title')]
    try:
        name, works = await anilist.works_of(person['id'], include_adult=adult_mode != "no")
    except Exception:
        return None
    works = [w for w in works if w['id'] not in reading and adult_ok(w, adult_mode)
             and not any(plain_ratio(w['title'], t) >= SAME_TITLE for t in reading_titles)]
    if not works:
        return None
    return {"name": name, "role": " y ".join(sorted(person["roles"])), "because": person["because"],
            "works": works[:WORKS_PER_CREATOR], "id": person['id']}
