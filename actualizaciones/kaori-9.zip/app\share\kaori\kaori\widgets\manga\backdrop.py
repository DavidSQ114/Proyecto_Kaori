from gi.repository import Gdk, GdkPixbuf, GObject, Graphene, Gsk, Gtk

HEIGHT = 420
BLUR_WIDTH = 20  # px the cover is shrunk to; drawn back up with smoothing it reads as a strong blur


class Backdrop(Gtk.Widget):
    """The series cover, heavily blurred and dimmed, behind the top of the manga page.

    The blur is a tiny copy of the cover stretched with linear filtering: no blur shader, so it costs
    nothing on old GPUs and the result is drawn once and kept.
    """
    __gtype_name__ = "KaoriBackdrop"

    def __init__(self, height=HEIGHT, **kwargs):
        super().__init__(can_target=False, **kwargs)
        self.texture = None
        self.height = height

    def set_paintable(self, paintable):
        self.texture = self.shrink(paintable) if paintable is not None else None
        self.queue_draw()

    @staticmethod
    def shrink(paintable):
        if not isinstance(paintable, Gdk.Texture):
            return None
        width, height = paintable.get_width(), paintable.get_height()
        if not width or not height:
            return None
        pixbuf = Gdk.pixbuf_get_from_texture(paintable)
        if pixbuf is None:
            return None
        small = pixbuf.scale_simple(BLUR_WIDTH, max(1, round(BLUR_WIDTH * height / width)),
                                    GdkPixbuf.InterpType.HYPER)
        return Gdk.Texture.new_for_pixbuf(small)

    def do_measure(self, orientation, for_size):
        if orientation == Gtk.Orientation.VERTICAL:
            return self.height, self.height, -1, -1
        return 0, 0, -1, -1

    def do_snapshot(self, snapshot):
        if self.texture is None:
            return
        width, height = self.get_width(), self.get_height()
        # Cover-fit: fill the width, crop the height around the upper third (where faces usually are)
        ratio = self.texture.get_height() / self.texture.get_width()
        draw_height = max(height, width * ratio)
        offset = -(draw_height - height) / 3
        snapshot.push_clip(Graphene.Rect().init(0, 0, width, height))
        snapshot.push_opacity(0.45)
        snapshot.append_scaled_texture(self.texture, Gsk.ScalingFilter.LINEAR,
                                       Graphene.Rect().init(0, offset, width, draw_height))
        snapshot.pop()
        snapshot.pop()
