"""The chapter list shown right on the manga page: filters, order, and a selection mode for bulk actions."""
import asyncio
import time
from datetime import datetime

from gi.repository import Adw, Gdk, Gio, GLib, Gtk, Pango

PAGE_SIZE = 50  # rows built at a time; "Mostrar más" adds the next batch
FETCH_TOLERANCE = 5  # s between the fetch and a stamped-on date
WATCHED = ("is-read", "is-downloaded", "last-page-read", "is-bookmarked")


def has_real_date(chapter) -> bool:
    """Sources that don't publish dates get the moment the server fetched the chapter list as their
    upload date; a real one is anything else. (Many chapters sharing a date is fine: sites often
    upload a batch the same day.)"""
    if not (chapter.upload_date or "").isdigit():
        return False
    if (chapter.fetched_at or "").isdigit():
        return abs(int(chapter.upload_date) / 1000 - int(chapter.fetched_at)) >= FETCH_TOLERANCE
    return True


def real_dates(chapters) -> list[int]:
    """Upload dates (ms) that the source really published."""
    return [int(c.upload_date) for c in chapters if has_real_date(c)]


def format_date(upload_date: str) -> str:
    if not upload_date:
        return ""
    try:
        timestamp = int(upload_date) / 1000
    except ValueError:
        return ""
    days = int((time.time() - timestamp) // 86400)
    if days <= 0:
        return "hoy"
    if days == 1:
        return "ayer"
    if days < 7:
        return f"hace {days} días"
    return datetime.fromtimestamp(timestamp).strftime("%d/%m/%Y")


class ChapterItem(Gtk.ListBoxRow):
    __gtype_name__ = "KaoriChapterItem"

    def __init__(self, chapter, chapter_list):
        super().__init__(css_classes=["chapter-item"])
        self.chapter = chapter
        self.list = chapter_list

        box = Gtk.Box(spacing=12, margin_top=8, margin_bottom=8, margin_start=12, margin_end=12)
        self.check = Gtk.CheckButton(valign=Gtk.Align.CENTER, can_target=False)
        box.append(self.check)

        info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, hexpand=True, valign=Gtk.Align.CENTER)
        top = Gtk.Box(spacing=8)
        self.name = Gtk.Label(xalign=0, ellipsize=Pango.EllipsizeMode.END, css_classes=["chapter-name"])
        top.append(self.name)
        self.new_badge = Gtk.Label(label="NUEVO", css_classes=["chapter-badge", "new"], valign=Gtk.Align.CENTER)
        top.append(self.new_badge)
        self.here_badge = Gtk.Label(label="AQUÍ VAS", css_classes=["chapter-badge", "here"], valign=Gtk.Align.CENTER)
        top.append(self.here_badge)
        info.append(top)

        self.progress = Gtk.ProgressBar(css_classes=["chapter-progress"], valign=Gtk.Align.CENTER)
        info.append(self.progress)
        box.append(info)

        self.pages = Gtk.Label(css_classes=["dim-label", "caption"], valign=Gtk.Align.CENTER)
        box.append(self.pages)
        self.date = Gtk.Label(css_classes=["dim-label", "caption"], width_chars=10, xalign=1,
                              valign=Gtk.Align.CENTER)
        box.append(self.date)
        self.bookmark = Gtk.Image(icon_name="starred-symbolic", tooltip_text="En marcadores")
        box.append(self.bookmark)
        self.downloaded = Gtk.Image(icon_name="folder-download-symbolic", tooltip_text="Descargado",
                                    css_classes=["chapter-downloaded"])
        box.append(self.downloaded)
        self.read_mark = Gtk.Image(icon_name="object-select-symbolic", tooltip_text="Leído",
                                   css_classes=["chapter-read"])
        box.append(self.read_mark)
        self.set_child(box)

        # Right click: the same actions as the selection bar, for this chapter alone
        actions = Gio.SimpleActionGroup()
        for name, callback in (("read", lambda *_: self.list.mark([self.chapter], True)),
                               ("unread", lambda *_: self.list.mark([self.chapter], False)),
                               ("download", lambda *_: self.list.download([self.chapter])),
                               ("delete", lambda *_: self.list.delete_download(self.chapter)),
                               ("from_here", lambda *_: self.list.mark_previous(self.chapter))):
            action = Gio.SimpleAction.new(name, None)
            action.connect("activate", callback)
            actions.add_action(action)
        self.insert_action_group("row", actions)
        self.actions = actions
        click = Gtk.GestureClick(button=Gdk.BUTTON_SECONDARY)
        click.connect("pressed", self.on_right_click)
        self.add_controller(click)

        self.handlers = [chapter.connect(f"notify::{name}", lambda *_: self.update()) for name in WATCHED]
        self.update()

    def disconnect_model(self):
        for handler in self.handlers:
            self.chapter.disconnect(handler)
        self.handlers = []

    def update(self):
        chapter = self.chapter
        self.name.set_label(chapter.name)
        self.name.set_tooltip_text(chapter.name)
        self.date.set_label(format_date(chapter.upload_date) if has_real_date(chapter) else "")
        reading = not chapter.is_read and chapter.last_page_read > 0 and chapter.page_count > 0
        self.progress.set_visible(reading)
        if reading:
            self.progress.set_fraction(min(chapter.last_page_read / chapter.page_count, 1.0))
        self.pages.set_label(f"{chapter.last_page_read}/{chapter.page_count}" if reading else "")
        self.pages.set_visible(reading)
        self.bookmark.set_visible(chapter.is_bookmarked)
        self.downloaded.set_visible(chapter.is_downloaded)
        self.read_mark.set_visible(chapter.is_read)
        self.new_badge.set_visible(chapter.id in self.list.new_ids)
        current = chapter.id == self.list.current_id
        self.here_badge.set_visible(current)
        for name, on in (("read", chapter.is_read), ("current", current)):
            if on:
                self.add_css_class(name)
            else:
                self.remove_css_class(name)

    def update_selection(self):
        self.check.set_visible(self.list.selecting)
        self.check.set_active(self.chapter.id in self.list.selected)

    def on_right_click(self, gesture, n_press, x, y):
        chapter = self.chapter
        self.actions.lookup_action("read").set_enabled(not chapter.is_read)
        self.actions.lookup_action("unread").set_enabled(chapter.is_read)
        self.actions.lookup_action("download").set_enabled(not chapter.is_downloaded)
        self.actions.lookup_action("delete").set_enabled(chapter.is_downloaded)
        menu = Gio.Menu()
        menu.append("Marcar como leído", "row.read")
        menu.append("Marcar como no leído", "row.unread")
        menu.append("Marcar leídos hasta aquí", "row.from_here")
        downloads = Gio.Menu()
        downloads.append("Descargar", "row.download")
        downloads.append("Borrar descarga", "row.delete")
        menu.append_section(None, downloads)
        popover = Gtk.PopoverMenu.new_from_model(menu)
        popover.set_has_arrow(False)
        popover.set_parent(self)
        rect = Gdk.Rectangle()
        rect.x, rect.y, rect.width, rect.height = int(x), int(y), 1, 1
        popover.set_pointing_to(rect)
        popover.connect("closed", lambda p: GLib.idle_add(p.unparent))
        popover.popup()


class ChapterList(Gtk.Box):
    """Every chapter of the series, under the synopsis. Needs the MangaPage for opening chapters."""
    __gtype_name__ = "KaoriChapterList"

    def __init__(self, page):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.page = page
        self.suwayomi = page.suwayomi
        self.descending = True
        self.selecting = False
        self.selected = set()
        self.new_ids = set()
        self.current_id = None
        self.shown = PAGE_SIZE
        self.rows = []
        self.refresh_id = 0

        # Header: title + count, filter, order, select
        header = Gtk.Box(spacing=10)
        header.append(Gtk.Label(label="Capítulos", css_classes=["title-4"]))
        self.count = Gtk.Label(css_classes=["dim-label"], hexpand=True, xalign=0)
        header.append(self.count)
        self.filter = Adw.ToggleGroup(css_classes=["round"])
        for name, label in (("all", "Todos"), ("unread", "Sin leer"), ("downloaded", "Descargados")):
            self.filter.add(Adw.Toggle(name=name, label=label))
        self.filter.set_active_name("all")
        self.filter.connect("notify::active-name", lambda *_: self.rebuild(reset=True))
        header.append(self.filter)
        self.order = Gtk.Button(css_classes=["flat"])
        self.order.connect("clicked", self.on_order_clicked)
        header.append(self.order)
        self.select_button = Gtk.ToggleButton(label="Seleccionar", css_classes=["flat"])
        self.select_button.connect("toggled", self.on_select_toggled)
        header.append(self.select_button)
        self.append(header)

        # Selection bar, only while selecting
        bar = Gtk.Box(spacing=8, css_classes=["selection-bar"])
        self.selection_label = Gtk.Label(hexpand=True, xalign=0, margin_start=6)
        bar.append(self.selection_label)
        for label, callback, classes in (
                ("Todo", self.on_select_all, ["flat"]),
                ("Marcar leídos", lambda *_: self.mark(self.selected_chapters(), True), []),
                ("Marcar no leídos", lambda *_: self.mark(self.selected_chapters(), False), []),
                ("Descargar", lambda *_: self.download(self.selected_chapters()), ["suggested-action"])):
            button = Gtk.Button(label=label, css_classes=classes)
            button.connect("clicked", callback)
            bar.append(button)
        self.selection_revealer = Gtk.Revealer(child=bar)
        self.append(self.selection_revealer)

        self.listbox = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE, css_classes=["chapter-list"])
        self.listbox.connect("row-activated", self.on_row_activated)
        self.append(self.listbox)
        self.empty = Gtk.Label(label="Cargando capítulos…", css_classes=["dim-label"], margin_top=12,
                               margin_bottom=12, wrap=True, justify=Gtk.Justification.CENTER)
        self.append(self.empty)
        # When the site wouldn't give the chapters: why, and try again
        self.load_error = None
        self.retry = Gtk.Button(label="Reintentar", halign=Gtk.Align.CENTER, visible=False,
                                css_classes=["pill", "suggested-action"])
        self.retry.connect("clicked", self.on_retry_clicked)
        self.retry_callback = None
        self.append(self.retry)
        self.more = Gtk.Button(label="Mostrar más", halign=Gtk.Align.CENTER, css_classes=["pill"])
        self.more.connect("clicked", self.on_more_clicked)
        self.append(self.more)

        self.chapters_handler = 0
        self.update_order_button()

    def connect_model(self):
        if not self.chapters_handler:
            self.chapters_handler = self.page.model.chapters.connect("items-changed",
                                                                     lambda *_: self.queue_rebuild())
        self.rebuild()

    def disconnect_model(self):
        if self.chapters_handler:
            self.page.model.chapters.disconnect(self.chapters_handler)
            self.chapters_handler = 0
        for row in self.rows:
            row.disconnect_model()

    # --- building ---

    def sorted_chapters(self) -> list:
        chapters = sorted(self.page.model.chapters or [], key=lambda c: (c.chapter_number, c.source_order))
        return chapters[::-1] if self.descending else chapters

    def visible_chapters(self) -> list:
        mode = self.filter.get_active_name()
        chapters = self.sorted_chapters()
        if mode == "unread":
            chapters = [c for c in chapters if not c.is_read]
        elif mode == "downloaded":
            chapters = [c for c in chapters if c.is_downloaded]
        return chapters

    def queue_rebuild(self):
        # The list arrives as one items-changed per batch; rebuild once they settle
        if not self.refresh_id:
            self.refresh_id = GLib.idle_add(self.rebuild)

    def rebuild(self, reset=False):
        self.refresh_id = 0
        if reset:
            self.shown = PAGE_SIZE
        for row in self.rows:
            row.disconnect_model()
            self.listbox.remove(row)
        self.rows = []

        everything = self.sorted_chapters()
        entry = self.page.history.entries.get(str(self.page.model.id)) or {}
        newest = sorted(everything, key=lambda c: (c.chapter_number, c.source_order))
        new = entry.get('new_chapters', 0)
        self.new_ids = {c.id for c in newest[-new:]} if new else set()
        point = self.page.resume_point()
        self.current_id = point[0].id if point else None

        chapters = self.visible_chapters()
        for chapter in chapters[:self.shown]:
            row = ChapterItem(chapter, self)
            row.update_selection()
            self.listbox.append(row)
            self.rows.append(row)

        read = sum(1 for c in everything if c.is_read)
        self.count.set_label(f"{len(everything)} · {read} leídos" if everything else "")
        self.listbox.set_visible(bool(chapters))
        self.empty.set_visible(not chapters)
        if not chapters:
            mode = self.filter.get_active_name()
            self.empty.set_label((self.load_error or "Cargando capítulos…") if not everything else
                                 {"unread": "Ya leíste todos los capítulos",
                                  "downloaded": "Aún no descargaste capítulos"}.get(mode, ""))
        remaining = len(chapters) - self.shown
        self.more.set_visible(remaining > 0)
        if remaining > 0:
            self.more.set_label(f"Mostrar más ({remaining} restantes)")
        self.update_selection_label()
        return GLib.SOURCE_REMOVE

    def on_more_clicked(self, button):
        self.shown += PAGE_SIZE * 2
        self.rebuild()

    def set_load_error(self, text, retry=None):
        """Why the chapters didn't load (None: they did, or are loading again)."""
        self.load_error = text
        self.retry_callback = retry
        self.retry.set_visible(retry is not None)
        if text is not None and not getattr(self, "rows", None):  # no chapter shown yet
            self.empty.set_label(text)
            self.empty.set_visible(True)

    def on_retry_clicked(self, button):
        callback = self.retry_callback
        self.set_load_error("Cargando capítulos…")
        if callback is not None:
            callback()

    def update_order_button(self):
        self.order.set_icon_name("view-sort-descending-symbolic" if self.descending else
                                 "view-sort-ascending-symbolic")
        self.order.set_tooltip_text("Más recientes primero" if self.descending else "Desde el primero")

    def on_order_clicked(self, button):
        self.descending = not self.descending
        self.update_order_button()
        self.rebuild(reset=True)

    # --- selection ---

    def on_select_toggled(self, button):
        self.selecting = button.get_active()
        if not self.selecting:
            self.selected.clear()
        self.selection_revealer.set_reveal_child(self.selecting)
        for row in self.rows:
            row.update_selection()
        self.update_selection_label()

    def on_select_all(self, *args):
        visible = {c.id for c in self.visible_chapters()}
        self.selected = set() if visible <= self.selected else visible
        for row in self.rows:
            row.update_selection()
        self.update_selection_label()

    def update_selection_label(self):
        n = len(self.selected)
        self.selection_label.set_label(f"{n} seleccionado{'s' if n != 1 else ''}" if n else
                                       "Toca los capítulos para elegirlos")

    def selected_chapters(self) -> list:
        return [c for c in self.sorted_chapters() if c.id in self.selected]

    def end_selection(self):
        self.select_button.set_active(False)

    def on_row_activated(self, listbox, row):
        chapter = row.chapter
        if self.selecting:
            self.selected.symmetric_difference_update({chapter.id})
            row.update_selection()
            self.update_selection_label()
            return
        partial = not chapter.is_read and chapter.last_page_read > 0
        self.page.open_chapter(chapter, chapter.last_page_read - 1 if partial else 0)

    # --- actions ---

    def toast(self, message, downloads=False):
        window = self.get_root()
        if window is None:
            return
        toast = Adw.Toast(title=message, timeout=3, use_markup=False)
        if downloads:
            toast.set_button_label("Ver")
            toast.set_action_name("app.open_downloads_page")
        window.toast_overlay.dismiss_all()
        window.toast_overlay.add_toast(toast)

    def mark(self, chapters, read: bool):
        chapters = [c for c in chapters if c.is_read != read]
        if chapters:
            asyncio.create_task(self.run_mark(chapters, read))
        self.end_selection()

    def mark_previous(self, chapter):
        """Everything up to this chapter (in reading order) as read."""
        earlier = [c for c in self.sorted_chapters()
                   if (c.chapter_number, c.source_order) <= (chapter.chapter_number, chapter.source_order)]
        self.mark(earlier, True)

    async def run_mark(self, chapters, read):
        try:
            await self.suwayomi.updateChapters([c.id for c in chapters], read)
        except Exception:
            self.toast("No se pudieron actualizar los capítulos")
            return
        n = len(chapters)
        self.toast(f"{n} capítulo{'s' if n != 1 else ''} marcado{'s' if n != 1 else ''} como "
                   f"{'leído' if read else 'no leído'}{'s' if n != 1 else ''}")
        self.rebuild()

    def download(self, chapters):
        chapters = [c for c in chapters if not c.is_downloaded]
        self.end_selection()
        if not chapters:
            self.toast("Esos capítulos ya están descargados")
            return
        asyncio.create_task(self.run_download(chapters))

    async def run_download(self, chapters):
        try:
            await self.suwayomi.enqueueChapterDownloads([c.id for c in chapters])
        except Exception:
            self.toast("No se pudo iniciar la descarga")
            return
        n = len(chapters)
        self.toast(f"Descargando {n} capítulo{'s' if n != 1 else ''}", downloads=True)

    def delete_download(self, chapter):
        self.activate_action("app.delete_chapter_download", GLib.Variant("i", chapter.id))
