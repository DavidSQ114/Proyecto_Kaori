import asyncio
import time

from gi.repository import Adw, Gdk, Gio, GLib, Gtk, Pango

HERO_COVER = (150, 220)
TILE_COVER = (160, 235)
DAY = 86400


def format_duration(seconds: float) -> str:
    minutes = int(seconds // 60)
    if minutes < 1:
        return "menos de 1 min"
    hours, minutes = divmod(minutes, 60)
    return f"{hours} h {minutes} min" if hours else f"{minutes} min"


def format_ago(timestamp: float) -> str:
    seconds = max(0, time.time() - timestamp)
    if seconds < 60:
        return "ahora"
    if seconds < 3600:
        return f"hace {int(seconds // 60)} min"
    if seconds < DAY:
        return f"hace {int(seconds // 3600)} h"
    days = int(seconds // DAY)
    return "ayer" if days == 1 else f"hace {days} días"


def progress(entry) -> float:
    page, count = entry.get('page', 0), entry.get('page_count', 0)
    return min(page / count, 1.0) if count else 0.0


def position_text(entry, short=False) -> str:
    page, count = entry.get('page', 0), entry.get('page_count', 0)
    chapter = entry.get('chapter_name', '')
    if short:
        chapter = chapter.replace("Capítulo", "Cap.").replace("Capitulo", "Cap.")
        return f"{chapter} · {page}/{count}" if count else f"{chapter} · pág. {page}"
    return f"{chapter} · Página {page} de {count}" if count else f"{chapter} · Página {page}"


def new_text(new: int) -> str:
    return "1 capítulo nuevo" if new == 1 else f"{new} capítulos nuevos"


def fixed_cover(size, *classes):
    """A Picture that keeps exactly `size`, whatever the image's natural size."""
    width, height = size
    picture = Gtk.Picture(content_fit=Gtk.ContentFit.COVER, can_shrink=True,
                          width_request=width, height_request=height, css_classes=["poster", *classes])
    frame = Adw.Clamp(maximum_size=width, tightening_threshold=width,
                      child=Adw.Clamp(orientation=Gtk.Orientation.VERTICAL, maximum_size=height,
                                      tightening_threshold=height, child=picture))
    return picture, frame


def section_name(entry) -> str:
    if entry.get('new_chapters', 0):
        return "Con capítulos nuevos"
    start_of_today = time.mktime(time.localtime()[:3] + (0, 0, 0, 0, 0, -1))
    last = entry['last_read']
    if last >= start_of_today:
        return "Hoy"
    if last >= start_of_today - 6 * DAY:
        return "Esta semana"
    if last >= start_of_today - 29 * DAY:
        return "Este mes"
    return "Antes"


SECTION_ORDER = ["Con capítulos nuevos", "Hoy", "Esta semana", "Este mes", "Antes"]


def series_link(entry, label: Gtk.Label) -> Gtk.Button:
    """The series name as a link to its page (synopsis, chapters, captures); the rest of the card
    still continues reading."""
    button = Gtk.Button(child=label, css_classes=["flat", "series-link"], halign=Gtk.Align.START,
                        tooltip_text="Ver la serie")
    button.set_cursor_from_name("pointer")
    button.connect("clicked", lambda button: button.activate_action("app.show_manga",
                                                                    GLib.Variant("i", entry['manga_id'])))
    return button


class HistoryTile(Gtk.FlowBoxChild):
    """Steam-library style card: cover with a thin progress bar on it, title and chapter below."""
    __gtype_name__ = "KaoriHistoryTile"

    def __init__(self, entry: dict, page):
        super().__init__()
        self.entry = entry
        self.set_tooltip_text(
            f"{entry['title']}\n{position_text(entry)}\n"
            f"Leído {format_duration(entry.get('seconds', 0))} · {format_ago(entry['last_read'])}\n"
            "Clic: continuar · Clic en el nombre: ver la serie · Clic derecho: más opciones")

        width = TILE_COVER[0]
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, width_request=width,
                      halign=Gtk.Align.CENTER, valign=Gtk.Align.START, margin_top=4, margin_bottom=4)

        self.cover, frame = fixed_cover(TILE_COVER)
        overlay = Gtk.Overlay(child=frame)
        if entry.get('page_count'):
            overlay.add_overlay(Gtk.ProgressBar(fraction=progress(entry), valign=Gtk.Align.END,
                                                css_classes=["tile-progress"]))
        if new := entry.get('new_chapters', 0):
            overlay.add_overlay(Gtk.Label(label=f"+{new}", halign=Gtk.Align.END, valign=Gtk.Align.START,
                                          tooltip_text=new_text(new), css_classes=["rank-badge", "new-badge"]))
        box.append(overlay)

        box.append(series_link(entry, Gtk.Label(label=entry['title'], xalign=0, wrap=True, lines=2,
                                                max_width_chars=1, ellipsize=Pango.EllipsizeMode.END,
                                                css_classes=["heading"])))
        box.append(Gtk.Label(label=position_text(entry, short=True), xalign=0, max_width_chars=1,
                             ellipsize=Pango.EllipsizeMode.END, css_classes=["dim-label", "caption"]))
        self.set_child(box)

        menu = Gtk.GestureClick(button=Gdk.BUTTON_SECONDARY)
        menu.connect("pressed", lambda gesture, n, x, y: page.show_tile_menu(self, x, y))
        self.add_controller(menu)

    async def load_cover(self, suwayomi):
        await load_cover(self.cover, self.entry, suwayomi)


async def load_cover(picture, entry, suwayomi):
    from ..containers import covers
    try:
        picture.set_paintable(await covers.load(suwayomi, entry['manga_id'], entry.get('thumbnail_url'), identify=True))
    except Exception:
        pass  # missing covers keep the placeholder background


@Gtk.Template(resource_path='/io/github/riyaniii/Kaori/pages/history.ui')
class HistoryPage(Adw.NavigationPage):
    __gtype_name__ = "KaoriHistoryPage"

    stack = Gtk.Template.Child()
    scrolled = Gtk.Template.Child()
    hero = Gtk.Template.Child()
    sections = Gtk.Template.Child()
    check_button = Gtk.Template.Child()
    check_label = Gtk.Template.Child()

    def __init__(self):
        super().__init__()
        app = Gio.Application.get_default()
        self.suwayomi = app.suwayomi
        self.history = app.history
        self.updates = app.updates
        self.dirty = True
        self.tasks = []

        self.history.connect("changed", self.on_history_changed)
        self.updates.connect("notify::checking", self.update_check_status)
        self.updates.connect("notify::last-check", self.update_check_status)
        self.connect("realize", lambda page: self.update_badge())
        self.update_check_status()
        self.connect("map", lambda page: self.refresh())
        # Keep the "hace X min" texts fresh while the page is visible
        GLib.timeout_add_seconds(60, self.on_minute)

    def on_history_changed(self, history):
        self.dirty = True
        self.update_badge()
        if self.get_mapped():
            self.refresh()

    def update_badge(self):
        """Number of new chapters next to "Tus Lecturas" in the sidebar."""
        window = self.get_root()
        if window is None or not hasattr(window, "main_stack"):
            return
        page = window.main_stack.get_page(window.main_stack.get_child_by_name("history"))
        total = self.history.total_new()
        page.set_badge_number(total)
        page.set_needs_attention(total > 0)

    def update_check_status(self, *args):
        if self.updates.checking:
            self.check_button.set_sensitive(False)
            self.check_label.set_label("Buscando capítulos nuevos…")
            return
        self.check_button.set_sensitive(True)
        if self.updates.last_check:
            self.check_label.set_label(f"Última revisión: {format_ago(self.updates.last_check)} · "
                                       "Kaori revisa sola cada pocas horas mientras está abierta")
        else:
            self.check_label.set_label("Kaori buscará capítulos nuevos de tus lecturas en unos minutos")

    @Gtk.Template.Callback()
    def on_check_clicked(self, button):
        self.updates.check_now()

    def on_minute(self):
        if self.get_mapped():
            self.dirty = True
            self.refresh()
            self.update_check_status()
        return GLib.SOURCE_CONTINUE

    def refresh(self):
        if not self.dirty:
            return
        self.dirty = False
        for task in self.tasks:
            task.cancel()
        self.tasks = []
        scroll = self.scrolled.get_vadjustment().get_value()  # rebuilding shouldn't jump to the top

        for container in (self.hero, self.sections):
            while child := container.get_first_child():
                container.remove(child)

        entries = self.history.items()  # most recently read first
        self.stack.set_visible_child_name("list" if entries else "empty")
        if not entries:
            return

        self.build_hero(entries[0])
        groups = {}
        for entry in entries[1:]:
            groups.setdefault(section_name(entry), []).append(entry)
        for name in SECTION_ORDER:
            if name in groups:
                self.build_section(name, groups[name])

        GLib.idle_add(lambda: self.scrolled.get_vadjustment().set_value(scroll) and False)

    def build_hero(self, entry):
        cover, frame = fixed_cover(HERO_COVER)
        frame.set_valign(Gtk.Align.START)
        self.hero.append(frame)
        self.tasks.append(asyncio.create_task(load_cover(cover, entry, self.suwayomi)))

        info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, hexpand=True,
                       valign=Gtk.Align.CENTER, margin_start=20)
        info.append(Gtk.Label(label="CONTINUAR LEYENDO", xalign=0, css_classes=["dim-label", "caption-heading"]))
        info.append(series_link(entry, Gtk.Label(label=entry['title'], xalign=0, wrap=True,
                                                 css_classes=["title-1"])))
        if new := entry.get('new_chapters', 0):
            badge = Gtk.Label(label=new_text(new), halign=Gtk.Align.START, css_classes=["compare-badge", "sakura"])
            info.append(badge)
        info.append(Gtk.Label(label=position_text(entry), xalign=0, css_classes=["title-4"]))
        if entry.get('page_count'):
            info.append(Gtk.ProgressBar(fraction=progress(entry), hexpand=False, width_request=360,
                                        halign=Gtk.Align.START))
        info.append(Gtk.Label(
            label=f"Leído {format_duration(entry.get('seconds', 0))} en total · {format_ago(entry['last_read'])}",
            xalign=0, css_classes=["dim-label"]))

        button = Gtk.Button(label="▶  Continuar", halign=Gtk.Align.START, margin_top=6,
                            css_classes=["pill", "suggested-action"])
        button.connect("clicked", lambda button: asyncio.create_task(self.open_entry(entry)))
        info.append(button)
        self.hero.append(info)

    def build_section(self, name, entries):
        title = Gtk.Box(spacing=8)
        title.append(Gtk.Label(label=name, xalign=0, css_classes=["title-3"]))
        title.append(Gtk.Label(label=str(len(entries)), css_classes=["dim-label"]))
        self.sections.append(title)

        grid = Gtk.FlowBox(homogeneous=True, min_children_per_line=2, max_children_per_line=12,
                           column_spacing=10, row_spacing=14, selection_mode=Gtk.SelectionMode.NONE,
                           activate_on_single_click=True, valign=Gtk.Align.START)
        grid.connect("child-activated", lambda box, tile: asyncio.create_task(self.open_entry(tile.entry)))
        for entry in entries:
            tile = HistoryTile(entry, self)
            grid.append(tile)
            self.tasks.append(asyncio.create_task(tile.load_cover(self.suwayomi)))
        self.sections.append(grid)

    def show_tile_menu(self, tile, x, y):
        popover = Gtk.Popover(has_arrow=True)
        popover.set_parent(tile)
        rect = Gdk.Rectangle()
        rect.x, rect.y, rect.width, rect.height = int(x), int(y), 1, 1
        popover.set_pointing_to(rect)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        actions = [
            ("Continuar leyendo", lambda: asyncio.create_task(self.open_entry(tile.entry))),
            ("Ver capítulos", lambda: tile.activate_action("app.show_manga",
                                                           GLib.Variant("i", tile.entry['manga_id']))),
            ("Quitar de Tus Lecturas", lambda: self.on_remove(tile.entry)),
        ]
        for label, callback in actions:
            button = Gtk.Button(label=label, css_classes=["flat"])
            button.get_child().set_xalign(0)
            button.connect("clicked", lambda button, callback=callback: (popover.popdown(), callback()))
            box.append(button)
        popover.set_child(box)
        popover.connect("closed", lambda popover: GLib.idle_add(popover.unparent))
        popover.popup()

    def on_remove(self, entry):
        self.history.remove(entry['manga_id'])
        self.history.flush()

    async def open_entry(self, entry):
        from ..reader import ReaderPage

        window = self.get_root()
        try:
            manga = await self.suwayomi.getManga(entry['manga_id'])
            chapter = self.suwayomi.getModel(entry['chapter_id'], 'Chapter')
            if chapter is None:  # chapter list not loaded yet (e.g. manga cached without chapters)
                manga = await self.suwayomi.fetchManga(entry['manga_id'])
                chapter = self.suwayomi.getModel(entry['chapter_id'], 'Chapter')
        except Exception as error:
            window.toast_overlay.add_toast(Adw.Toast(title=f"No se pudo abrir: {error}", timeout=3))
            return
        if chapter is None:
            window.toast_overlay.add_toast(Adw.Toast(title="Ese capítulo ya no existe en la fuente", timeout=3))
            return
        self.history.mark_seen(entry['manga_id'])
        window.chapter_panel.set_manga_model(manga)
        reader = ReaderPage(manga, chapter)
        # Resume at the page saved in the history (the server only knows the furthest page read)
        reader.start_load(chapter, resume_position=max(0, entry.get('page', 1) - 1))
        window.main_nav_view.push(reader)
