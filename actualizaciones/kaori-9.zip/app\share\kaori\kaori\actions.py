from gi.repository import Adw

from kaori.widgets.reader.page import ReaderPage

from . import widgets as Widgets


def get_window(app):
    return app.get_active_window()


def switch_page(app, name: str):
    get_window(app).main_stack.set_visible_child_name(name)


def open_search_page(app):
    switch_page(app, 'search')


def open_downloads_page(app):
    switch_page(app, 'downloads')


def open_gallery(app):
    window = get_window(app)
    # Coming from the reader's "Ver": leave the reader so the Galería isn't hidden behind it
    nav = window.main_nav_view
    nav.pop_to_page(nav.get_navigation_stack().get_item(0))
    switch_page(app, 'gallery')
    gallery_nav = window.main_stack.get_child_by_name('gallery')
    gallery_nav.pop_to_page(gallery_nav.get_navigation_stack().get_item(0))


def open_library_page(app):
    switch_page(app, 'library')


def show_page(app, page: Adw.NavigationPage):
    get_window(app).main_stack.get_visible_child().push(page)


def show_dialog(app, dialog: Adw.Dialog):
    dialog.present(get_window(app))


def show_toast(app, message: str):
    toast_overlay = get_window(app).toast_overlay
    toast_overlay.dismiss_all()
    toast_overlay.add_toast(Adw.Toast(title=message, timeout=1, use_markup=False))


def toggle_chapter_panel(app):
    window = get_window(app)
    stack_page = window.main_stack.get_visible_child().get_visible_page()
    reader_page = window.main_nav_view.get_visible_page()

    if not (isinstance(stack_page, Widgets.manga.MangaPage) or isinstance(reader_page, ReaderPage)):
        return

    split_view = window.overlay_split_view
    split_view.set_show_sidebar(not split_view.get_show_sidebar())


async def set_chapters(app, manga_id: int):
    model = app.suwayomi.getModel(manga_id, 'Manga')
    get_window(app).chapter_panel.set_manga_model(model)


async def show_reader(app, manga_id: int, chapter_id: int):
    manga_model = app.suwayomi.getModel(manga_id, 'Manga')
    chapter_model = app.suwayomi.getModel(chapter_id, 'Chapter')
    get_window(app).main_nav_view.push(ReaderPage(manga_model, chapter_model))


async def show_extension(app, pkg_name: str):
    model = app.suwayomi.getModel(pkg_name, 'Extension')
    show_dialog(app, Widgets.extension.ExtensionDialog(model))


async def show_source(app, source_id: str):
    model = app.suwayomi.getModel(source_id, 'Source')
    show_page(app, Widgets.source.SourcePage(model))


async def show_manga(app, manga_id: int):
    model = app.suwayomi.getModel(manga_id, 'Manga')
    if model is None:
        # Not loaded this session (e.g. opened from Tus Lecturas or the Galería): ask the server first
        show_toast(app, "Cargando la serie…")
        try:
            model = await app.suwayomi.getManga(manga_id)
        except Exception as error:
            show_toast(app, f"No se pudo abrir la serie: {error}")
            return
    show_page(app, Widgets.manga.MangaPage(model))


async def extension_action(app, pkg_name: str):
    suwayomi = app.suwayomi
    model = suwayomi.getModel(pkg_name, 'Extension')

    if model.has_update:
        await suwayomi.updateExtension(model.pkg_name)
    elif model.is_installed:
        await suwayomi.uninstallExtension(model.pkg_name)
    else:
        await suwayomi.installExtension(model.pkg_name)


async def toggle_library(app, manga_id: int):
    model = app.suwayomi.getModel(manga_id, 'Manga')
    was_in_library = model.in_library

    await app.suwayomi.setMangaLibrary(model.id, not was_in_library)

    show_toast(app, f"{model.title}: " + ("quitada de la biblioteca" if was_in_library else "añadida a la biblioteca"))


async def download_chapter(app, chapter_id: int):
    model = app.suwayomi.getModel(chapter_id, 'Chapter')
    await app.suwayomi.enqueueChapterDownload(chapter_id)
    show_toast(app, f"Descargando {model.name}")


async def delete_chapter_download(app, chapter_id: int):
    model = app.suwayomi.getModel(chapter_id, 'Chapter')
    await app.suwayomi.deleteDownloadedChapter(chapter_id)
    show_toast(app, f"Descarga borrada: {model.name}")
