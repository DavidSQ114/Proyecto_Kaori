"""What AniList knows about a series, in Spanish, for the sources that leave the page empty: the
synopsis (machine-translated with MyMemory, free and keyless), its genres, score and years.

Translations are cached per series in <cache>/kaori/synopsis.json: one lookup per series, ever.
"""
import html
import json
import os
import re

import httpx
from gi.repository import GLib

TRANSLATE_URL = "https://api.mymemory.translated.net/get"
CHUNK = 450  # MyMemory takes up to 500 characters per request
MIN_DESCRIPTION = 60  # a source description shorter than this says nothing ("Sin descripción")

GENRES_ES = {
    "Action": "Acción", "Adventure": "Aventura", "Comedy": "Comedia", "Drama": "Drama", "Ecchi": "Ecchi",
    "Fantasy": "Fantasía", "Horror": "Terror", "Mahou Shoujo": "Mahou Shoujo", "Mecha": "Mecha",
    "Music": "Música", "Mystery": "Misterio", "Psychological": "Psicológico", "Romance": "Romance",
    "Sci-Fi": "Ciencia ficción", "Slice of Life": "Recuentos de la vida", "Sports": "Deportes",
    "Supernatural": "Sobrenatural", "Thriller": "Suspenso", "Hentai": "Hentai",
}
STATUS = {"RELEASING": "ONGOING", "FINISHED": "COMPLETED", "CANCELLED": "CANCELLED", "HIATUS": "ON_HIATUS"}


def lacks_description(description: str | None) -> bool:
    text = re.sub(r"\s+", " ", description or "").strip()
    return len(text) < MIN_DESCRIPTION


def clean(description: str) -> str:
    """AniList's text without its HTML and the trailing "(Source: …)" credit."""
    text = re.sub(r"<br\s*/?>", "\n", description or "", flags=re.IGNORECASE)
    text = html.unescape(re.sub(r"<[^>]+>", "", text))
    text = re.sub(r"\(\s*source:[^)]*\)\s*$", "", text.strip(), flags=re.IGNORECASE | re.MULTILINE)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def chunks(paragraph: str) -> list[str]:
    """Whole sentences, at most CHUNK characters each."""
    out, current = [], ""
    for sentence in re.split(r"(?<=[.!?…])\s+", paragraph):
        while len(sentence) > CHUNK:  # a single huge sentence: cut it at a comma or space
            cut = max(sentence.rfind(", ", 0, CHUNK), sentence.rfind(" ", 0, CHUNK))
            cut = cut if cut > 0 else CHUNK
            out.append(sentence[:cut]); sentence = sentence[cut:].lstrip(", ")
        if current and len(current) + 1 + len(sentence) > CHUNK:
            out.append(current); current = sentence
        else:
            current = f"{current} {sentence}".strip()
    if current:
        out.append(current)
    return out


class Synopsis:
    def __init__(self):
        self.http = httpx.AsyncClient(timeout=20)
        self.path = os.path.join(GLib.get_user_cache_dir(), "kaori", "synopsis.json")
        try:
            with open(self.path, encoding="utf-8") as file:
                self.cache = json.load(file)
        except (OSError, ValueError):
            self.cache = {}

    async def spanish(self, anilist_id: int, description: str) -> tuple[str, bool]:
        """(text, translated): the Spanish synopsis, or the English one if translating failed."""
        key = str(anilist_id)
        if key in self.cache:
            return self.cache[key], True
        english = clean(description)
        if not english:
            return "", False
        paragraphs = []
        for paragraph in english.split("\n"):
            if not paragraph.strip():
                paragraphs.append("")
                continue
            parts = []
            for part in chunks(paragraph.strip()):
                translated = await self.translate(part)
                if translated is None:
                    return english, False  # not cached: try again next time
                parts.append(translated)
            paragraphs.append(" ".join(parts))
        text = re.sub(r"\n{3,}", "\n\n", "\n".join(paragraphs)).strip()
        self.cache[key] = text
        self.save()
        return text, True

    async def short(self, text: str) -> str:
        """A short text (a review's title) in Spanish; the original if it can't be translated now."""
        key = "t:" + text
        if key in self.cache:
            return self.cache[key]
        if len(text) > CHUNK or not text.strip():
            return text
        translated = await self.translate(text)
        if translated is None:
            return text
        self.cache[key] = translated
        self.save()
        return translated

    async def translate(self, text: str) -> str | None:
        try:
            response = await self.http.get(TRANSLATE_URL, params={"q": text, "langpair": "en|es"})
            data = response.json()
        except Exception:
            return None
        if data.get("responseStatus") != 200:
            return None
        result = (data.get("responseData") or {}).get("translatedText") or ""
        # Out of the daily quota MyMemory answers with a warning instead of a translation
        if not result or "MYMEMORY WARNING" in result.upper():
            return None
        return html.unescape(result)

    def save(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as file:
            json.dump(self.cache, file, ensure_ascii=False)
        os.replace(tmp, self.path)


_shared = None


def shared() -> Synopsis:
    global _shared
    if _shared is None:
        _shared = Synopsis()
    return _shared
