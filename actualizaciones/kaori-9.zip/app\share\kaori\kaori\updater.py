"""Updates for the shared Kaori: download, check and prepare them; Kaori.exe installs them on restart.

The published update is two files on the web (UPDATE_URL):
  latest.json  {"release": 3, "notes": "…", "file": "kaori-3.zip", "sha256": "…", "size": 123}
  kaori-3.zip  every file changed since the shared package (app\\…, Kaori.exe…), so it works whatever
               update a friend is coming from.

Kaori checks it on startup (once a day) and from the menu. A newer release is downloaded to
data\\update, its SHA-256 checked against latest.json, and unpacked into data\\update\\pending. Running
Kaori keeps some files locked (Kaori.exe, the interface resources), so Kaori.exe copies them into
place before starting Kaori next time. Nothing is installed if the checksum doesn't match, and only
Kaori's own folders can be written.
"""
import asyncio
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import zipfile

import httpx
from gi.repository import Adw, GLib, GObject, Gtk

from .release import RELEASE

# Where the updates are published: the actualizaciones folder of github.com/DavidSQ114/Proyecto_Kaori.
UPDATE_URL = os.environ.get("KAORI_UPDATE_URL") or "https://raw.githubusercontent.com/DavidSQ114/Proyecto_Kaori/main/actualizaciones/"
CHECK_EVERY = 24 * 3600  # s between automatic checks
FIRST_CHECK_DELAY = 90  # s after startup, so it doesn't slow the opening
ALLOWED = ("app/", "Kaori.exe", "Kaori.cmd", "LÉEME.txt", "source/")  # what an update may replace
MAX_SIZE = 300 * 1024 * 1024


def kaori_root() -> str:
    """The folder with Kaori.exe: app\\share\\kaori\\kaori\\updater.py is four levels below it."""
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(here))))


def update_dir() -> str:
    return os.path.join(kaori_root(), "data", "update")


def pending_release() -> int:
    """The release already downloaded and waiting for a restart (0 if none)."""
    try:
        with open(os.path.join(update_dir(), "pending", "READY"), encoding="utf-8") as file:
            return int(file.read().strip() or 0)
    except (OSError, ValueError):
        return 0


class Updater(GObject.Object):
    __gtype_name__ = 'KaoriUpdater'

    state = GObject.Property(type=str, default="idle")  # idle / checking / downloading / ready / error

    def __init__(self, app):
        super().__init__()
        self.app = app
        self.latest = None
        self.task = None
        self.error = ""
        self.progress = 0.0
        GLib.timeout_add_seconds(FIRST_CHECK_DELAY, self.on_first_check)

    @property
    def configured(self) -> bool:
        return bool(UPDATE_URL)

    def on_first_check(self):
        last = self.app.settings.get_int64("updates-last-check") if self.has_key("updates-last-check") else 0
        if self.configured and time.time() - last > CHECK_EVERY:
            self.check(quiet=True)
        return GLib.SOURCE_REMOVE

    def has_key(self, key) -> bool:
        return key in self.app.settings.props.settings_schema.list_keys()

    def check(self, quiet=False):
        if self.task is None or self.task.done():
            self.task = asyncio.create_task(self.run(quiet))
        return self.task

    async def run(self, quiet):
        """Look for a newer release and, if there is one, download and prepare it."""
        if not self.configured:
            self.fail("Las actualizaciones aún no están configuradas", quiet)
            return
        if pending_release() > RELEASE:
            self.state = "ready"
            if not quiet:
                self.announce()
            return
        self.state = "checking"
        try:
            async with httpx.AsyncClient(timeout=20, follow_redirects=True) as http:
                response = await http.get(UPDATE_URL + "latest.json", params={"t": int(time.time())})
                response.raise_for_status()
                latest = response.json()
                if self.has_key("updates-last-check"):
                    self.app.settings.set_int64("updates-last-check", int(time.time()))
                if int(latest.get("release", 0)) <= RELEASE:
                    self.state = "idle"
                    if not quiet:
                        self.toast("Kaori está al día")
                    return
                self.latest = latest
                self.state = "downloading"
                path = await self.download(http, latest)
            await asyncio.get_running_loop().run_in_executor(None, self.unpack, path, latest)
        except Exception as error:
            self.fail(f"No se pudo actualizar: {error}", quiet)
            return
        self.state = "ready"
        self.announce()

    async def download(self, http, latest) -> str:
        name = os.path.basename(latest["file"])
        size = int(latest.get("size", 0))
        if not name.endswith(".zip") or size > MAX_SIZE:
            raise ValueError("actualización no válida")
        os.makedirs(update_dir(), exist_ok=True)
        path = os.path.join(update_dir(), name)
        digest = hashlib.sha256()
        done = 0
        async with http.stream("GET", UPDATE_URL + name) as response:
            response.raise_for_status()
            with open(path, "wb") as file:
                async for chunk in response.aiter_bytes(65536):
                    file.write(chunk)
                    digest.update(chunk)
                    done += len(chunk)
                    if done > MAX_SIZE:
                        raise ValueError("actualización demasiado grande")
                    self.progress = done / size if size else 0.0
        if digest.hexdigest().lower() != str(latest.get("sha256", "")).lower():
            os.remove(path)
            raise ValueError("el archivo descargado no coincide con el publicado (se descartó)")
        return path

    def unpack(self, path, latest):
        pending = os.path.join(update_dir(), "pending")
        shutil.rmtree(pending, ignore_errors=True)
        os.makedirs(pending)
        with zipfile.ZipFile(path) as archive:
            for info in archive.infolist():
                name = info.filename.replace("\\", "/")
                if name.startswith("Kaori/"):  # zips made of the Kaori folder itself
                    name = name[len("Kaori/"):]
                if info.is_dir() or not name:
                    continue
                parts = name.split("/")
                if name.startswith("/") or ".." in parts or ":" in name or not name.startswith(ALLOWED):
                    raise ValueError(f"la actualización intenta escribir fuera de Kaori: {name}")
                target = os.path.join(pending, *parts)
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with archive.open(info) as source, open(target, "wb") as out:
                    shutil.copyfileobj(source, out)
        with open(os.path.join(pending, "READY"), "w", encoding="utf-8") as file:
            file.write(str(int(latest["release"])))
        os.remove(path)

    def fail(self, message, quiet):
        self.state = "error"
        self.error = message
        print(f"[actualización] {message}")
        if not quiet:
            self.toast(message)

    # --- telling the user (inside Kaori only) ---

    def toast(self, message, button=None, callback=None):
        window = self.app.get_active_window()
        if window is None or not hasattr(window, "toast_overlay"):
            return
        toast = Adw.Toast(title=message, timeout=8 if button else 3, use_markup=False)
        if button:
            toast.set_button_label(button)
            toast.connect("button-clicked", lambda t: callback())
        window.toast_overlay.add_toast(toast)

    def announce(self):
        notes = (self.latest or {}).get("notes") or ""
        self.toast("Actualización de Kaori lista" + (f": {notes}" if notes else "") + ". Se instala al reiniciar.",
                   "Reiniciar ahora", self.restart)

    def restart(self):
        """Close Kaori and open it again: Kaori.exe installs the update before starting."""
        launcher = os.path.join(kaori_root(), "Kaori.exe")
        if not os.path.exists(launcher):
            self.toast("Cierra Kaori y ábrelo de nuevo para instalar la actualización")
            return
        if sys.platform == "win32":
            # Kaori.exe waits for this Kaori to close (--esperar), installs the update and starts it again.
            # Not this run's variables: the new Kaori starts its own server.
            env = {key: value for key, value in os.environ.items()
                   if key not in ("KAORI_SERVER_PID", "KAORI_LAUNCHER_SPLASH", "KAORI_SERVER_DIR")}
            subprocess.Popen([launcher, "--esperar", str(os.getpid())], cwd=kaori_root(), env=env,
                             creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
                             close_fds=True)
        self.app.quit()
