import json
import os
import time

from gi.repository import GLib, GObject

MAX_ENTRIES = 50
SAVE_DELAY = 2  # seconds


class ReadingHistory(GObject.Object):
    """Local reading history: last chapter/page per manga and total time spent reading it.

    Stored as JSON in the user data dir, keyed by manga id, newest entries first when listed.
    """
    __gtype_name__ = 'KaoriReadingHistory'

    @GObject.Signal
    def changed(self):
        pass

    def __init__(self):
        super().__init__()
        self.path = os.path.join(GLib.get_user_data_dir(), 'kaori', 'history.json')
        self.entries: dict[str, dict] = {}
        self.save_id = 0
        try:
            with open(self.path, encoding='utf-8') as file:
                self.entries = json.load(file)
        except (OSError, ValueError):
            self.entries = {}

    def items(self) -> list[dict]:
        return sorted(self.entries.values(), key=lambda entry: entry['last_read'], reverse=True)

    def record(self, manga, chapter, page: int):
        """Remember that `page` (1-based) of `chapter` is being read now."""
        entry = self.entries.setdefault(str(manga.id), {'manga_id': manga.id, 'seconds': 0})
        entry.update(
            title=manga.title,
            thumbnail_url=manga.thumbnail_url,
            chapter_id=chapter.id,
            chapter_name=chapter.name,
            page=page,
            page_count=chapter.page_count,
            last_read=time.time(),
            new_chapters=0,  # reading it means the new chapters were seen
        )
        if manga.chapters is not None and manga.chapters.get_n_items():
            entry['known_chapters'] = manga.chapters.get_n_items()
        self.trim()
        self.queue_save()

    def update_chapters(self, manga_id: int, count: int, latest_name: str) -> int:
        """Store the chapter count found by the update check; returns how many are new since last time."""
        entry = self.entries.get(str(manga_id))
        if entry is None:
            return 0
        known = entry.get('known_chapters', 0)
        added = count - known if known else 0  # first check only sets the baseline
        entry['known_chapters'] = count
        entry['latest_chapter'] = latest_name
        entry['checked'] = time.time()
        if added > 0:
            entry['new_chapters'] = entry.get('new_chapters', 0) + added
        self.queue_save()
        return max(added, 0)

    def mark_seen(self, manga_id: int):
        if (entry := self.entries.get(str(manga_id))) and entry.get('new_chapters'):
            entry['new_chapters'] = 0
            self.queue_save()

    def total_new(self) -> int:
        return sum(entry.get('new_chapters', 0) for entry in self.entries.values())

    def add_time(self, manga_id: int, seconds: float):
        if entry := self.entries.get(str(manga_id)):
            entry['seconds'] = entry.get('seconds', 0) + seconds
            self.queue_save()

    def remove(self, manga_id: int):
        if self.entries.pop(str(manga_id), None) is not None:
            self.queue_save()

    def trim(self):
        for entry in self.items()[MAX_ENTRIES:]:
            del self.entries[str(entry['manga_id'])]

    def queue_save(self):
        if not self.save_id:
            self.save_id = GLib.timeout_add_seconds(SAVE_DELAY, self.save)

    def save(self):
        self.save_id = 0
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as file:
            json.dump(self.entries, file, ensure_ascii=False, indent=1)
        os.replace(tmp, self.path)
        self.emit('changed')
        return GLib.SOURCE_REMOVE

    def flush(self):
        if self.save_id:
            GLib.source_remove(self.save_id)
            self.save()
