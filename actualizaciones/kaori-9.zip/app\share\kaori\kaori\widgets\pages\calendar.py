"""Calendario: what comes out each day of this week, for the series you read (and, if you want, the
ones in your library). The schedule of each series is learned from its own chapter dates
(see schedule.py); nothing here asks the sites, so it opens instantly."""
import asyncio
from datetime import date, timedelta

from gi.repository import Adw, Gio, GLib, Gtk, Pango

from ... import schedule

COVER = (112, 160)
SMALL_COVER = (72, 104)
MAX_CONCURRENT = 4
MONTHS = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"]
SHORT_DAYS = ["lun", "mar", "mié", "jue", "vie", "sáb", "dom"]


def day_text(day: date) -> str:
    return f"{SHORT_DAYS[day.weekday()]} {day.day} {MONTHS[day.month - 1]}"


def relative(day: date, today: date) -> str:
    days = (day - today).days
    if days == 0:
        return "hoy"
    if days == 1:
        return "mañana"
    if days == -1:
        return "ayer"
    if 1 < days < 7:
        return f"el {schedule.DAY_NAMES[day.weekday()]}"
    return day_text(day)


def chapter_text(number: float) -> str:
    return f"Cap. {int(number)}" if number == int(number) else f"Cap. {number:g}"


def fixed_cover(size):
    width, height = size
    picture = Gtk.Picture(content_fit=Gtk.ContentFit.COVER, can_shrink=True,
                          width_request=width, height_request=height, css_classes=["poster"])
    frame = Adw.Clamp(maximum_size=width, tightening_threshold=width,
                      child=Adw.Clamp(orientation=Gtk.Orientation.VERTICAL, maximum_size=height,
                                      tightening_threshold=height, child=picture))
    return picture, frame


class CalendarPage(Adw.NavigationPage):
    __gtype_name__ = "KaoriCalendarPage"

    def __init__(self):
        super().__init__(title="Calendario", tag="calendar")
        app = Gio.Application.get_default()
        self.app = app
        self.suwayomi = app.suwayomi
        self.history = app.history
        self.settings = app.settings
        self.semaphore = asyncio.Semaphore(MAX_CONCURRENT)
        self.task = None
        self.cover_tasks = []
        self.dirty = True
        self.shown_day = None

        self.scope = Adw.ToggleGroup(tooltip_text="Qué series aparecen en el calendario")
        self.scope.add(Adw.Toggle(name="reading", label="Tus Lecturas"))
        self.scope.add(Adw.Toggle(name="library", label="+ Biblioteca"))
        self.scope.set_active_name(self.settings.get_string("calendar-scope"))
        self.scope.connect("notify::active-name", self.on_scope_changed)
        refresh = Gtk.Button(icon_name="view-refresh-symbolic",
                             tooltip_text="Buscar capítulos nuevos ahora (revisa los sitios)")
        refresh.connect("clicked", lambda button: app.updates.check_now())
        self.week_label = Gtk.Label(css_classes=["heading"])

        header = Adw.HeaderBar(title_widget=self.week_label)
        header.pack_start(self.scope)
        header.pack_end(refresh)

        self.content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18,
                               margin_top=12, margin_bottom=30, margin_start=20, margin_end=20)
        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE)
        self.stack.add_named(Adw.Spinner(width_request=48, height_request=48, halign=Gtk.Align.CENTER,
                                         valign=Gtk.Align.CENTER), "loading")
        self.stack.add_named(Adw.StatusPage(
            icon_name="x-office-calendar-symbolic", title="Tu calendario está vacío",
            description="Lee algunas series en emisión: Kaori aprende qué día sale cada una y te lo muestra aquí."),
            "empty")
        self.stack.add_named(Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER, child=self.content),
                             "content")
        view = Adw.ToolbarView(content=self.stack)
        view.add_top_bar(header)
        self.set_child(view)

        self.history.connect("changed", self.on_data_changed)
        app.updates.connect("notify::last-check", self.on_data_changed)
        self.connect("map", lambda page: self.refresh())
        GLib.timeout_add_seconds(600, self.on_tick)  # a new day moves "hoy"

    # --- data ---

    def on_scope_changed(self, *args):
        self.settings.set_string("calendar-scope", self.scope.get_active_name())
        self.dirty = True
        self.refresh()

    def on_data_changed(self, *args):
        self.dirty = True
        if self.get_mapped():
            self.refresh()

    def on_tick(self):
        if self.shown_day != date.today():
            self.on_data_changed()
        return GLib.SOURCE_CONTINUE

    def refresh(self):
        if not self.dirty and self.shown_day == date.today():
            return
        self.dirty = False
        if self.task:
            self.task.cancel()
        self.task = asyncio.create_task(self.load())

    async def load(self):
        if not self.content.get_first_child():
            self.stack.set_visible_child_name("loading")
        ids = [entry['manga_id'] for entry in self.history.items()]
        if self.scope.get_active_name() == "library":
            try:
                await self.suwayomi.refreshLibrary()
            except Exception:
                pass
            ids += [manga.id for manga in self.suwayomi.library if manga.id not in ids]
        try:
            series = await self.suwayomi.getScheduleData(ids)
        except Exception:
            series = []
        today = date.today()
        reading = {entry['manga_id'] for entry in self.history.items()}
        for item in series:
            item['schedule'] = schedule.analyze(item['chapters'], item['status'], today)
            numbers = [c['number'] for c in item['chapters'] if c['number'] is not None and c['number'] >= 0]
            item['latest'] = max(numbers) if numbers else None
            item['reading'] = item['id'] in reading
            item['new'] = (self.history.entries.get(str(item['id'])) or {}).get('new_chapters', 0)
        self.fill(series, today)

    # --- layout ---

    def fill(self, series, today):
        for task in self.cover_tasks:
            task.cancel()
        self.cover_tasks = []
        while child := self.content.get_first_child():
            self.content.remove(child)
        self.shown_day = today
        monday = today - timedelta(days=today.weekday())
        sunday = monday + timedelta(days=6)
        self.week_label.set_label(f"Esta semana · {monday.day} {MONTHS[monday.month - 1]} – "
                                  f"{sunday.day} {MONTHS[sunday.month - 1]}")

        days = {d: [] for d in range(7)}
        irregular, paused, learning = [], [], []
        for item in series:
            plan = item['schedule']
            state = plan['state']
            last = plan['last']
            if state == "finalizada":
                continue
            if state == "en_pausa":
                paused.append(item)
            elif state == "sin_datos":
                learning.append(item)
            elif last is not None and monday <= last <= sunday:
                # Already out this week (even the irregular ones): on the day it came out
                item['out'] = True
                days[last.weekday()].append(item)
            elif plan['day'] is not None:
                item['out'] = False
                days[plan['day']].append(item)  # expected on its usual day
            else:
                irregular.append(item)

        if not any(days.values()) and not irregular and not paused and not learning:
            self.stack.set_visible_child_name("empty")
            return

        week = Gtk.Box(spacing=8, homogeneous=True, css_classes=["calendar-week"])
        for index in range(7):
            week.append(self.day_column(monday + timedelta(days=index), today, days[index]))
        self.content.append(week)

        if irregular:
            self.content.append(self.section("Sin día fijo",
                                             "Publican, pero cada vez un día distinto: cuándo podría salir el próximo"))
            self.content.append(self.row(sorted(irregular, key=lambda i: i['schedule']['next'] or today),
                                         lambda i: f"Próximo ~{relative(i['schedule']['next'], today)}"
                                         if i['schedule']['next'] else "",
                                         lambda i: i['schedule']['label'].replace("Sin día fijo · ", "")
                                         .capitalize()))
        if paused:
            self.content.append(self.section("En pausa",
                                             "Dejaron de salir: vuelven solas al calendario en cuanto salga un capítulo"))
            self.content.append(self.row(sorted(paused, key=lambda i: i['schedule']['since_days'] or 0),
                                         lambda i: f"Sin capítulos hace {i['schedule']['since_days']} días",
                                         lambda i: (f"Último: {chapter_text(i['latest'])} · " if i['latest'] is not None
                                                    else "Último: ") + day_text(i['schedule']['last'])))
        if learning:
            self.content.append(self.section("Aprendiendo su día",
                                             "Su sitio no dice cuándo publica cada capítulo: Kaori lo aprende al ver "
                                             "salir los próximos (en unas semanas estarán en el calendario)"))
            self.content.append(self.row(sorted(learning, key=lambda i: i['title']),
                                         lambda i: (f"Ha visto salir {i['schedule']['releases']} de {schedule.MIN_RELEASES} capítulos"
                                                    if i['schedule']['releases'] else "Aún no ha visto salir ninguno"),
                                         lambda i: f"Último: {chapter_text(i['latest'])}" if i['latest'] is not None
                                         else ""))
        self.stack.set_visible_child_name("content")

    def day_column(self, day, today, items):
        column = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, css_classes=["calendar-day"])
        if day == today:
            column.add_css_class("today")
        elif day < today:
            column.add_css_class("past")
        head = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0, css_classes=["calendar-day-head"])
        head.append(Gtk.Label(label="Hoy" if day == today else schedule.DAY_NAMES[day.weekday()].capitalize(),
                              css_classes=["heading"]))
        head.append(Gtk.Label(label=f"{day.day} {MONTHS[day.month - 1]}", css_classes=["dim-label", "caption"]))
        column.append(head)
        # Out first, then by how sure the day is
        items.sort(key=lambda i: (not i.get('out'), -i['schedule']['confidence'], i['title']))
        for item in items:
            column.append(self.day_card(item, day, today))
        if not items:
            column.append(Gtk.Label(label="—", css_classes=["dim-label"], margin_top=12))
        return column

    def day_card(self, item, day, today):
        plan = item['schedule']
        button = Gtk.Button(css_classes=["flat", "calendar-card"], tooltip_text=f"{item['title']}\n{plan['label']}"
                            f"\n{item['source']}")
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        cover, frame = fixed_cover(COVER)
        overlay = Gtk.Overlay(child=frame, halign=Gtk.Align.CENTER)
        if item.get('out'):
            badge, css = "✓ Ya salió", "sakura"
        elif plan['state'] == "retrasada":
            badge, css = f"Retrasada {plan['late_days']} d", "warning-badge"
        elif plan['state'] == "sin_dia_fijo":
            badge, css = "Irregular", "bl-badge"
        else:
            badge, css = None, None
        if badge:
            overlay.add_overlay(Gtk.Label(label=badge, halign=Gtk.Align.START, valign=Gtk.Align.START,
                                          css_classes=["compare-badge", css], margin_top=6, margin_start=6))
        box.append(overlay)
        box.append(Gtk.Label(label=item['title'], xalign=0, wrap=True, lines=2, max_width_chars=1,
                             ellipsize=Pango.EllipsizeMode.END, css_classes=["caption-heading"]))
        latest = item['latest']
        if item.get('out') and latest is not None:
            detail = f"{chapter_text(latest)}" + (" · sin leer" if item['new'] else "")
        elif latest is not None:
            detail = f"Esperado: {chapter_text(latest + 1)}"
        else:
            detail = "Esperado"
        if plan['also'] is not None and not item.get('out'):
            detail += f" · a veces {SHORT_DAYS[plan['also']]}"
        box.append(Gtk.Label(label=detail, xalign=0, wrap=True, css_classes=["caption", "dim-label"]))
        box.append(Gtk.Label(label=item['source'], xalign=0, ellipsize=Pango.EllipsizeMode.END,
                             css_classes=["caption", "calendar-source"]))
        button.set_child(box)
        button.connect("clicked", lambda b, mid=item['id']: b.activate_action("app.show_manga", GLib.Variant("i", mid)))
        self.load_cover(cover, item)
        return button

    def section(self, title, subtitle):
        header = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, margin_top=8)
        header.append(Gtk.Label(label=title, xalign=0, css_classes=["title-3"]))
        header.append(Gtk.Label(label=subtitle, xalign=0, css_classes=["dim-label", "caption"]))
        return header

    def row(self, items, detail, extra):
        flow = Gtk.FlowBox(homogeneous=True, min_children_per_line=2, max_children_per_line=10,
                           column_spacing=8, row_spacing=8, selection_mode=Gtk.SelectionMode.NONE)
        for item in items:
            button = Gtk.Button(css_classes=["flat", "calendar-card"], tooltip_text=f"{item['title']}\n"
                                f"{item['schedule']['label']}\n{item['source']}")
            line = Gtk.Box(spacing=10)
            cover, frame = fixed_cover(SMALL_COVER)
            line.append(frame)
            texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3, valign=Gtk.Align.CENTER)
            texts.append(Gtk.Label(label=item['title'], xalign=0, wrap=True, lines=2, max_width_chars=1,
                                   hexpand=True, ellipsize=Pango.EllipsizeMode.END, css_classes=["caption-heading"]))
            if text := detail(item):
                texts.append(Gtk.Label(label=text, xalign=0, wrap=True, css_classes=["caption", "dim-label"]))
            if text := extra(item):
                texts.append(Gtk.Label(label=text, xalign=0, wrap=True, css_classes=["caption", "dim-label"]))
            texts.append(Gtk.Label(label=item['source'], xalign=0, ellipsize=Pango.EllipsizeMode.END,
                                   css_classes=["caption", "calendar-source"]))
            line.append(texts)
            button.set_child(line)
            button.connect("clicked", lambda b, mid=item['id']: b.activate_action("app.show_manga",
                                                                                    GLib.Variant("i", mid)))
            flow.append(button)
            self.load_cover(cover, item)
        return flow

    def load_cover(self, picture, item):
        async def load():
            model = self.suwayomi.getModel(item['id'], 'Manga')
            if model is not None and model.paintable is not None:
                picture.set_paintable(model.paintable)
                return
            from ..containers import covers
            async with self.semaphore:
                try:
                    paintable = await covers.load(self.suwayomi, item['id'], item['thumbnail_url'], identify=True)
                except Exception:
                    return
            picture.set_paintable(paintable)
        self.cover_tasks.append(asyncio.create_task(load()))
