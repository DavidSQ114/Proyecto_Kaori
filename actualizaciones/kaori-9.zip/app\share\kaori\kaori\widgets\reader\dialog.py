from gi.repository import Adw, Gio, GObject, Gtk

from .webtoon import BASE_WIDTH

ORIENTATIONS = [Gtk.Orientation.VERTICAL, Gtk.Orientation.HORIZONTAL]
DIRECTIONS = [Gtk.TextDirection.LTR, Gtk.TextDirection.RTL]
WIDTH_KEY = "webtoon-zoom"
SPEED_KEY = "scroll-speed"


def percent(scale, value):
    return f"{value:.0f}%"


@Gtk.Template(resource_path='/io/github/riyaniii/Kaori/reader/dialog.ui')
class SettingsDialog(Adw.Dialog):
    __gtype_name__ = "KaoriSettingsDialog"

    stack = GObject.Property(type=Gtk.Widget)

    orientation_row = Gtk.Template.Child()
    direction_row = Gtk.Template.Child()
    width_scale = Gtk.Template.Child()
    speed_scale = Gtk.Template.Child()

    def __init__(self, stack):
        super().__init__()
        self.stack = stack
        self.webtoon = stack.get_child_by_name("webtoon")
        self.settings = Gio.Application.get_default().settings

        for scale in (self.width_scale, self.speed_scale):
            scale.set_format_value_func(percent)
            scale.add_mark(100, Gtk.PositionType.BOTTOM, None)

        self.updating = True
        self.orientation_row.set_selected(ORIENTATIONS.index(self.webtoon.orientation))
        self.direction_row.set_selected(DIRECTIONS.index(self.webtoon.direction))
        self.width_scale.set_value(round(self.webtoon.zoom / BASE_WIDTH * 100))
        self.speed_scale.set_value(round(self.settings.get_double(SPEED_KEY) * 100))
        self.updating = False

    @Gtk.Template.Callback()
    def is_webtoon(self, obj, visible_child_name):
        return visible_child_name == "webtoon"

    @Gtk.Template.Callback()
    def on_orientation_changed(self, row, pspec):
        if not self.updating:
            self.webtoon.orientation = ORIENTATIONS[row.get_selected()]

    @Gtk.Template.Callback()
    def on_direction_changed(self, row, pspec):
        if not self.updating:
            self.webtoon.direction = DIRECTIONS[row.get_selected()]

    @Gtk.Template.Callback()
    def on_width_changed(self, scale):
        if self.updating:
            return
        relative = scale.get_value() / 100
        self.settings.set_double(WIDTH_KEY, relative)
        self.webtoon.reset_zoom()

    @Gtk.Template.Callback()
    def on_width_reset(self, button):
        self.width_scale.set_value(100)

    @Gtk.Template.Callback()
    def on_speed_changed(self, scale):
        if not self.updating:
            self.settings.set_double(SPEED_KEY, scale.get_value() / 100)

    @Gtk.Template.Callback()
    def on_speed_reset(self, button):
        self.speed_scale.set_value(100)
