"""'Si te gusta esto…': series like the one on the manga page, from AniList."""
import asyncio

from gi.repository import Adw, Gio, Gtk, Pango

COVER_WIDTH = 140
COVER_HEIGHT = 200
MAX_CONCURRENT = 3

_anilist = None


def shared_anilist():
    global _anilist
    if _anilist is None:
        from ...integrations.anilist import AniList
        _anilist = AniList()
    return _anilist


class SimilarCard(Gtk.Button):
    __gtype_name__ = "KaoriSimilarCard"

    def __init__(self, entry):
        super().__init__(css_classes=["flat", "similar-card"], tooltip_text=entry['title'])
        self.entry = entry
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, width_request=COVER_WIDTH)
        self.cover = Gtk.Picture(content_fit=Gtk.ContentFit.COVER, can_shrink=True, css_classes=["poster"],
                                 width_request=COVER_WIDTH, height_request=COVER_HEIGHT)
        box.append(Adw.Clamp(maximum_size=COVER_WIDTH, tightening_threshold=COVER_WIDTH,
                             child=Adw.Clamp(orientation=Gtk.Orientation.VERTICAL, maximum_size=COVER_HEIGHT,
                                             tightening_threshold=COVER_HEIGHT, child=self.cover)))
        box.append(Gtk.Label(label=entry['title'], xalign=0, ellipsize=Pango.EllipsizeMode.END,
                             max_width_chars=1, hexpand=True, css_classes=["caption-heading"]))
        details = [entry['kind']] + ([f"★ {entry['score']}"] if entry.get('score') else [])
        box.append(Gtk.Label(label="  ·  ".join(details), xalign=0, css_classes=["dim-label", "caption"]))
        self.set_child(box)

    async def load_cover(self, suwayomi, semaphore):
        if not self.entry.get('cover_url'):
            return
        async with semaphore:
            try:
                self.cover.set_paintable(await suwayomi.getPaintable(self.entry['cover_url']))
            except Exception:
                pass


class SimilarRow(Gtk.Box):
    __gtype_name__ = "KaoriSimilarRow"

    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8, visible=False)
        self.suwayomi = Gio.Application.get_default().suwayomi
        self.loaded = False
        header = Gtk.Box(spacing=10)
        header.append(Gtk.Label(label="Si te gusta esto…", css_classes=["title-4"]))
        self.source = Gtk.Label(css_classes=["dim-label", "caption"], valign=Gtk.Align.BASELINE_CENTER)
        header.append(self.source)
        self.append(header)
        self.cards = Gtk.Box(spacing=8)
        scrolled = Gtk.ScrolledWindow(vscrollbar_policy=Gtk.PolicyType.NEVER, child=self.cards,
                                      propagate_natural_height=True)
        self.append(scrolled)

    def load(self, title: str, genres: list, anilist_id: int | None = None):
        if self.loaded or not title:
            return
        self.loaded = True
        asyncio.create_task(self.fill(title, genres, anilist_id))

    def reset(self):
        while child := self.cards.get_first_child():
            self.cards.remove(child)
        self.loaded = False
        self.set_visible(False)

    async def fill(self, title, genres, anilist_id=None):
        try:
            entries, how = await shared_anilist().recommendations(title, genres, anilist_id)
        except Exception:
            return  # offline or AniList down: the row just stays hidden
        if not entries:
            return
        self.source.set_label(how)
        semaphore = asyncio.Semaphore(MAX_CONCURRENT)
        tasks = []
        for entry in entries:
            card = SimilarCard(entry)
            card.connect("clicked", self.on_card_clicked)
            self.cards.append(card)
            tasks.append(card.load_cover(self.suwayomi, semaphore))
        self.set_visible(True)
        await asyncio.gather(*tasks, return_exceptions=True)

    def on_card_clicked(self, card):
        from ..pages.ranking_detail import RankingDetailPage
        nav = self.get_ancestor(Adw.NavigationView)
        if nav is not None:
            nav.push(RankingDetailPage(card.entry, shared_anilist()))
