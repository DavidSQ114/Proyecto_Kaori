"""Link a series to its AniList entry by hand, when Kaori couldn't tell which one it is."""
import asyncio

from gi.repository import Adw, Gio, Gtk, Pango

from .similar import shared_anilist

COVER_WIDTH = 46
COVER_HEIGHT = 66


class LinkDialog(Adw.Dialog):
    __gtype_name__ = "KaoriLinkDialog"

    def __init__(self, manga, on_linked):
        super().__init__(title="Vincular con AniList", content_width=560, content_height=620)
        self.manga = manga
        self.on_linked = on_linked
        self.suwayomi = Gio.Application.get_default().suwayomi
        self.task = None

        self.entry = Gtk.SearchEntry(text=manga.title, hexpand=True,
                                     placeholder_text="Nombre en inglés, romaji o coreano")
        self.entry.connect("activate", lambda entry: self.search())
        hint = Gtk.Label(label="Kaori no reconoció esta serie. Búscala con su nombre en inglés o el original "
                               "y elige la correcta: así funcionan las recomendaciones.",
                         wrap=True, xalign=0, css_classes=["dim-label", "caption"])
        self.list = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE, css_classes=["boxed-list"])
        self.list.connect("row-activated", self.on_row_activated)
        self.status = Gtk.Label(css_classes=["dim-label"], margin_top=12)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, margin_top=6, margin_bottom=12,
                      margin_start=12, margin_end=12)
        box.append(self.entry)
        box.append(hint)
        box.append(self.status)
        box.append(self.list)
        view = Adw.ToolbarView(content=Gtk.ScrolledWindow(child=box, hscrollbar_policy=Gtk.PolicyType.NEVER))
        view.add_top_bar(Adw.HeaderBar())
        self.set_child(view)
        self.search()

    def search(self):
        if self.task:
            self.task.cancel()
        self.task = asyncio.create_task(self.run_search(self.entry.get_text().strip()))

    async def run_search(self, text):
        while row := self.list.get_first_child():
            self.list.remove(row)
        if not text:
            return
        self.status.set_label("Buscando…")
        self.status.set_visible(True)
        try:
            entries = await shared_anilist().search(text)
        except Exception:
            self.status.set_label("No se pudo consultar AniList")
            return
        self.status.set_visible(not entries)
        self.status.set_label("Sin resultados: prueba con el nombre en inglés")
        for entry in entries:
            self.list.append(self.make_row(entry))

    def make_row(self, entry):
        row = Gtk.ListBoxRow(activatable=True)
        row.entry = entry
        box = Gtk.Box(spacing=12, margin_top=6, margin_bottom=6, margin_start=6, margin_end=6)
        cover = Gtk.Picture(content_fit=Gtk.ContentFit.COVER, can_shrink=True, css_classes=["poster"],
                            width_request=COVER_WIDTH, height_request=COVER_HEIGHT)
        box.append(Adw.Clamp(maximum_size=COVER_WIDTH, tightening_threshold=COVER_WIDTH,
                             child=Adw.Clamp(orientation=Gtk.Orientation.VERTICAL, maximum_size=COVER_HEIGHT,
                                             tightening_threshold=COVER_HEIGHT, child=cover)))
        info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, valign=Gtk.Align.CENTER)
        info.append(Gtk.Label(label=entry['title'], xalign=0, wrap=True, css_classes=["heading"]))
        details = [entry['kind']] + ([f"★ {entry['score']}"] if entry.get('score') else []) + \
                  (["+18"] if entry.get('adult') else [])
        others = [t for t in entry.get('search_titles', [])[1:3] if t != entry['title']]
        info.append(Gtk.Label(label="  ·  ".join(details) + (f"  ·  {', '.join(others)}" if others else ""),
                              xalign=0, ellipsize=Pango.EllipsizeMode.END, max_width_chars=1, hexpand=True,
                              css_classes=["dim-label", "caption"]))
        box.append(info)
        row.set_child(box)
        asyncio.create_task(self.load_cover(cover, entry.get('cover_url')))
        return row

    async def load_cover(self, picture, url):
        if url:
            try:
                picture.set_paintable(await self.suwayomi.getPaintable(url))
            except Exception:
                pass

    def on_row_activated(self, listbox, row):
        Gio.Application.get_default().identity.link(self.manga.id, row.entry['id'], row.entry['title'])
        self.close()
        self.on_linked()
