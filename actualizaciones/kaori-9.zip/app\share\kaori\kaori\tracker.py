"""Your library as a tracker: each series is Leyendo, Pendiente, Completada or Abandonada.

What you choose is kept in <data>/kaori/tracker.json. Series you never set get one guessed:
completed when every chapter is read and the series has finished, reading when it is in Tus
Lecturas, pending otherwise (added to the library, not started).
"""
import json
import os

from gi.repository import GLib, GObject

STATUSES = [  # (id, name)
    ("reading", "Leyendo"),
    ("plan", "Pendiente"),
    ("completed", "Completada"),
    ("dropped", "Abandonada"),
]
NAMES = dict(STATUSES)
FINISHED = {"COMPLETED", "PUBLISHING_FINISHED", "CANCELLED"}


class Tracker(GObject.Object):
    __gtype_name__ = 'KaoriTracker'

    @GObject.Signal
    def changed(self):
        pass

    def __init__(self, history):
        super().__init__()
        self.history = history
        self.path = os.path.join(GLib.get_user_data_dir(), 'kaori', 'tracker.json')
        try:
            with open(self.path, encoding='utf-8') as file:
                self.chosen: dict[str, str] = json.load(file)
        except (OSError, ValueError):
            self.chosen = {}

    def status_of(self, manga) -> str:
        if status := self.chosen.get(str(manga.id)):
            return status
        reading = str(manga.id) in self.history.entries
        if reading and manga.chapters_ahead == 0 and manga.read_fraction >= 0.99 and (manga.status or "") in FINISHED:
            return "completed"
        if reading:
            return "reading"
        return "plan"

    def is_chosen(self, manga_id: int) -> bool:
        return str(manga_id) in self.chosen

    def set_status(self, manga_id: int, status: str | None):
        """None goes back to the guessed status."""
        if status is None:
            self.chosen.pop(str(manga_id), None)
        else:
            self.chosen[str(manga_id)] = status
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as file:
            json.dump(self.chosen, file, ensure_ascii=False, indent=1)
        os.replace(tmp, self.path)
        self.emit('changed')
