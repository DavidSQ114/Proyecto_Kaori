"""Capture mode of the reader: drag a rectangle over a panel and keep it in the Galería.

The cut-out isn't a screenshot of the window: the reader is drawn again just for the chosen area at
the pages' own resolution, so the image is as sharp as the original even when reading zoomed out,
and a panel split across two webtoon pages comes out in one piece.
"""
from gi.repository import Gdk, GObject, Graphene, Gtk

MIN_SELECTION = 12  # px: a smaller drag is a slip, not a selection
MAX_SCALE = 4.0
MAX_SIDE = 6000  # px of the saved image (and well under the GPU's texture limit)

DIM = Gdk.RGBA()
DIM.parse("rgba(0, 0, 0, 0.55)")
def border_color():
    """The theme's main colour (chosen in Apariencia)."""
    from gi.repository import Gio
    from ... import theme
    return theme.primary_rgba(Gio.Application.get_default().settings)


def rect(x, y, width, height):
    return Graphene.Rect().init(x, y, width, height)


class SelectionArea(Gtk.Widget):
    """Dims the reader and shows the rectangle being dragged."""
    __gtype_name__ = "KaoriCaptureSelection"

    def __init__(self):
        super().__init__(hexpand=True, vexpand=True)
        self.selection = None  # (x, y, width, height) in this widget's coordinates
        self.set_cursor_from_name("crosshair")

    def do_snapshot(self, snapshot):
        width, height = self.get_width(), self.get_height()
        if self.selection is None:
            snapshot.append_color(DIM, rect(0, 0, width, height))
            return
        x, y, w, h = self.selection
        # Dim everything around the selection, leave the selection clear
        for area in ((0, 0, width, y), (0, y + h, width, height - y - h), (0, y, x, h), (x + w, y, width - x - w, h)):
            if area[2] > 0 and area[3] > 0:
                snapshot.append_color(DIM, rect(*area))
        border = border_color()
        for edge in ((x, y, w, 2), (x, y + h - 2, w, 2), (x, y, 2, h), (x + w - 2, y, 2, h)):
            snapshot.append_color(border, rect(*edge))


class CaptureOverlay(Gtk.Overlay):
    """Sits over the reader while capturing. Emits `captured` with a Gdk.Texture, or `cancelled`."""
    __gtype_name__ = "KaoriCaptureOverlay"

    @GObject.Signal(arg_types=(Gdk.Texture,))
    def captured(self, texture):
        pass

    @GObject.Signal
    def cancelled(self):
        pass

    def __init__(self, target: Gtk.Widget):
        super().__init__(visible=False)
        self.target = target  # the widget being captured; must cover the same area as this overlay
        self.area = SelectionArea()
        self.set_child(self.area)
        hint = Gtk.Label(label="Arrastra sobre la viñeta para guardarla  ·  Enter: todo lo visible  ·  Esc: cancelar",
                         halign=Gtk.Align.CENTER, valign=Gtk.Align.START, margin_top=70, can_target=False,
                         css_classes=["capture-hint"])
        self.add_overlay(hint)

        drag = Gtk.GestureDrag(button=Gdk.BUTTON_PRIMARY)
        drag.connect("drag-begin", self.on_drag_begin)
        drag.connect("drag-update", self.on_drag_update)
        drag.connect("drag-end", self.on_drag_end)
        self.area.add_controller(drag)
        cancel = Gtk.GestureClick(button=Gdk.BUTTON_SECONDARY)
        cancel.connect("pressed", lambda *_: self.stop(cancelled=True))
        self.area.add_controller(cancel)
        self.origin = (0.0, 0.0)

    @property
    def active(self) -> bool:
        return self.get_visible()

    def start(self):
        self.area.selection = None
        self.set_visible(True)
        self.area.queue_draw()

    def stop(self, cancelled=False):
        self.set_visible(False)
        self.area.selection = None
        if cancelled:
            self.emit("cancelled")

    def on_drag_begin(self, gesture, x, y):
        self.origin = (x, y)
        self.area.selection = (x, y, 0, 0)
        self.area.queue_draw()

    def on_drag_update(self, gesture, dx, dy):
        x0, y0 = self.origin
        width, height = self.area.get_width(), self.area.get_height()
        x1 = max(0.0, min(width, x0 + dx))
        y1 = max(0.0, min(height, y0 + dy))
        self.area.selection = (min(x0, x1), min(y0, y1), abs(x1 - x0), abs(y1 - y0))
        self.area.queue_draw()

    def on_drag_end(self, gesture, dx, dy):
        selection = self.area.selection
        if selection is None or selection[2] < MIN_SELECTION or selection[3] < MIN_SELECTION:
            self.area.selection = None
            self.area.queue_draw()
            return
        self.capture(*selection)

    def capture_all(self):
        self.capture(0, 0, self.target.get_width(), self.target.get_height())

    def capture(self, x, y, width, height):
        # Hide first so neither the dimming nor the hint can end up in the image
        self.stop()
        texture = render_area(self.target, x, y, width, height)
        if texture is not None:
            self.emit("captured", texture)


def native_scale(target: Gtk.Widget) -> float:
    """How many image pixels each on-screen pixel of the pages stands for (>= 1): the largest ratio
    between a shown page's own width and the width it's drawn at."""
    best = 1.0
    stack = [target]
    while stack:
        widget = stack.pop()
        child = widget.get_first_child()
        while child is not None:
            if child.get_mapped():
                stack.append(child)
            child = child.get_next_sibling()
        if not isinstance(widget, Gtk.Picture):
            continue
        paintable = widget.get_paintable()
        if paintable is None:
            continue
        shown = widget.get_width() * drawn_zoom(widget, target)
        if shown > 1:
            best = max(best, paintable.get_intrinsic_width() / shown)
    return min(best, MAX_SCALE)


def drawn_zoom(widget: Gtk.Widget, target: Gtk.Widget) -> float:
    """Zoom applied while drawing (the webtoon canvas scales its pages in its own snapshot)."""
    zoom = 1.0
    parent = widget.get_parent()
    while parent is not None and parent is not target.get_parent():
        value = getattr(parent, "zoom", None)
        if isinstance(value, float):
            zoom *= value
        parent = parent.get_parent()
    return zoom


def render_area(target: Gtk.Widget, x, y, width, height):
    native = target.get_native()
    if native is None or width < 1 or height < 1:
        return None
    scale = native_scale(target)
    scale = max(1.0, min(scale, MAX_SIDE / max(width, height)))

    snapshot = Gtk.Snapshot()
    Gtk.WidgetPaintable(widget=target).snapshot(snapshot, target.get_width() * scale, target.get_height() * scale)
    node = snapshot.to_node()
    if node is None:
        return None
    return native.get_renderer().render_texture(node, rect(x * scale, y * scale, width * scale, height * scale))
