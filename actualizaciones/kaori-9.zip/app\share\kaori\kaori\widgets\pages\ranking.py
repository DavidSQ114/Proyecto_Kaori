import asyncio

from ...integrations.synopsis import GENRES_ES
from gi.repository import Adw, Gio, Gtk, Pango

from ...integrations.anilist import AniList
from .ranking_detail import RankingDetailPage

KINDS = ["all", "manga", "manhwa", "manhua"]
ADULT = ["no", "only", "all"]
ROMANCE = ["all", "bl", "gl", "none"]
CARD_WIDTH = 180
COVER_HEIGHT = round(CARD_WIDTH / 0.68)


class RankingCard(Gtk.FlowBoxChild):
    __gtype_name__ = "KaoriRankingCard"

    def __init__(self, entry: dict):
        super().__init__()
        self.entry = entry
        self.set_tooltip_text(f"Ver detalles de «{entry['title']}»")

        # Fixed size: inside a FlowBox an AspectFrame gets no height until the cover has loaded
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, width_request=CARD_WIDTH,
                      halign=Gtk.Align.CENTER, valign=Gtk.Align.START,
                      margin_start=6, margin_end=6, margin_top=6, margin_bottom=6)

        self.cover = Gtk.Picture(content_fit=Gtk.ContentFit.COVER, can_shrink=True,
                                 width_request=CARD_WIDTH, height_request=COVER_HEIGHT,
                                 css_classes=["rounded", "poster"])
        overlay = Gtk.Overlay(child=self.cover)
        overlay.add_overlay(Gtk.Label(label=f"#{entry['rank']}", halign=Gtk.Align.START, valign=Gtk.Align.START,
                                      css_classes=["rank-badge"]))
        box.append(overlay)

        box.append(Gtk.Label(label=entry['title'], xalign=0, wrap=True, lines=2, max_width_chars=1,
                             ellipsize=Pango.EllipsizeMode.END, css_classes=["heading"]))
        score = f"★ {entry['score']}" if entry.get('score') else "★ –"
        meta = Gtk.Box(spacing=8)
        meta.append(Gtk.Label(label=f"{score}  ·  {entry['kind']}", xalign=0, css_classes=["little-bold"]))
        if entry.get('bl'):
            meta.append(Gtk.Label(label="BL", tooltip_text="Boys' Love: romance entre chicos",
                                  css_classes=["compare-badge", "bl-badge"]))
        if entry.get('gl'):
            meta.append(Gtk.Label(label="GL", tooltip_text="Girls' Love (Yuri): romance entre chicas",
                                  css_classes=["compare-badge", "gl-badge"]))
        if entry.get('adult'):
            meta.append(Gtk.Label(label="+18", css_classes=["compare-badge", "sakura"]))
        box.append(meta)
        if entry.get('genres'):
            box.append(Gtk.Label(label=", ".join(GENRES_ES.get(g, g) for g in entry['genres'][:3]), xalign=0,
                                 ellipsize=Pango.EllipsizeMode.END, css_classes=["dim-label", "caption"]))
        self.set_child(box)

    async def load_cover(self, suwayomi):
        if not self.entry.get('cover_url'):
            return
        try:
            self.cover.set_paintable(await suwayomi.getPaintable(self.entry['cover_url']))
        except Exception:
            pass  # keep the placeholder background


@Gtk.Template(resource_path='/io/github/riyaniii/Kaori/pages/ranking.ui')
class RankingPage(Adw.NavigationPage):
    __gtype_name__ = "KaoriRankingPage"

    sort_group = Gtk.Template.Child()
    kind_dropdown = Gtk.Template.Child()
    adult_dropdown = Gtk.Template.Child()
    romance_dropdown = Gtk.Template.Child()
    stack = Gtk.Template.Child()
    error_page = Gtk.Template.Child()
    scrolled = Gtk.Template.Child()
    flowbox = Gtk.Template.Child()
    more_button = Gtk.Template.Child()

    def __init__(self):
        super().__init__()
        self.suwayomi = Gio.Application.get_default().suwayomi
        self.anilist = AniList()
        self.page = 0
        self.load_task = None
        self.cover_tasks = []
        self.loaded = False
        # Only hit the network once the page is actually opened
        self.connect("map", lambda page: self.loaded or self.reload())

    @property
    def filters(self):
        return (self.sort_group.get_active_name() or "score", KINDS[self.kind_dropdown.get_selected()],
                ADULT[self.adult_dropdown.get_selected()], ROMANCE[self.romance_dropdown.get_selected()])

    @Gtk.Template.Callback()
    def on_filters_changed(self, *args):
        if self.loaded:
            self.reload()

    @Gtk.Template.Callback()
    def on_retry_clicked(self, button):
        self.reload()

    @Gtk.Template.Callback()
    def on_more_clicked(self, button):
        self.start_load(self.page + 1)

    def reload(self):
        self.loaded = True
        for task in self.cover_tasks:
            task.cancel()
        self.cover_tasks = []
        self.flowbox.remove_all()
        self.scrolled.get_vadjustment().set_value(0)
        self.stack.set_visible_child_name("loading")
        self.start_load(1)

    def start_load(self, page):
        if self.load_task:
            self.load_task.cancel()
        self.load_task = asyncio.create_task(self.load(page, *self.filters))

    async def load(self, page, sort, kind, adult, romance):
        self.more_button.set_sensitive(False)
        try:
            entries, has_next = await self.anilist.ranking(sort, kind, page, adult, romance)
        except Exception as error:
            if page == 1:
                self.error_page.set_description(str(error))
                self.stack.set_visible_child_name("error")
            self.more_button.set_sensitive(True)
            return

        self.page = page
        for entry in entries:
            card = RankingCard(entry)
            self.flowbox.append(card)
            self.cover_tasks.append(asyncio.create_task(card.load_cover(self.suwayomi)))
        self.more_button.set_visible(has_next)
        self.more_button.set_sensitive(True)
        self.stack.set_visible_child_name("grid")

    @Gtk.Template.Callback()
    def on_child_activated(self, flowbox, card):
        nav_view = self.get_ancestor(Adw.NavigationView)
        nav_view.push(RankingDetailPage(card.entry, self.anilist))
