import asyncio
from gi.repository import Adw, Gio, GObject, Gtk

from ..manga import MangaCard
from ..containers import MangaGrid
from .filter import SourceFilter
from .preferences import SourcePreferencesDialog

from ...integrations import models
from ...integrations.suwayomi import SourceMangaType
from ...integrations.compare import friendly_error, loose_match, loose_queries, webview_stuck

QUICK_FILTER_TYPES = ("SelectFilter", "SortFilter")
MAX_QUICK_FILTERS = 4


class Pager:
    """Loads one tab of a source page by page, appending each page to its grid (infinite scroll)."""

    def __init__(self, page, stack, grid, error_page):
        self.page = page
        self.stack = stack
        self.grid = grid
        self.error_page = error_page
        self.task = None
        self.query = {}
        self.current = 0
        self.has_next = False
        self.loading = False
        self.started = False
        self.loose_filter = None  # original text when showing an accent-tolerant retry

    async def loose_search(self):
        """Nothing for the exact text: retry without accents, then with the stem of the longest word
        ("operacion" finds "Operación"). Later pages keep using the query that worked."""
        original = self.query['query']
        for alternative, needs_filter in loose_queries(original):
            try:
                mangas, has_next = await self.page.suwayomi.getSourceMangaPage(
                    self.page.model.id, page=1, **{**self.query, 'query': alternative})
            except Exception:
                continue
            if needs_filter:
                mangas = [m for m in mangas if loose_match(original, m.title)]
            if mangas:
                self.query = {**self.query, 'query': alternative}
                self.loose_filter = original if needs_filter else None
                return mangas, has_next
        return [], False

    def show_error(self, error):
        self.error_page.set_description(friendly_error(error))
        self.error_page.set_tooltip_text(str(error)[:600])  # the full message, for diagnosing
        self.error_page.set_child(None)
        if webview_stuck(error):
            button = Gtk.Button(label="Destrabar y reintentar", halign=Gtk.Align.CENTER,
                                css_classes=["pill", "suggested-action"])
            button.connect("clicked", self.on_unstick_clicked)
            self.error_page.set_child(button)
        self.stack.set_visible_child_name("error")

    def on_unstick_clicked(self, button):
        button.set_sensitive(False)
        button.set_label("Reiniciando el servidor… (unos 20 s)")
        asyncio.create_task(self.unstick())

    async def unstick(self):
        app = Gio.Application.get_default()
        if not await app.restart_server():
            self.error_page.set_child(None)
            self.error_page.set_description("No se pudo reiniciar el servidor. Cierra y vuelve a abrir Kaori.")
            return
        self.start(**self.query)

    def start(self, **query):
        if self.task:
            self.task.cancel()
        self.started = True
        self.query = query
        self.loose_filter = None
        self.current = 0
        self.has_next = True
        self.loading = False
        self.grid.remove_all()
        self.stack.set_visible_child_name("loading")
        self.load_next()

    def clear(self):
        if self.task:
            self.task.cancel()
        self.started = False
        self.has_next = False
        self.loading = False
        self.grid.remove_all()

    def load_next(self):
        if self.loading or not self.has_next:
            return
        self.loading = True
        self.page.update_info()
        self.task = asyncio.create_task(self.load(self.current + 1))

    async def load(self, number):
        try:
            mangas, has_next = await self.page.suwayomi.getSourceMangaPage(self.page.model.id, page=number, **self.query)
        except asyncio.CancelledError:
            raise
        except Exception as error:
            self.loading = False
            if number == 1:
                self.show_error(error)
            else:
                self.has_next = False  # stop asking; what loaded so far stays visible
            self.page.update_info()
            return

        if number == 1 and not mangas and self.query.get('query') and self.loose_filter is None:
            mangas, has_next = await self.loose_search()
        if self.loose_filter:
            mangas = [m for m in mangas if loose_match(self.loose_filter, m.title)]

        added = self.grid.append_items(mangas)
        self.current = number
        # A page with nothing new means the source is looping over the same results
        self.has_next = has_next and added > 0
        self.loading = False
        if number == 1:
            self.stack.set_visible_child_name("results" if mangas else "empty")
        self.page.update_info()
        # If the first pages don't fill the window there is nothing to scroll: keep going
        self.grid.check_near_end(self.grid.scrolled.get_vadjustment())


@Gtk.Template(resource_path='/io/github/riyaniii/Kaori/source/page.ui')
class SourcePage(Adw.NavigationPage):
    __gtype_name__ = "KaoriSourcePage"

    model = GObject.Property(type=models.Source)

    search_entry = Gtk.Template.Child()
    filter_button = Gtk.Template.Child()
    source_stack = Gtk.Template.Child()
    settings_button = Gtk.Template.Child()

    count_label = Gtk.Template.Child()
    quick_filters = Gtk.Template.Child()
    more_filters_button = Gtk.Template.Child()
    clear_filters_button = Gtk.Template.Child()
    sort_button = Gtk.Template.Child()

    popular_stack = Gtk.Template.Child()
    popular_grid = Gtk.Template.Child()
    popular_error = Gtk.Template.Child()

    latest_stack = Gtk.Template.Child()
    latest_grid = Gtk.Template.Child()
    latest_error = Gtk.Template.Child()

    search_stack = Gtk.Template.Child()
    search_grid = Gtk.Template.Child()
    search_error = Gtk.Template.Child()

    def __init__(self, model):
        super().__init__()
        self.model = model
        self.suwayomi = Gio.Application.get_default().suwayomi
        self.dialog_changes = []
        self.quick_changes = {}  # top-level filter position -> change, from the bar above the grid
        self.updating_quick = False

        self.pagers = {
            name: Pager(self, getattr(self, f"{name}_stack"), getattr(self, f"{name}_grid"), getattr(self, f"{name}_error"))
            for name in ("popular", "latest", "search")
        }

        self.filter_dialog = SourceFilter()
        self.filter_dialog.connect("applied", self.on_filters_applied)

        self.pagers["popular"].start(fetch_type=SourceMangaType.POPULAR)
        asyncio.create_task(self.load_filters())
        self.settings_button.set_visible(model.is_configurable)

    @property
    def filter_changes(self) -> list:
        """Changes from the filter dialog plus the quick filters (quick ones win on the same filter)."""
        quick_positions = set(self.quick_changes)
        merged = [change for change in self.dialog_changes if change.get("position") not in quick_positions]
        return merged + [{"position": position, **change} for position, change in self.quick_changes.items()]

    @property
    def current_pager(self) -> Pager:
        return self.pagers[self.source_stack.get_visible_child_name()]

    def update_info(self, *args):
        pager = self.current_pager
        count = pager.grid.get_n_items()
        if not pager.started:
            text = ""
        elif pager.loading and count == 0:
            text = "Cargando…"
        else:
            text = f"Mostrando {count} mangas"
            if pager.loading:
                text += " · cargando más…"
            elif not pager.has_next and count:
                text += " · no hay más"
        self.count_label.set_label(text)

        filtered = bool(self.filter_changes)
        self.clear_filters_button.set_visible(filtered)
        on_popular = self.source_stack.get_visible_child_name() == "popular"
        self.quick_filters.set_visible(on_popular)
        if filtered:
            self.filter_button.add_css_class("suggested-action")
        else:
            self.filter_button.remove_css_class("suggested-action")

    async def load_filters(self):
        filters = await self.suwayomi.getSourceFilters(self.model.id)
        self.filter_dialog.set_filters(filters)
        self.more_filters_button.set_visible(bool(filters))
        self.build_quick_filters(filters)

    def build_quick_filters(self, filters):
        """Dropdowns for the source's simple top-level filters (status, type, sort...) right on the page."""
        added = 0
        for position, node in enumerate(filters):
            if node["type"] not in QUICK_FILTER_TYPES or not node["values"] or added >= MAX_QUICK_FILTERS:
                continue
            added += 1
            box = Gtk.Box(spacing=4)
            box.append(Gtk.Label(label=node["name"], css_classes=["dim-label"]))
            dropdown = Gtk.DropDown(model=Gtk.StringList.new(node["values"]), tooltip_text=node["name"])
            default = node["default"]
            if node["type"] == "SortFilter":
                index = (default or {}).get("index")
                dropdown.set_selected(index if index is not None else 0)
            else:
                dropdown.set_selected(default or 0)
            dropdown.connect("notify::selected", self.on_quick_filter_changed, position, node)
            box.append(dropdown)
            self.quick_filters.append(box)

    def on_quick_filter_changed(self, dropdown, pspec, position, node):
        if self.updating_quick:
            return
        index = dropdown.get_selected()
        if node["type"] == "SortFilter":
            ascending = (node["default"] or {}).get("ascending", False)
            self.quick_changes[position] = {"sortState": {"index": index, "ascending": ascending}}
        else:
            self.quick_changes[position] = {"selectState": index}
        self.apply_filters()

    def apply_filters(self):
        """Popular becomes 'explore with filters' when any filter is set; Search uses them too."""
        if self.filter_changes:
            self.pagers["popular"].start(fetch_type=SourceMangaType.SEARCH, filters=self.filter_changes)
        else:
            self.pagers["popular"].start(fetch_type=SourceMangaType.POPULAR)
        if self.search_entry.get_text():
            self.search()
        self.update_info()

    def on_filters_applied(self, dialog, changes):
        self.dialog_changes = changes
        if self.source_stack.get_visible_child_name() == "search":
            self.search()
            self.update_info()
        else:
            self.apply_filters()

    @Gtk.Template.Callback()
    def on_clear_filters_clicked(self, *_):
        self.dialog_changes = []
        self.quick_changes = {}
        self.filter_dialog.rebuild()
        self.updating_quick = True
        for box in list(self.quick_filters):
            self.quick_filters.remove(box)
        self.updating_quick = False
        self.build_quick_filters(self.filter_dialog.filters)
        self.apply_filters()

    @Gtk.Template.Callback()
    def on_sort_toggled(self, button):
        for pager in self.pagers.values():
            pager.grid.set_sorted(button.get_active())

    @Gtk.Template.Callback()
    def on_near_end(self, grid):
        for pager in self.pagers.values():
            if pager.grid is grid and pager.started:
                pager.load_next()

    @Gtk.Template.Callback()
    def on_page_changed(self, stack, pspec):
        if stack.get_visible_child_name() == "latest" and not self.pagers["latest"].started:
            self.pagers["latest"].start(fetch_type=SourceMangaType.LATEST)
        self.update_info()

    @Gtk.Template.Callback()
    def is_search_page(self, obj, page_name):
        return page_name == "search"

    @Gtk.Template.Callback()
    def on_search_entry_activate(self, entry):
        self.search()

    def search(self):
        text = self.search_entry.get_text()
        if text or self.filter_changes:
            self.pagers["search"].start(
                fetch_type=SourceMangaType.SEARCH,
                query=text or None,
                filters=self.filter_changes,
            )
        else:
            self.pagers["search"].clear()
            self.search_stack.set_visible_child_name("normal")
        self.update_info()

    @Gtk.Template.Callback()
    def on_filter_clicked(self, *_):
        self.filter_dialog.present(self)

    @Gtk.Template.Callback()
    def on_source_settings_clicked(self, *_):
        dialog = SourcePreferencesDialog(self.suwayomi, self.model)
        dialog.connect("changed", lambda dialog: self.reload_after_settings())
        dialog.present(self)

    def reload_after_settings(self):
        """Settings like "show NSFW" change what the source lists: load everything again."""
        self.apply_filters()
        if self.pagers["latest"].started:
            self.pagers["latest"].start(fetch_type=SourceMangaType.LATEST)
