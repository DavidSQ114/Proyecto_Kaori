import asyncio
import time
from gi.repository import Adw, Gio, GObject, Gtk

from ..containers import MangaRow
from .compare import ComparePage
from ...integrations.suwayomi import SourceMangaType
from ...integrations.names import looks_spanish
from ...integrations.compare import MIN_TITLE_SIMILARITY, loose_match, loose_queries, normalize, plain_ratio, similarity

SOURCE_BUDGET = 25  # s a source may spend trying further names
SECOND_ROUND_NAMES = 2  # titles found in some sources, tried in the ones that found nothing
MAX_TITLE_TRIES = 7  # names to try per source when a lookup (ranking, Para ti) has several
# Nonsense query: whatever a source returns for it is a fixed block (some broken searches always
# return "featured" series, e.g. AKAYA), not real results.
CANARY_QUERY = "zqxjvkaori"


SHORT_NAME_WORDS = 2  # names this short must look like the whole title, not just appear in it
SHORT_NAME_SIMILARITY = 0.8


def is_relevant(title: str, names: list[str]) -> bool:
    """The result looks like one of the series' names. A one- or two-word name ("Preparación",
    "Set Up") has to resemble the whole title: "Academia de preparación" merely contains it."""
    for name in names:
        if len([w for w in normalize(name).split() if len(w) > 2]) <= SHORT_NAME_WORDS:
            if plain_ratio(name, title) >= SHORT_NAME_SIMILARITY:
                return True
        elif similarity(name, title) >= MIN_TITLE_SIMILARITY or loose_match(name, title):
            return True
    return False


@Gtk.Template(resource_path='/io/github/riyaniii/Kaori/pages/search.ui')
class SearchPage(Adw.NavigationPage):
    __gtype_name__ = "KaoriSearchPage"

    main_box = Gtk.Template.Child()
    search_entry = Gtk.Template.Child()
    compare_button = Gtk.Template.Child()
    searching_title = Gtk.Template.Child()
    searching_names = Gtk.Template.Child()
    searching_progress = Gtk.Template.Child()

    state = GObject.Property(type=str, default="greeter")
    completed_sources = GObject.Property(type=int, default=0)
    total_sources = GObject.Property(type=int, default=0)

    def __init__(self):
        super().__init__()
        self.suwayomi = Gio.Application.get_default().suwayomi
        self.search_task = None
        self.results = []  # (source, mangas) of the last search, for the comparison
        self.found = {}  # source id -> (source, mangas shown)
        self.last_query = ""
        self.fixed = {}  # source id -> task giving the ids it returns for any query (once per session)
        self.connect("notify::completed-sources", self.update_searching_progress)
        self.connect("notify::total-sources", self.update_searching_progress)

    def update_searching_progress(self, *args):
        if self.total_sources:
            self.searching_progress.set_label(f"{min(self.completed_sources, self.total_sources)} de "
                                              f"{self.total_sources} búsquedas terminadas")
        else:
            self.searching_progress.set_label("")

    def reset_progress(self):
        self.completed_sources = self.total_sources = 0

    @Gtk.Template.Callback()
    def get_progress(self, obj, completed, total):
        return completed / total if total else 0.0

    async def fixed_results(self, source) -> set:
        async def probe():
            try:
                mangas = await self.suwayomi.getSourceManga(source.id, fetch_type=SourceMangaType.SEARCH,
                                                            query=CANARY_QUERY)
            except Exception:
                return set()
            return {manga.id for manga in mangas}

        if source.id not in self.fixed:
            self.fixed[source.id] = asyncio.ensure_future(probe())
        return await asyncio.shield(self.fixed[source.id])

    async def search_source(self, source, row, queries, relevant_to=None, keep=False):
        """Search one source; with several names (English, Spanish…), it keeps trying until one of
        them gives results there: Spanish scans list series under their own names.

        keep: what the source already shows stays if no name finds anything better."""
        queries = [queries] if isinstance(queries, str) else queries
        if relevant_to is None and len(queries) > 1:
            relevant_to = queries
        mangas, query = [], queries[0]
        started = time.monotonic()
        for index, query in enumerate(queries):
            if index and time.monotonic() - started > SOURCE_BUDGET:
                break  # a slow source (some take 15 s per search) doesn't get to try every name
            # Accent / stem retries only where they pay off: the typed text and the Spanish names
            loose = len(queries) == 1 or looks_spanish(query)
            mangas = await self.search_one(source, query, loose=loose)
            if relevant_to:
                # Several names: keep only what looks like one of them, else try the next name
                # (a source answering "Ctrl+Alt+Resign" with "Yuri Is My Job" hasn't found it)
                mangas = [m for m in mangas if is_relevant(m.title, relevant_to)]
            if mangas:
                break
        fixed = await self.fixed_results(source) if mangas else set()
        # Drop the source's fixed block unless an item really matches what was searched
        mangas = [manga for manga in mangas
                  if manga.id not in fixed or similarity(query, manga.title) >= MIN_TITLE_SIMILARITY]
        if not keep:
            self.completed_sources += 1
        if mangas or not keep:
            self.show_found(source, row, mangas)

    def show_found(self, source, row, mangas):
        self.found[source.id] = (source, mangas)
        self.results = [(s, m) for s, m in self.found.values() if m]
        row.set_items(mangas)
        row.set_visible(bool(mangas))
        self.compare_button.set_sensitive(bool(self.results))

    async def search_one(self, source, query, loose=True):
        # One request at a time per source: sources that search through a hidden browser (Ikigai)
        # hang when two searches start it at once, and then fail until the server restarts
        mangas = await self.suwayomi.getSourceManga(source.id, fetch_type=SourceMangaType.SEARCH, query=query)
        # Nothing for the exact text: retry without accents / with a word stem ("operacion" -> "Operación")
        for alternative, needs_filter in ([] if mangas or not loose else loose_queries(query)):
            try:
                found = await self.suwayomi.getSourceManga(source.id, fetch_type=SourceMangaType.SEARCH,
                                                           query=alternative)
            except Exception:
                continue
            mangas = [m for m in found if loose_match(query, m.title)] if needs_filter else found
            if mangas:
                break
        return mangas

    async def search(self, query):
        """Search every source for `query`, a text or a list of names for the same series.

        A known series (typed by name, or from the ranking / Para ti) is searched with all its names
        (English, Spanish, translations), only results that look like it are kept, and they're shown
        together once every source answered. Free text ("cambio de traba") is a normal search whose
        results show as they arrive."""
        typed = isinstance(query, str)
        self.last_query = query if typed else query[0]
        self.results = []
        self.found = {}
        self.compare_button.set_sensitive(False)
        self.searching_title.set_label("Reconociendo la serie…")
        self.searching_names.set_label("")
        self.state = "searching"
        names = list(query) if not typed else [query]
        if typed:
            try:
                names = await Gio.Application.get_default().names.for_typed(query)
            except Exception as error:
                print(f"[search] no se pudieron obtener los nombres de {query!r}: {error!r}")
                names = [query]
        known = len(names) > 1
        self.last_names = names
        print(f"[search] {query!r}: {'serie conocida' if known else 'texto libre'} -> {names}")
        if known:
            self.searching_title.set_label("Buscando en todas las fuentes con sus diferentes nombres…")
            self.searching_names.set_label("  ·  ".join(f"«{name}»" for name in names))
        else:
            self.state = "result"

        await self.suwayomi.refreshSources()
        sources = list(self.suwayomi.sources)
        self.total_sources = len(sources)
        rows = [MangaRow(source.name, source.id) for source in sources]
        for row in rows:
            row.set_visible(False)
            self.main_box.append(row)

        await asyncio.gather(
            *(self.search_source(s, r, names if known else query) for s, r in zip(sources, rows)),
            return_exceptions=True,
        )
        if known:
            await self.second_round(names, sources, rows)
        self.reset_progress()
        found = any(row.get_visible() for row in rows)
        self.state = "result" if found else "empty"
        return found

    def has_relevant(self, source, names):
        _, mangas = self.found.get(source.id, (source, []))
        return any(is_relevant(m.title, names) for m in mangas)

    async def second_round(self, names, sources, rows):
        """The names some sources answered with ("Cambio de trabajo" for "Ctrl+Alt+Resign"), asked to
        the sources that found nothing. One round only, never a name already tried: no loops."""
        tried = {normalize(name) for name in names}
        counts, originals = {}, {}
        for _, mangas in self.results:
            for manga in mangas:
                key = normalize(manga.title)
                if key and key not in tried and is_relevant(manga.title, names):
                    counts[key] = counts.get(key, 0) + 1
                    originals.setdefault(key, manga.title.strip(" ."))
        new = [originals[key] for key, _ in sorted(counts.items(), key=lambda item: -item[1])][:SECOND_ROUND_NAMES]
        empty = [(source, row) for source, row in zip(sources, rows) if not self.has_relevant(source, names)]
        if not new or not empty:
            return
        self.total_sources += len(empty)
        await asyncio.gather(
            *(self.search_source(source, row, new, relevant_to=list(names) + new, keep=True) for source, row in empty),
            return_exceptions=True,
        )

    def clear(self):
        if self.search_task:
            self.search_task.cancel()
        for child in list(self.main_box):
            self.main_box.remove(child)
        self.reset_progress()

    def to_start(self):
        """Clicking Search again in the sidebar: ready to type another search (results stay)."""
        self.search_entry.grab_focus()
        self.search_entry.select_region(0, -1)

    @Gtk.Template.Callback()
    def on_search_entry_activate(self, entry):
        self.clear()
        if text := entry.get_text():
            self.search_task = asyncio.create_task(self.search(text))
        else:
            self.state = "greeter"

    def search_titles(self, titles: list[str], compare: bool = False):
        """Search every source for the first title that gives results (used by the ranking).
        With compare, open the source comparison as soon as the results are in."""
        self.clear()
        self.search_task = asyncio.create_task(self.search_alternatives(titles[:MAX_TITLE_TRIES], compare))

    async def search_alternatives(self, titles, compare=False):
        titles = list(dict.fromkeys(t for t in titles if t))
        if not titles:
            return
        self.search_entry.set_text(titles[0])
        if await self.search(titles) and compare and self.results:
            self.on_compare_clicked(None)

    @Gtk.Template.Callback()
    def on_compare_clicked(self, button):
        if self.results:
            self.get_ancestor(Adw.NavigationView).push(ComparePage(self.last_query, list(self.results),
                                                                       getattr(self, "last_names", None)))
