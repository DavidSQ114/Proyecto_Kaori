import asyncio

from gi.repository import Gtk, Adw, Gio, GLib, GObject
from ..manga import MangaCard
from . import covers
from ...integrations import models

NEAR_END_DISTANCE = 800  # px from the bottom at which the next page is requested


def compare_titles(a, b, *args):
    a, b = (a.title or "").casefold(), (b.title or "").casefold()
    return (a > b) - (a < b)


@Gtk.Template(resource_path='/io/github/riyaniii/Kaori/containers/manga_grid.ui')
class MangaGrid(Adw.BreakpointBin):
    __gtype_name__ = 'KaoriMangaGrid'

    grid = Gtk.Template.Child()
    scrolled = Gtk.Template.Child()

    @GObject.Signal
    def near_end(self):
        """Scrolled close to the bottom (or the content doesn't fill the view): time for another page."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.search_text = ""
        self.suwayomi = Gio.Application.get_default().suwayomi
        self.extra_filter = None  # item -> bool, on top of the search (the Library's status tabs)
        self.context_menu = None  # card -> None, on right click (the Library's status menu)
        self.custom_sorter = None

        self.store = Gio.ListStore(item_type=models.Manga)

        self.custom_filter = Gtk.CustomFilter.new(self.filter_func)
        self.filter_model = Gtk.FilterListModel(model=self.store, filter=self.custom_filter)
        self.sorter = Gtk.CustomSorter.new(compare_titles)
        self.sort_model = Gtk.SortListModel(model=self.filter_model, sorter=None)

        selection = Gtk.NoSelection(model=self.sort_model)
        self.grid.set_model(selection)

        adjustment = self.scrolled.get_vadjustment()
        adjustment.connect("value-changed", self.check_near_end)
        adjustment.connect("notify::upper", self.check_near_end)
        adjustment.connect("notify::page-size", self.check_near_end)
        self.grid.connect('activate', self.on_activate)

        factory = Gtk.SignalListItemFactory()
        factory.connect('setup', self.on_setup)
        factory.connect('bind', self.on_bind)
        factory.connect('unbind', self.on_unbind)
        self.grid.set_factory(factory)

    def bind_store(self, store: Gio.ListStore):
        self.store = store
        self.filter_model.set_model(store)

    def filter_func(self, item):
        title = (item.title or "").lower()
        return self.search_text in title and (self.extra_filter is None or self.extra_filter(item))

    def set_sort(self, compare):
        """Order the cards with compare(a, b) -> -1 / 0 / 1."""
        self.custom_sorter = Gtk.CustomSorter.new(lambda a, b, *_: compare(a, b))
        self.sort_model.set_sorter(self.custom_sorter)

    def refresh_view(self):
        """The filter or the order depend on something that changed (a status, the chosen tab)."""
        self.custom_filter.changed(Gtk.FilterChange.DIFFERENT)
        if self.custom_sorter is not None:
            self.custom_sorter.changed(Gtk.SorterChange.DIFFERENT)

    def set_search_text(self, text: str):
        self.search_text = text.strip().lower()
        self.custom_filter.changed(Gtk.FilterChange.DIFFERENT)

    def on_setup(self, factory, list_item):
        child = MangaCard()
        child.thumbnail_task = None
        right_click = Gtk.GestureClick(button=3)
        right_click.connect("pressed", lambda gesture, n, x, y, card=child:
                            self.context_menu(card) if self.context_menu and card.model else None)
        child.add_controller(right_click)
        list_item.set_child(child)

    def on_bind(self, factory, list_item):
        item = list_item.get_item()
        card = list_item.get_child()
        card.model = item
        covers.retain(item)

        if item.paintable is None and item.thumbnail_url:
            card.thumbnail_task = asyncio.create_task(self.load_thumbnail(item))

    def on_unbind(self, factory, list_item):
        card = list_item.get_child()
        if card.thumbnail_task:
            card.thumbnail_task.cancel()
            card.thumbnail_task = None

        covers.release(list_item.get_item())

        card.model = None

    async def load_thumbnail(self, item):
        try:
            paintable = await covers.load(self.suwayomi, item.id, item.thumbnail_url, identify=item.in_library)
        except asyncio.CancelledError:
            raise
        except Exception:
            paintable = None
        if paintable:
            item.paintable = paintable
        item.cover_failed = paintable is None

    def on_activate(self, grid_view, position):
        item = self.sort_model.get_item(position)
        grid_view.activate_action("app.show_manga", GLib.Variant("i", item.id))

    def check_near_end(self, adjustment, *args):
        if self.store.get_n_items() == 0 or not self.get_mapped():
            return
        remaining = adjustment.get_upper() - adjustment.get_value() - adjustment.get_page_size()
        if remaining < NEAR_END_DISTANCE:
            self.emit("near-end")

    def set_sorted(self, alphabetical: bool):
        self.sort_model.set_sorter(self.sorter if alphabetical else None)

    def get_n_items(self) -> int:
        return self.store.get_n_items()

    def remove_all(self):
        self.store.remove_all()
        self.scrolled.get_vadjustment().set_value(0)

    def set_items(self, items: list):
        self.store.splice(0, self.store.get_n_items(), items)

    def append_items(self, items: list) -> int:
        """Add the next page, skipping series already shown (sources sometimes repeat them)."""
        known = {item.id for item in self.store}
        new = [item for item in items if item.id not in known]
        self.store.splice(self.store.get_n_items(), 0, new)
        return len(new)
