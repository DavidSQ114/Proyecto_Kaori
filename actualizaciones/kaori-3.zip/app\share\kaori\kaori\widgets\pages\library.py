"""Biblioteca: your series as a tracker. Tabs by status (Leyendo, Pendiente, Completada, Abandonada),
several orders, and a right click on a cover to change its status."""
import asyncio
import re
from gi.repository import Adw, Gio, GLib, GObject, Gtk

from ..manga import MangaCard
from ..containers import MangaGrid
from ...tracker import STATUSES

SORTS = [  # (id, name)
    ("updated", "Actualizada recientemente"),
    ("name", "Nombre"),
    ("progress", "Progreso"),
    ("added", "Añadida recientemente"),
]


def title_key(manga) -> str:
    return (manga.title or "").casefold()


def progress(manga) -> float:
    return manga.read_fraction


def chapter_number(entry, suwayomi) -> float | None:
    """The number of the chapter you left a series at (Tus Lecturas)."""
    chapter = suwayomi.getModel(entry.get('chapter_id'), 'Chapter')
    if chapter is not None and chapter.chapter_number >= 0:
        return chapter.chapter_number
    match = re.search(r"(\d+(?:[.,]\d+)?)", entry.get('chapter_name') or "")
    return float(match.group(1).replace(",", ".")) if match else None


def added(manga) -> float:
    try:
        return float(manga.in_library_at or 0)
    except ValueError:
        return 0.0


def compare(a, b) -> int:
    return (a > b) - (a < b)


@Gtk.Template(resource_path='/io/github/riyaniii/Kaori/pages/library.ui')
class LibraryPage(Adw.NavigationPage):
    __gtype_name__ = "KaoriLibraryPage"

    manga_grid = Gtk.Template.Child()
    grid_view = Gtk.Template.Child()

    library_size = GObject.Property(type=int, default=0)

    def __init__(self):
        super().__init__()
        app = Gio.Application.get_default()
        self.suwayomi = app.suwayomi
        self.tracker = app.tracker
        self.settings = app.settings

        library = self.suwayomi.library
        self.manga_grid.bind_store(library)
        library.bind_property("n-items", self, "library_size", GObject.BindingFlags.SYNC_CREATE)

        # Status tabs and the order, under the search bar
        bar = Gtk.Box(spacing=12, margin_start=18, margin_end=18, margin_top=4, margin_bottom=8)
        self.tabs = Adw.ToggleGroup(tooltip_text="Clic derecho en una portada para cambiar su estado")
        self.toggles = {"all": Adw.Toggle(name="all", label="Todas")}
        self.tabs.add(self.toggles["all"])
        for status, name in STATUSES:
            self.toggles[status] = Adw.Toggle(name=status, label=name)
            self.tabs.add(self.toggles[status])
        self.tabs.set_active_name(self.settings.get_string("library-tab"))
        self.tabs.connect("notify::active-name", self.on_tab_changed)
        bar.append(self.tabs)
        bar.append(Gtk.Box(hexpand=True))
        bar.append(Gtk.Label(label="Ordenar:", css_classes=["dim-label"]))
        self.sort = Gtk.DropDown.new_from_strings([name for _, name in SORTS])
        saved = self.settings.get_string("library-sort")
        self.sort.set_selected(next((i for i, (sid, _) in enumerate(SORTS) if sid == saved), 0))
        self.sort.connect("notify::selected", self.on_sort_changed)
        bar.append(self.sort)
        self.grid_view.add_top_bar(bar)

        self.manga_grid.extra_filter = self.in_tab
        self.manga_grid.context_menu = self.show_status_menu
        self.manga_grid.set_sort(self.compare)

        self.history = app.history
        self.positions_task = None
        self.tracker.connect("changed", lambda *_: self.refresh())
        self.history.connect("changed", lambda *_: self.update_positions())
        library.connect("items-changed", lambda *_: GLib.idle_add(self.refresh_idle))
        asyncio.create_task(self.load())

    async def load(self):
        await self.suwayomi.refreshLibrary()
        await self.compute_positions()

    def update_positions(self):
        if self.positions_task is None or self.positions_task.done():
            self.positions_task = asyncio.create_task(self.compute_positions())

    async def compute_positions(self):
        """Chapters ahead of where you left each series, and how far into it you are: one query."""
        try:
            series = await self.suwayomi.getScheduleData([manga.id for manga in self.suwayomi.library])
        except Exception:
            series = []
        for item in series:
            model = self.suwayomi.getModel(item['id'], 'Manga')
            if model is None:
                continue
            numbers = sorted({c['number'] for c in item['chapters'] if c['number'] is not None and c['number'] >= 0})
            entry = self.history.entries.get(str(item['id']))
            current = chapter_number(entry, self.suwayomi) if entry else None
            if current is None or not numbers:
                model.chapters_ahead, model.read_fraction = 0, 0.0
            else:
                model.chapters_ahead = sum(1 for n in numbers if n > current)
                model.read_fraction = sum(1 for n in numbers if n <= current) / len(numbers)
        self.refresh()

    def refresh_idle(self):
        self.refresh()
        return GLib.SOURCE_REMOVE

    def refresh(self):
        counts = {status: 0 for status, _ in STATUSES}
        for manga in self.suwayomi.library:
            counts[self.tracker.status_of(manga)] += 1
        self.toggles["all"].set_label(f"Todas · {self.suwayomi.library.get_n_items()}")
        for status, name in STATUSES:
            self.toggles[status].set_label(f"{name} · {counts[status]}")
        self.manga_grid.refresh_view()

    # --- tabs and order ---

    def in_tab(self, manga) -> bool:
        tab = self.tabs.get_active_name()
        return tab in (None, "all") or self.tracker.status_of(manga) == tab

    def on_tab_changed(self, *args):
        self.settings.set_string("library-tab", self.tabs.get_active_name() or "all")
        self.manga_grid.refresh_view()

    def on_sort_changed(self, *args):
        self.settings.set_string("library-sort", SORTS[self.sort.get_selected()][0])
        self.manga_grid.refresh_view()

    def compare(self, a, b) -> int:
        order = SORTS[self.sort.get_selected()][0]
        if order == "updated":
            result = compare(b.latest_update, a.latest_update)
        elif order == "progress":
            result = compare(progress(b), progress(a))
        elif order == "added":
            result = compare(added(b), added(a))
        else:
            result = 0
        return result or compare(title_key(a), title_key(b))

    # --- right click: change the status ---

    def show_status_menu(self, card):
        manga = card.model
        current = self.tracker.status_of(manga)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, margin_top=6, margin_bottom=6,
                      margin_start=6, margin_end=6)
        box.append(Gtk.Label(label=manga.title, xalign=0, max_width_chars=28, wrap=True,
                             css_classes=["heading"], margin_bottom=4))
        popover = Gtk.Popover(child=box, has_arrow=True)
        for status, name in STATUSES:
            button = Gtk.Button(css_classes=["flat"])
            button.set_child(Gtk.Label(label=("✓  " if status == current else "     ") + name, xalign=0))
            button.connect("clicked", lambda b, s=status: (popover.popdown(), self.tracker.set_status(manga.id, s)))
            box.append(button)
        if self.tracker.is_chosen(manga.id):
            auto = Gtk.Button(css_classes=["flat"], tooltip_text="Kaori elige según lo que lees")
            auto.set_child(Gtk.Label(label="     Automático", xalign=0, css_classes=["dim-label"]))
            auto.connect("clicked", lambda b: (popover.popdown(), self.tracker.set_status(manga.id, None)))
            box.append(auto)
        popover.set_parent(card)
        popover.connect("closed", lambda p: GLib.idle_add(lambda: p.unparent() or GLib.SOURCE_REMOVE))
        popover.popup()

    @Gtk.Template.Callback()
    def get_page(self, obj, size):
        return "grid" if size > 0 else "greeter"

    @Gtk.Template.Callback()
    def on_search_changed(self, entry):
        self.manga_grid.set_search_text(entry.get_text())
