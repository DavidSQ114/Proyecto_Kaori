"""Read-only client for the public AniList GraphQL API (no account or key needed), used for rankings."""
import asyncio
import json
import re
import unicodedata
import os
import time

import httpx
from gi.repository import GLib

API_URL = "https://graphql.anilist.co"
CACHE_TTL = 24 * 3600  # rankings change slowly; refresh at most once a day
RECS_TTL = 7 * 86400  # a series' community recommendations: they grow slowly
STAFF_TTL = 30 * 86400  # who made a series and what else they made: almost never changes
PER_PAGE = 50

SORTS = {
    "score": "SCORE_DESC",
    "popularity": "POPULARITY_DESC",
    "trending": "TRENDING_DESC",
}
COUNTRIES = {"all": None, "manga": "JP", "manhwa": "KR", "manhua": "CN"}
# Adult content filter: AniList's isAdult flag (explicit works)
ADULT = {"no": "false", "only": "true", "all": None}
# Romance between men / women: AniList has them as tags with a relevance %; below this it's just a side element
BL_TAG, GL_TAG, MIN_TAG_RANK = "Boys' Love", "Yuri", 60
# Romance filter, applied by AniList itself so every page is full and the ranks are real
ROMANCE = {
    "all": "",
    "bl": f', tag_in: ["{BL_TAG}"], minimumTagRank: {MIN_TAG_RANK}',
    "gl": f', tag_in: ["{GL_TAG}"], minimumTagRank: {MIN_TAG_RANK}',
    # Excluding works with AniList's default tag threshold; combined with minimumTagRank it lets BL through
    "none": f', tag_not_in: ["{BL_TAG}", "{GL_TAG}"]',
}
COUNTRY_NAMES = {"JP": "Manga", "KR": "Manhwa", "CN": "Manhua", "TW": "Manhua"}

QUERY = """
query ($page: Int, $perPage: Int, $sort: [MediaSort]%(country_var)s) {
  Page(page: $page, perPage: $perPage) {
    pageInfo { hasNextPage }
    media(type: MANGA, sort: $sort%(country_arg)s%(adult_arg)s%(romance_arg)s, format_not: NOVEL) {
      id
      title { romaji english }
      synonyms
      averageScore
      popularity
      countryOfOrigin
      isAdult
      genres
      tags { name rank }
      coverImage { large }
    }
  }
}
"""


DETAILS_QUERY = """
query ($id: Int) {
  Media(id: $id) {
    title { romaji english native }
    description(asHtml: false)
    status
    format
    chapters
    volumes
    startDate { year }
    endDate { year }
    averageScore
    popularity
    favourites
    genres
    siteUrl
    countryOfOrigin
    coverImage { extraLarge }
    reviews(sort: RATING_DESC, perPage: 3) {
      nodes { summary score rating ratingAmount siteUrl user { name } }
    }
  }
}
"""


BY_ID_RECOMMENDATIONS_QUERY = """
query ($id: Int) {
  Media(id: $id, type: MANGA) {
    recommendations(sort: RATING_DESC, perPage: 25) {
      nodes { rating mediaRecommendation { %(fields)s } }
    }
  }
}
"""

STAFF_OF_MEDIA_QUERY = """
query ($id: Int) {
  Media(id: $id, type: MANGA) {
    staff(perPage: 10, sort: [RELEVANCE]) { edges { role node { id name { full native } } } }
  }
}
"""

STAFF_WORKS_QUERY = """
query ($id: Int) {
  Staff(id: $id) {
    name { full native }
    staffMedia(type: MANGA, sort: [POPULARITY_DESC], perPage: 25) { edges { staffRole node { %(fields)s } } }
  }
}
"""

# Roles that make a series "theirs" (not translators, letterers, assistants...)
CREATOR_ROLES = ("story", "art", "original")


def creator_role(role: str) -> str | None:
    """"Story & Art" -> "Historia y arte", "Original Creator" -> "Obra original"; None for other roles."""
    role = (role or "").casefold()
    if not any(word in role for word in CREATOR_ROLES):
        return None
    if "original" in role:
        return "Obra original"
    if "story" in role and "art" in role:
        return "Historia y arte"
    return "Historia" if "story" in role else "Arte"


SEARCH_QUERY = """
query ($search: String) {
  Page(perPage: 8) {
    media(search: $search, type: MANGA, format_not: NOVEL) { %(fields)s }
  }
}
"""

RECOMMENDATIONS_QUERY = """
query ($search: String) {
  Media(search: $search, type: MANGA) {
    id
    title { romaji english native }
    synonyms
    recommendations(sort: RATING_DESC, perPage: 16) {
      nodes { mediaRecommendation { %(fields)s } }
    }
  }
}
"""

BY_GENRE_QUERY = """
query ($genres: [String]) {
  Page(perPage: 16) {
    media(type: MANGA, genre_in: $genres, sort: POPULARITY_DESC, isAdult: false, format_not: NOVEL) { %(fields)s }
  }
}
"""

MEDIA_FIELDS = ("id title { romaji english } synonyms averageScore popularity countryOfOrigin isAdult genres "
                "tags { name rank } coverImage { large }")

# Genre names the Spanish sources use -> AniList's (normalized: lowercase, no accents)
GENRES_ES = {
    "accion": "Action", "action": "Action", "aventura": "Adventure", "adventure": "Adventure",
    "comedia": "Comedy", "comedy": "Comedy", "drama": "Drama", "ecchi": "Ecchi",
    "fantasia": "Fantasy", "fantasy": "Fantasy", "terror": "Horror", "horror": "Horror",
    "misterio": "Mystery", "mystery": "Mystery", "psicologico": "Psychological", "psychological": "Psychological",
    "romance": "Romance", "ciencia ficcion": "Sci-Fi", "sci-fi": "Sci-Fi", "sci fi": "Sci-Fi",
    "recuentos de la vida": "Slice of Life", "vida cotidiana": "Slice of Life", "slice of life": "Slice of Life",
    "deportes": "Sports", "deporte": "Sports", "sports": "Sports", "sobrenatural": "Supernatural",
    "supernatural": "Supernatural", "suspenso": "Thriller", "suspense": "Thriller", "thriller": "Thriller",
    "mecha": "Mecha", "musica": "Music", "music": "Music",
}
# A title search counts as the same series from this similarity on (any of its AniList names)
MIN_TITLE_MATCH = 0.75


# AniList allows a limited number of requests per minute and answers 429 beyond that: every
# request in Kaori (rankings, recommendations, identification) goes through one paced queue.
REQUEST_GAP = 0.8
MAX_RETRIES = 3
_lock = None
_last = 0.0


async def throttled_post(http, payload):
    global _lock, _last
    if _lock is None:
        _lock = asyncio.Lock()
    for attempt in range(MAX_RETRIES + 1):
        async with _lock:
            wait = _last + REQUEST_GAP - time.monotonic()
            if wait > 0:
                await asyncio.sleep(wait)
            try:
                response = await http.post(API_URL, json=payload)
            finally:
                _last = time.monotonic()
            if response.status_code == 429 and attempt < MAX_RETRIES:
                # Told to slow down: wait what it asks (holding the queue) and try again
                await asyncio.sleep(min(float(response.headers.get("Retry-After", 10) or 10), 60))
                continue
        return response
    return response


class AniList:
    def __init__(self):
        self.http = httpx.AsyncClient(timeout=20, headers={"Accept": "application/json"})
        self.cache_dir = os.path.join(GLib.get_user_cache_dir(), "kaori", "anilist")

    def cache_path(self, sort, country, page, adult="no", romance="all"):
        return os.path.join(self.cache_dir, f"v2-{sort}-{country}-{adult}-{romance}-{page}.json")  # v2: BL/GL tags

    async def ranking(self, sort: str = "score", country: str = "all", page: int = 1,
                      adult: str = "no", romance: str = "all") -> tuple[list[dict], bool]:
        """Returns (entries, has_next_page). Each entry is a plain dict ready for the UI."""
        path = self.cache_path(sort, country, page, adult, romance)
        try:
            if time.time() - os.path.getmtime(path) < CACHE_TTL:
                with open(path, encoding="utf-8") as file:
                    data = json.load(file)
                return data["entries"], data["has_next"]
        except (OSError, ValueError, KeyError):
            pass

        variables = {"page": page, "perPage": PER_PAGE, "sort": [SORTS[sort]]}
        # A null countryOfOrigin would match nothing, so only add the filter when one is chosen
        if code := COUNTRIES[country]:
            variables["country"] = code
            fill = {"country_var": ", $country: CountryCode", "country_arg": ", countryOfOrigin: $country"}
        else:
            fill = {"country_var": "", "country_arg": ""}
        fill["adult_arg"] = f", isAdult: {ADULT[adult]}" if ADULT[adult] else ""
        fill["romance_arg"] = ROMANCE[romance]
        query = QUERY % fill
        response = await throttled_post(self.http, {"query": query, "variables": variables})
        response.raise_for_status()
        result = response.json()["data"]["Page"]

        offset = (page - 1) * PER_PAGE
        entries = [self.entry(media, offset + index + 1) for index, media in enumerate(result["media"])]
        has_next = result["pageInfo"]["hasNextPage"]

        os.makedirs(self.cache_dir, exist_ok=True)
        with open(path, "w", encoding="utf-8") as file:
            json.dump({"entries": entries, "has_next": has_next}, file, ensure_ascii=False)
        return entries, has_next

    async def details(self, media_id: int) -> dict:
        """Synopsis, publication info and the top community reviews of one series."""
        path = os.path.join(self.cache_dir, f"media-{media_id}.json")
        try:
            if time.time() - os.path.getmtime(path) < CACHE_TTL:
                with open(path, encoding="utf-8") as file:
                    return json.load(file)
        except (OSError, ValueError):
            pass

        response = await throttled_post(self.http, {"query": DETAILS_QUERY, "variables": {"id": media_id}})
        response.raise_for_status()
        media = response.json()["data"]["Media"]

        os.makedirs(self.cache_dir, exist_ok=True)
        with open(path, "w", encoding="utf-8") as file:
            json.dump(media, file, ensure_ascii=False)
        return media

    async def cached_post(self, name: str, query: str, variables: dict, ttl: float = CACHE_TTL) -> dict:
        path = os.path.join(self.cache_dir, name)
        stale = None
        try:
            with open(path, encoding="utf-8") as file:
                stale = json.load(file)
            if time.time() - os.path.getmtime(path) < ttl:
                return stale
        except (OSError, ValueError):
            pass
        try:
            response = await throttled_post(self.http, {"query": query, "variables": variables})
            if response.status_code == 404:  # Media(search:) found nothing
                data = {"Media": None}
            else:
                response.raise_for_status()
                data = response.json()["data"]
        except Exception:
            if stale is not None:  # AniList down or limiting: an old answer beats none
                return stale
            raise
        os.makedirs(self.cache_dir, exist_ok=True)
        with open(path, "w", encoding="utf-8") as file:
            json.dump(data, file, ensure_ascii=False)
        return data

    async def recommendations_for(self, anilist_id: int, include_adult=False) -> list[dict]:
        """AniList's community recommendations for a series already identified. Each entry carries
        `rating`: how many readers upvoted that recommendation."""
        data = await self.cached_post(f"rec-id3-{anilist_id}.json", BY_ID_RECOMMENDATIONS_QUERY % {"fields": MEDIA_FIELDS},
                                      {"id": anilist_id}, ttl=RECS_TTL)
        nodes = ((data.get("Media") or {}).get("recommendations") or {}).get("nodes") or []
        entries = []
        for node in nodes:
            media = node.get("mediaRecommendation")
            if media and (include_adult or not media.get("isAdult")):
                entries.append({**self.entry(media, 0), "rating": node.get("rating") or 0})
        return entries

    async def creators_of(self, anilist_id: int) -> list[dict]:
        """Who wrote / drew a series: [{id, name, role}] (role in Spanish)."""
        data = await self.cached_post(f"staff-of-{anilist_id}.json", STAFF_OF_MEDIA_QUERY, {"id": anilist_id},
                                      ttl=STAFF_TTL)
        edges = (((data.get("Media") or {}).get("staff") or {}).get("edges")) or []
        creators = {}
        for edge in edges:
            role = creator_role(edge.get("role"))
            node = edge.get("node") or {}
            if role and node.get("id") and node["id"] not in creators:
                creators[node["id"]] = {"id": node["id"], "name": node["name"].get("full") or node["name"].get("native"),
                                        "role": role}
        return list(creators.values())

    async def works_of(self, staff_id: int, include_adult=False) -> tuple[str, list[dict]]:
        """(name, the series they wrote or drew), most popular first."""
        data = await self.cached_post(f"staff-works-{staff_id}.json", STAFF_WORKS_QUERY % {"fields": MEDIA_FIELDS},
                                      {"id": staff_id}, ttl=STAFF_TTL)
        staff = data.get("Staff") or {}
        name = (staff.get("name") or {}).get("full") or ""
        works, seen = [], set()
        for edge in ((staff.get("staffMedia") or {}).get("edges")) or []:
            media = edge.get("node")
            role = creator_role(edge.get("staffRole"))
            if not media or not role or media["id"] in seen or (media.get("isAdult") and not include_adult):
                continue
            seen.add(media["id"])
            works.append({**self.entry(media, 0), "role": role})
        return name, works

    async def search(self, text: str) -> list[dict]:
        """Series matching a title (for linking one by hand)."""
        response = await throttled_post(self.http, {"query": SEARCH_QUERY % {"fields": MEDIA_FIELDS},
                                                       "variables": {"search": text}})
        response.raise_for_status()
        return [self.entry(m, 0) for m in response.json()["data"]["Page"]["media"]]

    async def recommendations(self, title: str, genres: list[str], anilist_id: int | None = None) -> tuple[list[dict], str]:
        """Series like this one: (entries, how they were picked). AniList's own recommendations when it
        knows the series, else the most popular series of the same genres."""
        if anilist_id:
            found = await self.recommendations_for(anilist_id)
            if found:
                return found, "Recomendaciones de lectores de AniList para esta serie"
        from .compare import normalize, similarity
        key = re.sub(r"[^a-z0-9]+", "-", normalize(title))[:80]
        data = await self.cached_post(f"rec-{key}.json", RECOMMENDATIONS_QUERY % {"fields": MEDIA_FIELDS},
                                      {"search": title})
        media = data.get("Media")
        if media:
            names = [media["title"].get(k) for k in ("english", "romaji", "native")] + media.get("synonyms", [])
            if max((similarity(title, name) for name in names if name), default=0) >= MIN_TITLE_MATCH:
                nodes = media["recommendations"]["nodes"]
                found = [node["mediaRecommendation"] for node in nodes if node.get("mediaRecommendation")]
                found = [m for m in found if not m.get("isAdult")]
                if found:
                    return [self.entry(m, 0) for m in found], "Recomendaciones de AniList para esta serie"

        def plain(genre):  # "Acción" -> "accion"
            return "".join(c for c in unicodedata.normalize("NFD", normalize(genre)) if not unicodedata.combining(c))
        mapped = list(dict.fromkeys(GENRES_ES[g] for g in map(plain, genres or []) if g in GENRES_ES))[:2]
        if not mapped:
            return [], ""
        data = await self.cached_post(f"genre-{'-'.join(mapped)}.json", BY_GENRE_QUERY % {"fields": MEDIA_FIELDS},
                                      {"genres": mapped})
        found = data["Page"]["media"]
        return [self.entry(m, 0) for m in found], "Populares de " + " y ".join(mapped) + " en AniList"

    @staticmethod
    def entry(media: dict, rank: int) -> dict:
        title = media["title"]
        main = title.get("english") or title.get("romaji") or ""
        # Titles to try, in order, when looking the series up in the user's sources
        candidates = [main, title.get("romaji"), *media.get("synonyms", [])]
        search_titles = list(dict.fromkeys(t for t in candidates if t))
        return {
            "id": media["id"],
            "rank": rank,
            "title": main,
            "search_titles": search_titles,
            "score": media.get("averageScore"),
            "popularity": media.get("popularity"),
            "kind": COUNTRY_NAMES.get(media.get("countryOfOrigin"), "Manga"),
            "adult": bool(media.get("isAdult")),
            "bl": any(t["name"] == BL_TAG and t["rank"] >= MIN_TAG_RANK for t in media.get("tags") or []),
            "gl": any(t["name"] == GL_TAG and t["rank"] >= MIN_TAG_RANK for t in media.get("tags") or []),
            "genres": media.get("genres", []),
            "cover_url": (media.get("coverImage") or {}).get("large", ""),
        }
