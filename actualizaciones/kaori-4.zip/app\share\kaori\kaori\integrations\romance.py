"""What the Inicio, Explorar, Buscar and Para ti leave out: BL / GL series (if you choose so) and the
series you hid yourself ("No mostrar esta serie").

BL / GL is recognised by the genres the sites give (BL, Boys Love, Yaoi, Shounen Ai… / Yuri, GL…). Lists
often come without genres, so also:
- the titles seen as BL / GL anywhere (any source, everything the server knows) are remembered;
- AniList's most popular BL / GL titles (with their other names), refreshed weekly;
- the series shown without genres get them asked to their site in the background, taking turns
  between sites so every row gets better at once (the server keeps them, so once per series).
Kept in <cache>/kaori/romance_titles.json and <data>/kaori/hidden.json.
"""
import asyncio
import json
import os
import re
import unicodedata

from gi.repository import Gio, GLib, GObject

BL_GENRES = re.compile(r"(^|\b)(bl|boys?'? ?love|yaoi|shounen[ -]?ai|sh[oō]nen[ -]?ai)(\b|$)", re.IGNORECASE)
GL_GENRES = re.compile(r"(^|\b)(gl|girls?'? ?love|yuri|shoujo[ -]?ai|sh[oō]jo[ -]?ai)(\b|$)", re.IGNORECASE)
MODES = (("all", "BL y GL: todo"), ("no-bl", "Sin BL (yaoi)"), ("none", "Sin BL ni GL"))
# Omegaverse (alfas y omegas) stories are nearly always BL: a hint when a site gives no genres
OMEGAVERSE = re.compile(r"omegaverse|\b(alfa|alpha)s?\b.{0,400}\bomegas?\b|\bomegas?\b.{0,400}\b(alfa|alpha)s?\b",
                        re.IGNORECASE | re.DOTALL)

GET_TITLES_GENRES = """
query { mangas { nodes { title genre } } }
"""
FETCH_GENRES = """
mutation ($id: Int!) { fetchManga(input: {id: $id}) { manga { id genre } } }
"""
ANILIST_ROMANCE = """
query ($page: Int, $tag: String) {
  Page(page: $page, perPage: 50) {
    pageInfo { hasNextPage }
    media(type: MANGA, tag_in: [$tag], minimumTagRank: 60, sort: POPULARITY_DESC) {
      title { romaji english native } synonyms
    }
  }
}
"""
ANILIST_PAGES = {"bl": ("Boys' Love", 8), "gl": ("Yuri", 4)}  # tag and pages of 50
ANILIST_TTL = 7 * 86400
ENRICH_AT_ONCE = 4  # site requests at the same time for missing genres (never two to the same site)


def real_genres(genres) -> list:
    """Some sites send [""] for "no genres"."""
    return [genre for genre in genres or [] if genre and genre.strip()]


def normalize(title: str) -> str:
    """For comparing titles: no accents, case, punctuation or bracketed extras ("Jinx (2022)" = "Jinx")."""
    plain = "".join(c for c in unicodedata.normalize("NFD", title or "") if not unicodedata.combining(c))
    plain = re.sub(r"\([^)]*\)|\[[^\]]*\]", " ", plain)
    return re.sub(r"[^a-z0-9]+", " ", plain.casefold()).strip()


class ContentFilter(GObject.Object):
    """One per app (app.content_filter). `changed` when anything that hides series changes."""
    __gtype_name__ = "KaoriContentFilter"

    @GObject.Signal
    def changed(self):
        pass

    def __init__(self, settings):
        super().__init__()
        self.settings = settings
        self.titles_path = os.path.join(GLib.get_user_cache_dir(), "kaori", "romance_titles.json")
        self.hidden_path = os.path.join(GLib.get_user_data_dir(), "kaori", "hidden.json")
        self.known = {"bl": set(), "gl": set()}
        try:
            with open(self.titles_path, encoding="utf-8") as file:
                data = json.load(file)
                self.known = {kind: set(data.get(kind, [])) for kind in ("bl", "gl")}
        except (OSError, ValueError):
            pass
        try:
            with open(self.hidden_path, encoding="utf-8") as file:
                data = json.load(file)
                self.hidden_ids = set(data.get("ids", []))
                self.hidden_titles = set(data.get("titles", []))
        except (OSError, ValueError):
            self.hidden_ids, self.hidden_titles = set(), set()
        self.learned = False
        self.learning = None
        self.anilist_titles = {"bl": set(), "gl": set()}
        self.anilist_task = None
        self.enrich_queue = {}  # source id -> manga ids waiting, asked one site at a time
        self.enrich_busy = set()  # sources with a request running
        self.enrich_tried = set()
        self.enrich_workers = 0
        self.changed_id = 0
        # Before this was Para ti's own setting: keep what was chosen there
        if self.mode == "all" and settings.get_string("foryou-romance") != "all":
            settings.set_string("romance-filter", settings.get_string("foryou-romance"))
        settings.connect("changed::romance-filter", lambda *_: self.on_mode_changed())

    @property
    def mode(self) -> str:
        return self.settings.get_string("romance-filter")

    def on_mode_changed(self):
        if self.mode != "all":
            self.learn()
        self.emit("changed")

    # --- recognising BL / GL ---

    def kinds(self, title: str, genres, description: str = "") -> set:
        found = set()
        if not real_genres(genres) and description and OMEGAVERSE.search(description):
            found.add("bl")
        for genre in genres or []:
            if BL_GENRES.search(genre or ""):
                found.add("bl")
            if GL_GENRES.search(genre or ""):
                found.add("gl")
        key = normalize(title)
        if found:
            self.remember(key, found)
        elif key:
            found = {kind for kind in ("bl", "gl") if key in self.known[kind] or key in self.anilist_titles[kind]}
        return found

    def remember(self, key: str, kinds: set):
        new = [kind for kind in kinds if key and key not in self.known[kind]]
        for kind in new:
            self.known[kind].add(key)
        if new:
            self.save_titles()

    def learn(self):
        """Once per session: every title the server knows as BL / GL (one query to its database)."""
        if self.learned or (self.learning is not None and not self.learning.done()):
            return
        app = Gio.Application.get_default()
        if getattr(app, "suwayomi", None) is not None:
            self.learning = asyncio.ensure_future(self._learn(app.suwayomi))

    async def _learn(self, suwayomi):
        from gql import gql
        if self.anilist_task is None:
            self.anilist_task = asyncio.ensure_future(self.load_anilist())
        try:
            result = await suwayomi.query(gql(GET_TITLES_GENRES))
        except Exception:
            return  # the server isn't ready yet: tried again the next time a list is filtered
        self.learned = True
        before = sum(len(titles) for titles in self.known.values())
        for node in result["mangas"]["nodes"]:
            if node.get("genre"):
                self.kinds(node["title"], node["genre"])
        if sum(len(titles) for titles in self.known.values()) != before:
            self.emit("changed")

    async def load_anilist(self):
        """AniList's most popular BL / GL titles, every name they go by (cached for a week)."""
        import time
        path = os.path.join(GLib.get_user_cache_dir(), "kaori", "anilist", "romance_titles.json")
        try:
            if time.time() - os.path.getmtime(path) < ANILIST_TTL:
                with open(path, encoding="utf-8") as file:
                    data = json.load(file)
                self.anilist_titles = {kind: set(data.get(kind, [])) for kind in ("bl", "gl")}
                self.emit_changed_soon()
                return
        except (OSError, ValueError):
            pass
        import httpx
        from .anilist import throttled_post
        titles = {"bl": set(), "gl": set()}
        async with httpx.AsyncClient(timeout=20, headers={"Accept": "application/json"}) as http:
            for kind, (tag, pages) in ANILIST_PAGES.items():
                for page in range(1, pages + 1):
                    try:
                        response = await throttled_post(http, {"query": ANILIST_ROMANCE,
                                                               "variables": {"page": page, "tag": tag}})
                        response.raise_for_status()
                        data = response.json()["data"]["Page"]
                    except Exception:
                        self.anilist_task = None  # not cached: tried again later
                        return
                    for media in data["media"]:
                        names = list((media.get("title") or {}).values()) + (media.get("synonyms") or [])
                        titles[kind].update(key for key in map(normalize, names) if len(key) >= 3)
                    if not data["pageInfo"]["hasNextPage"]:
                        break
        self.anilist_titles = titles
        self._write(path, {kind: sorted(names) for kind, names in titles.items()})
        self.emit_changed_soon()

    def want_genres(self, manga):
        """A series listed without genres: ask its site for them in the background."""
        if not manga.id or manga.id in self.enrich_tried:
            return
        self.enrich_tried.add(manga.id)
        self.enrich_queue.setdefault(manga.source_id or "?", []).append(manga.id)
        while self.enrich_workers < ENRICH_AT_ONCE:
            self.enrich_workers += 1
            asyncio.ensure_future(self.enrich_worker())

    def next_to_enrich(self):
        """The next series of a site nobody is asking right now, sites taking turns."""
        for source in list(self.enrich_queue):
            if source not in self.enrich_busy and self.enrich_queue[source]:
                manga_id = self.enrich_queue[source].pop(0)
                # This site goes to the back of the line
                self.enrich_queue[source] = self.enrich_queue.pop(source)
                return source, manga_id
        return None, None

    @property
    def enrich_pending(self) -> int:
        return sum(len(ids) for ids in self.enrich_queue.values())

    async def enrich_worker(self):
        from gql import gql
        suwayomi = Gio.Application.get_default().suwayomi
        try:
            while True:
                source, manga_id = self.next_to_enrich()
                if manga_id is None:
                    return
                self.enrich_busy.add(source)
                try:
                    result = await suwayomi.query(gql(FETCH_GENRES), {"id": manga_id})
                except Exception:
                    continue
                finally:
                    self.enrich_busy.discard(source)
                genres = real_genres(((result.get("fetchManga") or {}).get("manga") or {}).get("genre"))
                model = suwayomi.getModel(manga_id, 'Manga')
                if model is not None and genres:
                    model.genre = genres
                    if self.kinds(model.title, genres):
                        self.emit_changed_soon()
        finally:
            self.enrich_workers -= 1

    def emit_changed_soon(self):
        """Many series learnt in a row: refilter the lists once, a moment later."""
        if not self.changed_id:
            self.changed_id = GLib.timeout_add(1200, self.emit_changed)

    def emit_changed(self):
        self.changed_id = 0
        self.emit("changed")
        return GLib.SOURCE_REMOVE

    # --- what to leave out ---

    def blocked(self, manga) -> bool:
        if manga.id in self.hidden_ids or normalize(manga.title) in self.hidden_titles:
            return True
        mode = self.mode
        if mode == "all":
            return False
        self.learn()
        found = self.kinds(manga.title, manga.genre, manga.description)
        if not found and not real_genres(manga.genre):
            self.want_genres(manga)
        if mode == "none":
            return bool(found)
        return "bl" in found

    def hide(self, manga):
        self.hidden_ids.add(manga.id)
        if key := normalize(manga.title):
            self.hidden_titles.add(key)
        self.save_hidden()
        self.emit("changed")

    def unhide_all(self):
        self.hidden_ids.clear()
        self.hidden_titles.clear()
        self.save_hidden()
        self.emit("changed")

    @property
    def hidden_count(self) -> int:
        return len(self.hidden_titles) or len(self.hidden_ids)

    # --- storage ---

    def save_titles(self):
        self._write(self.titles_path, {kind: sorted(titles) for kind, titles in self.known.items()})

    def save_hidden(self):
        self._write(self.hidden_path, {"ids": sorted(self.hidden_ids), "titles": sorted(self.hidden_titles)})

    @staticmethod
    def _write(path, data):
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as file:
                json.dump(data, file, ensure_ascii=False)
            os.replace(tmp, path)
        except OSError:
            pass
