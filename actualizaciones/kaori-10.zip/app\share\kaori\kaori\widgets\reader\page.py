import asyncio
from dataclasses import dataclass

from gi.repository import Adw, Gdk, Gio, GLib, GObject, Gtk, Pango

from ...integrations import models

from .base import adjacent_chapter, chapter_load_error, show_reader_toast
from .capture import CaptureOverlay
from .dialog import SettingsDialog
from .single import SinglePageReader
from .webtoon import WebtoonReader
from .double import DoublePageReader

LAST_PAGE = 10**6
SETTINGS_SAVE_DELAY = 500
HEADER_HOVER_HEIGHT = 48
HEADER_HIDE_DELAY = 1500
READING_IDLE_TIMEOUT = 60  # seconds without input/page changes before reading time stops counting
SIDE_EDGE = 16  # px from the left edge that open the chapter panel
SIDE_HIDE_MARGIN = 60  # px past the panel the pointer may wander before it closes
SIDE_HIDE_DELAY = 350  # ms

CTRL_KEYS = (Gdk.KEY_Control_L, Gdk.KEY_Control_R)

ORIENTATIONS = {
    "vertical": Gtk.Orientation.VERTICAL,
    "horizontal": Gtk.Orientation.HORIZONTAL,
}
DIRECTIONS = {
    "ltr": Gtk.TextDirection.LTR,
    "rtl": Gtk.TextDirection.RTL,
}


@dataclass(frozen=True)
class Reader:
    name: str
    title: str
    icon_name: str
    widget: type


@Gtk.Template(resource_path='/io/github/riyaniii/Kaori/reader/page.ui')
class ReaderPage(Adw.NavigationPage):
    __gtype_name__ = "KaoriReaderPage"

    manga_model = GObject.Property(type=models.Manga)
    chapter_model = GObject.Property(type=models.Chapter)
    position = GObject.Property(type=int, default=0)
    direction = GObject.Property(type=Gtk.TextDirection, default=Gtk.TextDirection.LTR)

    revealer = Gtk.Template.Child()
    header = Gtk.Template.Child()
    fullscreen_button = Gtk.Template.Child()
    autoread_button = Gtk.Template.Child()
    stack = Gtk.Template.Child()

    page_error = Gtk.Template.Child()
    page_error_label = Gtk.Template.Child()
    page_back_button = Gtk.Template.Child()
    page_forward_button = Gtk.Template.Child()
    side_revealer = Gtk.Template.Child()
    side_panel = Gtk.Template.Child()
    side_chapter_label = Gtk.Template.Child()
    side_previous = Gtk.Template.Child()
    side_next = Gtk.Template.Child()
    side_page_label = Gtk.Template.Child()
    side_page_scale = Gtk.Template.Child()
    side_scrolled = Gtk.Template.Child()
    side_chapters = Gtk.Template.Child()

    READERS = [
        Reader("webtoon", "Webtoon", "view-continuous-symbolic", WebtoonReader),
        Reader("single", "Single Page", "view-paged-symbolic", SinglePageReader),
        Reader("double", "Double Page", "view-dual-symbolic", DoublePageReader),
    ]

    def __init__(self, manga_model, chapter_model):
        super().__init__()
        self.manga_model = manga_model
        self.suwayomi = Gio.Application.get_default().suwayomi
        self.add_css_class("reader-solid")  # pages read best on a plain background, picture or not

        self.store = Gio.ListStore(item_type=models.Page)
        self.load_task = None
        self.saved_pages = {}

        sync = GObject.BindingFlags.SYNC_CREATE
        both_ways = sync | GObject.BindingFlags.BIDIRECTIONAL

        self.readers = {}
        for info in self.READERS:
            reader = info.widget()
            reader.bind_store(self.store)
            reader.connect("chapter-requested", self.on_chapter_requested)

            self.bind_property("manga-model", reader, "manga-model", sync)
            for name in ("chapter-model", "direction", "position"):
                self.bind_property(name, reader, name, both_ways)

            self.stack.add_titled_with_icon(reader, info.name, info.title, info.icon_name)
            self.readers[info.name] = reader

        self.webtoon = self.readers["webtoon"]
        self.active_reader = self.readers[self.stack.get_visible_child_name()]
        self.stack.connect("notify::visible-child-name", self.on_reader_switched)
        self.update_page_buttons()

        # Failed downloads in the single / double readers show a "Reintentar" box over the page
        for reader in self.readers.values():
            if reader is not self.webtoon:
                reader.connect("page-failed", self.on_page_failed)
        self.connect("notify::position", lambda *args: self.page_error.set_visible(False))

        self.connect("notify::position", self.on_position_notify)

        actions = {
            "next_page": lambda action, param: self.active_reader.next_page(),
            "previous_page": lambda action, param: self.active_reader.previous_page(),
            "next_chapter": lambda action, param: self.change_chapter(1),
            "previous_chapter": lambda action, param: self.change_chapter(-1),
        }
        action_group = Gio.SimpleActionGroup()
        for name, callback in actions.items():
            action = Gio.SimpleAction(name=name)
            action.connect("activate", callback)
            action_group.add_action(action)
        self.insert_action_group("reader", action_group)

        # Capture mode (C): cut a panel out and keep it in the Galería
        self.capture_overlay = CaptureOverlay(self.stack)
        self.capture_overlay.connect("captured", self.on_captured)
        self.capture_overlay.connect("cancelled", lambda *_: self.restore_focus())
        self.get_child().add_overlay(self.capture_overlay)

        key_controller = Gtk.EventControllerKey(propagation_phase=Gtk.PropagationPhase.CAPTURE)
        key_controller.connect("key-pressed", self.on_key_pressed)
        key_controller.connect("key-released", self.on_key_released)
        self.add_controller(key_controller)

        focus_controller = Gtk.EventControllerFocus()
        focus_controller.connect("leave", self.on_focus_leave)
        self.add_controller(focus_controller)

        back_click = Gtk.GestureClick(button=8)
        back_click.connect("pressed", lambda gesture, n_press, x, y: self.go_back())
        self.add_controller(back_click)

        self.held_ctrl_keys = set()
        self.pointer_in_zone = True
        self.hide_header_id = 0
        self.root_handlers = []

        motion_controller = Gtk.EventControllerMotion(propagation_phase=Gtk.PropagationPhase.CAPTURE)
        motion_controller.connect("enter", self.on_pointer_motion)
        motion_controller.connect("motion", self.on_pointer_motion)
        self.add_controller(motion_controller)

        self.header_focus = Gtk.EventControllerFocus()
        self.header_focus.connect("notify::contains-focus", self.update_header)
        self.header.add_controller(self.header_focus)

        self.connect("notify::root", self.on_root_changed)

        self.applying_settings = False
        self.settings_loaded = False
        self.save_settings_id = 0
        self.connect("notify::direction", self.on_setting_changed)
        self.webtoon.connect("notify::orientation", self.on_setting_changed)

        self.settings_task = asyncio.create_task(self.load_settings())

        # Reading history: last page per manga and time actually spent reading
        self.history = Gio.Application.get_default().history
        self.last_activity = GLib.get_monotonic_time()
        self.reading_timer = 0
        self.connect("notify::position", self.on_history_update)
        self.connect("notify::chapter-model", self.on_history_update)
        self.connect("realize", self.start_reading_timer)

        self.build_auto_read_bar()

        self.fullscreen_window = None  # the window put in full screen from here, and its handler
        self.fullscreen_handler = 0
        self.was_maximized = True

        # Left-edge chapter panel
        self.side_hide_id = 0
        self.updating_side = False
        if manga_model is not None:
            self.bind_side_chapters(manga_model)
            # Opened before the chapter list arrived (e.g. "Continuar" right at startup): fill it then
            handler = manga_model.connect("notify::chapters", self.bind_side_chapters)
            self.connect("unrealize", lambda page: manga_model.handler_is_connected(handler)
                         and manga_model.disconnect(handler))
        self.connect("notify::chapter-model", self.update_side_panel)
        self.connect("notify::position", self.update_side_panel)

        self.connect("unrealize", self.on_unrealize)
        self.connect("shown", lambda page: self.restore_focus())

        self.start_load(chapter_model, resume_position=self.initial_resume_position(chapter_model))

    def on_focus_leave(self, controller):
        self.held_ctrl_keys.clear()
        self.webtoon.stop_scrolling()

    def on_root_changed(self, *args):
        for obj, handler_id in self.root_handlers:
            obj.disconnect(handler_id)
        self.root_handlers = []

        root = self.get_root()
        if root is None:
            return

        split_view = root.overlay_split_view
        self.root_handlers = [
            (root, root.connect("notify::visible-dialog", self.update_header)),
            (split_view, split_view.connect("notify::show-sidebar", self.update_header)),
        ]
        self.update_header()

    def bind_side_chapters(self, manga_model, *args):
        if manga_model.chapters is not None:
            self.side_chapters.bind_model(manga_model.chapters, self.make_side_row)
            self.update_side_panel()

    def make_side_row(self, chapter):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, margin_top=4, margin_bottom=4)
        box.append(Gtk.Label(label=chapter.name, xalign=0, ellipsize=Pango.EllipsizeMode.END))
        if chapter.is_read:
            box.append(Gtk.Label(label="Leído", xalign=0, css_classes=["dim-label", "caption"]))
        row = Gtk.ListBoxRow(child=box)
        row.chapter = chapter
        return row

    def update_side_panel(self, *args):
        chapter = self.chapter_model
        if chapter is None:
            return
        self.side_chapter_label.set_label(chapter.name)
        self.side_previous.set_sensitive(adjacent_chapter(self.manga_model, chapter, -1) is not None)
        self.side_next.set_sensitive(adjacent_chapter(self.manga_model, chapter, 1) is not None)

        count = chapter.page_count
        page = self.position + 1
        self.side_page_label.set_label(f"Página {page} de {count}" if count > 0 else f"Página {page}")
        self.updating_side = True
        adjustment = self.side_page_scale.get_adjustment()
        adjustment.set_upper(max(count, 2))
        adjustment.set_value(page)
        self.updating_side = False
        self.side_page_scale.set_sensitive(count > 1)

    def show_side_panel(self):
        self.cancel_side_hide()
        if self.side_revealer.get_reveal_child():
            return
        self.update_side_panel()
        self.side_revealer.set_reveal_child(True)
        GLib.idle_add(self.scroll_side_to_current)

    def scroll_side_to_current(self):
        current = self.chapter_model
        row = self.side_chapters.get_first_child()
        while row is not None:
            if getattr(row, "chapter", None) is current:
                self.side_chapters.select_row(row)
                ok, bounds = row.compute_bounds(self.side_chapters)
                if ok:
                    adjustment = self.side_scrolled.get_vadjustment()
                    adjustment.set_value(bounds.get_y() - adjustment.get_page_size() / 2)
                break
            row = row.get_next_sibling()
        return GLib.SOURCE_REMOVE

    def hide_side_panel(self):
        self.side_hide_id = 0
        self.side_revealer.set_reveal_child(False)
        return GLib.SOURCE_REMOVE

    def cancel_side_hide(self):
        if self.side_hide_id:
            GLib.source_remove(self.side_hide_id)
            self.side_hide_id = 0

    def update_side_hover(self, x):
        if x <= SIDE_EDGE:
            self.show_side_panel()
        elif self.side_revealer.get_reveal_child():
            if x > self.side_panel.get_width() + SIDE_HIDE_MARGIN:
                if not self.side_hide_id:
                    self.side_hide_id = GLib.timeout_add(SIDE_HIDE_DELAY, self.hide_side_panel)
            else:
                self.cancel_side_hide()

    @Gtk.Template.Callback()
    def on_side_previous_clicked(self, button):
        self.change_chapter(-1)

    @Gtk.Template.Callback()
    def on_side_next_clicked(self, button):
        self.change_chapter(1)

    @Gtk.Template.Callback()
    def on_side_page_changed(self, scale, scroll, value):
        if not self.updating_side and self.chapter_model is not None:
            count = max(self.chapter_model.page_count, 1)
            self.position = max(0, min(round(value) - 1, count - 1))
        return False

    @Gtk.Template.Callback()
    def on_side_chapter_activated(self, listbox, row):
        chapter = row.chapter
        if chapter is not self.chapter_model:
            self.start_load(chapter, self.initial_resume_position(chapter))

    def on_pointer_motion(self, controller, x, y):
        self.mark_activity()
        self.update_side_hover(x)
        inside = y <= HEADER_HOVER_HEIGHT
        if inside != self.pointer_in_zone:
            self.pointer_in_zone = inside
            self.update_header()

    def update_header(self, *args):
        root = self.get_root()
        if root is None:
            return

        keep_open = (
            self.pointer_in_zone
            or root.get_visible_dialog() is not None
            or root.overlay_split_view.get_show_sidebar()
            or (self.header_focus.props.contains_focus and root.get_focus_visible())
        )

        if keep_open:
            self.cancel_header_hide()
            self.revealer.set_reveal_child(True)
        elif self.revealer.get_reveal_child() and not self.hide_header_id:
            self.hide_header_id = GLib.timeout_add(HEADER_HIDE_DELAY, self.hide_header)

    def hide_header(self):
        self.hide_header_id = 0
        self.revealer.set_reveal_child(False)
        return GLib.SOURCE_REMOVE

    def cancel_header_hide(self):
        if self.hide_header_id:
            GLib.source_remove(self.hide_header_id)
            self.hide_header_id = 0

    @property
    def stored_chapter_id(self):
        first = self.store.get_item(0)
        return first.chapter_id if first else None

    def loading(self) -> bool:
        return self.load_task is not None and not self.load_task.done()

    def initial_resume_position(self, chapter_model) -> int:
        if chapter_model.is_read or chapter_model.last_page_read <= 0:
            return 0
        return chapter_model.last_page_read - 1

    def start_load(self, chapter_model, resume_position=0) -> asyncio.Task:
        if self.loading():
            self.load_task.cancel()
        self.load_task = asyncio.create_task(
            self.load_chapter(chapter_model, resume_position=resume_position)
        )
        return self.load_task

    async def load_chapter(self, chapter_model, resume_position=0):
        self.chapter_model = chapter_model
        try:
            pages = await self.suwayomi.getChapterPages(chapter_model.id)
        except asyncio.CancelledError:
            raise
        except Exception as error:
            print(f"[lector] {chapter_model.name}: {str(error)[:300]}")
            show_reader_toast(self, chapter_load_error(chapter_model, error))
            return
        self.store.splice(0, self.store.get_n_items(), pages)

        if self.chapter_model is None or self.chapter_model.id != chapter_model.id:
            return

        count = chapter_model.page_count
        self.position = max(0, min(resume_position, count - 1)) if count else 0

    def change_chapter(self, direction: int, resume_position: int | None = None):
        if self.loading():
            return
        chapter = adjacent_chapter(self.manga_model, self.chapter_model, direction)
        if chapter is None:
            return
        if resume_position is None:
            resume_position = self.initial_resume_position(chapter)
        self.start_load(chapter, resume_position)

    def on_chapter_requested(self, reader, direction):
        self.change_chapter(direction, LAST_PAGE if direction < 0 else None)

    def on_history_update(self, *args):
        self.mark_activity()
        if self.manga_model is not None and self.chapter_model is not None:
            self.history.record(self.manga_model, self.chapter_model, self.position + 1)

    def mark_activity(self):
        self.last_activity = GLib.get_monotonic_time()

    def start_reading_timer(self, *args):
        if not self.reading_timer:
            self.reading_timer = GLib.timeout_add_seconds(1, self.on_reading_tick)

    def on_reading_tick(self):
        root = self.get_root()
        idle = (GLib.get_monotonic_time() - self.last_activity) / GLib.USEC_PER_SEC
        reading = self.get_mapped() and root is not None and root.is_active() and idle < READING_IDLE_TIMEOUT
        if reading and self.manga_model is not None:
            self.history.add_time(self.manga_model.id, 1)
        return GLib.SOURCE_CONTINUE

    def on_unrealize(self, page):
        # Left the reader any way (sidebar, Galería…): never leave Kaori stuck in full screen
        if self.fullscreen_window is not None:
            if self.fullscreen_window.is_fullscreen():
                self.exit_fullscreen(self.fullscreen_window)
            self.fullscreen_window.disconnect(self.fullscreen_handler)
            self.fullscreen_window, self.fullscreen_handler = None, 0
        if self.reading_timer:
            GLib.source_remove(self.reading_timer)
            self.reading_timer = 0
        self.cancel_header_hide()
        for task in (self.load_task, self.settings_task):
            if task is not None:
                task.cancel()
        if self.save_settings_id:
            GLib.source_remove(self.save_settings_id)
            self.flush_settings()

    def on_page_failed(self, reader, index):
        if reader is self.active_reader:
            self.page_error_label.set_label(f"No se pudo cargar la página {index + 1}")
            self.page_error.set_visible(True)

    @Gtk.Template.Callback()
    def on_page_retry_clicked(self, button):
        self.page_error.set_visible(False)
        self.active_reader.reload_current(forget=False)

    @Gtk.Template.Callback()
    def on_reload_clicked(self, button):
        self.page_error.set_visible(False)
        self.active_reader.reload_current(forget=True)

    def update_page_buttons(self):
        paged = self.active_reader is not self.webtoon
        self.page_back_button.set_visible(paged)
        self.page_forward_button.set_visible(paged)
        self.autoread_button.set_visible(not paged)  # Lectura automática is for the webtoon strip
        if paged:
            self.stop_auto_read_mode()

    # --- Lectura automática ---

    def build_auto_read_bar(self):
        """Floating controls while reading by itself: pause, slower / faster, close."""
        self.auto_mode = False
        bar = Gtk.Box(spacing=6, halign=Gtk.Align.CENTER, valign=Gtk.Align.END, margin_bottom=22,
                      css_classes=["osd", "toolbar", "auto-read-bar"], visible=False)
        self.auto_play = Gtk.Button(icon_name="media-playback-pause-symbolic", tooltip_text="Pausar (Espacio)",
                                    css_classes=["circular"])
        self.auto_play.connect("clicked", lambda b: self.toggle_auto_read_pause())
        slower = Gtk.Button(icon_name="list-remove-symbolic", tooltip_text="Más lento (↑)", css_classes=["circular"])
        slower.connect("clicked", lambda b: self.change_auto_speed(-1))
        self.auto_speed = Gtk.Label(css_classes=["auto-read-speed"], width_chars=12)
        faster = Gtk.Button(icon_name="list-add-symbolic", tooltip_text="Más rápido (↓)", css_classes=["circular"])
        faster.connect("clicked", lambda b: self.change_auto_speed(1))
        close = Gtk.Button(icon_name="window-close-symbolic", tooltip_text="Terminar la lectura automática (Esc)",
                           css_classes=["circular"])
        close.connect("clicked", lambda b: self.stop_auto_read_mode())
        for widget in (self.auto_play, slower, self.auto_speed, faster, close):
            bar.append(widget)
        self.auto_bar = bar
        self.get_child().add_overlay(bar)
        self.webtoon.connect("notify::auto-reading", self.on_auto_reading_changed)
        self.auto_activity_id = 0

    def update_auto_speed_label(self):
        self.auto_speed.set_label(f"Velocidad {self.webtoon.auto_read_level}")

    @Gtk.Template.Callback()
    def on_autoread_clicked(self, *args):
        if self.auto_mode:
            self.stop_auto_read_mode()
        else:
            self.start_auto_read_mode()
        self.restore_focus()

    def start_auto_read_mode(self):
        if self.active_reader is not self.webtoon:
            return
        self.auto_mode = True
        self.update_auto_speed_label()
        self.auto_bar.set_visible(True)
        self.autoread_button.set_icon_name("media-playback-stop-symbolic")
        self.webtoon.start_auto_read()

    def stop_auto_read_mode(self):
        if not getattr(self, "auto_mode", False):
            return
        self.auto_mode = False
        self.webtoon.stop_auto_read()
        self.auto_bar.set_visible(False)
        self.autoread_button.set_icon_name("media-playback-start-symbolic")

    def toggle_auto_read_pause(self):
        if self.webtoon.auto_reading:
            self.webtoon.stop_auto_read()
        else:
            self.webtoon.start_auto_read()
        self.restore_focus()

    def change_auto_speed(self, step):
        self.webtoon.set_auto_read_level(self.webtoon.auto_read_level + step)
        self.update_auto_speed_label()
        self.restore_focus()

    def on_auto_reading_changed(self, webtoon, pspec):
        playing = webtoon.auto_reading
        self.auto_play.set_icon_name("media-playback-pause-symbolic" if playing else "media-playback-start-symbolic")
        self.auto_play.set_tooltip_text("Pausar (Espacio)" if playing else "Continuar (Espacio)")
        # Reading by itself still counts as reading (no keys or clicks in the meantime)
        if playing and not self.auto_activity_id:
            self.auto_activity_id = GLib.timeout_add_seconds(10, self.on_auto_activity)

    def on_auto_activity(self):
        if not self.webtoon.auto_reading:
            self.auto_activity_id = 0
            return GLib.SOURCE_REMOVE
        self.mark_activity()
        return GLib.SOURCE_CONTINUE

    @Gtk.Template.Callback()
    def on_page_back_clicked(self, button):
        # The left button always points left: in right-to-left reading that's the next page
        if self.direction == Gtk.TextDirection.RTL:
            self.active_reader.next_page()
        else:
            self.active_reader.previous_page()

    @Gtk.Template.Callback()
    def on_page_forward_clicked(self, button):
        if self.direction == Gtk.TextDirection.RTL:
            self.active_reader.previous_page()
        else:
            self.active_reader.next_page()

    def on_reader_switched(self, stack, pspec):
        self.active_reader = self.readers[stack.get_visible_child_name()]
        self.page_error.set_visible(False)
        self.update_page_buttons()
        self.sync_store()
        self.on_setting_changed()
        GLib.idle_add(self.restore_focus)

    def restore_focus(self):
        root = self.get_root()
        if root is not None and root.get_focus() is None:
            self.active_reader.child_focus(Gtk.DirectionType.TAB_FORWARD)
        return GLib.SOURCE_REMOVE

    def sync_store(self):
        chapter = self.chapter_model
        if chapter is None or chapter.id == self.stored_chapter_id:
            return
        if self.active_reader is self.webtoon or self.loading():
            return
        self.start_load(chapter, resume_position=self.position)

    @Gtk.Template.Callback()
    def on_capture_clicked(self, *args):
        self.start_capture()

    def start_capture(self):
        self.hide_side_panel()
        self.capture_overlay.start()

    def on_captured(self, overlay, texture):
        app = Gio.Application.get_default()
        window = self.get_root()
        try:
            app.captures.add(texture, self.manga_model, self.chapter_model, self.position + 1)
            toast = Adw.Toast(title="Viñeta guardada en la Galería", timeout=3)
            toast.set_button_label("Ver")
            toast.set_action_name("app.open_gallery")
        except Exception as error:
            toast = Adw.Toast(title=f"No se pudo guardar la captura: {error}", timeout=4)
        if window is not None:
            window.toast_overlay.dismiss_all()
            window.toast_overlay.add_toast(toast)
        self.restore_focus()

    def on_key_pressed(self, controller, keyval, keycode, state):
        self.mark_activity()

        if self.capture_overlay.active:
            if keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter):
                self.capture_overlay.capture_all()
            elif keyval in (Gdk.KEY_Escape, Gdk.KEY_c, Gdk.KEY_C):
                self.capture_overlay.stop(cancelled=True)
            return True
        if keyval in (Gdk.KEY_c, Gdk.KEY_C) and not state & (Gdk.ModifierType.CONTROL_MASK | Gdk.ModifierType.ALT_MASK):
            self.start_capture()
            return True
        rtl = self.direction == Gtk.TextDirection.RTL

        if keyval in CTRL_KEYS:
            self.held_ctrl_keys.add(keyval)
            return False

        ctrl = bool(state & Gdk.ModifierType.CONTROL_MASK) or bool(self.held_ctrl_keys)

        if keyval == Gdk.KEY_F11:
            self.toggle_fullscreen()
            return True
        if keyval in (Gdk.KEY_a, Gdk.KEY_A) and not ctrl and self.active_reader is self.webtoon:
            if self.auto_mode:
                self.toggle_auto_read_pause()
            else:
                self.start_auto_read_mode()
            return True
        if self.auto_mode:
            if keyval == Gdk.KEY_space:
                self.toggle_auto_read_pause()
                return True
            if keyval in (Gdk.KEY_Up, Gdk.KEY_Down):
                self.change_auto_speed(1 if keyval == Gdk.KEY_Down else -1)
                return True
            if keyval == Gdk.KEY_Escape:
                self.stop_auto_read_mode()
                return True
        if keyval == Gdk.KEY_Escape:
            # Out of full screen first; a second Esc leaves the reader as always
            if not self.leave_fullscreen():
                self.go_back()
            return True

        if ctrl and keyval in (Gdk.KEY_plus, Gdk.KEY_equal, Gdk.KEY_KP_Add):
            self.active_reader.zoom_in()
            return True
        if ctrl and keyval in (Gdk.KEY_minus, Gdk.KEY_KP_Subtract):
            self.active_reader.zoom_out()
            return True
        if ctrl and keyval in (Gdk.KEY_0, Gdk.KEY_KP_0):
            self.active_reader.reset_zoom()
            return True

        if ctrl and keyval in (Gdk.KEY_Right, Gdk.KEY_Left):
            forward = (keyval == Gdk.KEY_Right) != rtl
            self.change_chapter(1 if forward else -1)
            return True
        if keyval == Gdk.KEY_period:
            self.change_chapter(1)
            return True
        if keyval == Gdk.KEY_comma:
            self.change_chapter(-1)
            return True

        if keyval == Gdk.KEY_Home:
            self.active_reader.position = 0
            return True
        if keyval == Gdk.KEY_End:
            self.active_reader.position = LAST_PAGE
            return True

        if self.active_reader is self.webtoon:
            return self.on_webtoon_key_pressed(keyval)

        if keyval in (Gdk.KEY_Down, Gdk.KEY_space, Gdk.KEY_Page_Down):
            self.active_reader.next_page()
            return True
        if keyval in (Gdk.KEY_Up, Gdk.KEY_Page_Up, Gdk.KEY_BackSpace):
            self.active_reader.previous_page()
            return True

        if keyval in (Gdk.KEY_Right, Gdk.KEY_Left):
            forward = (keyval == Gdk.KEY_Right) != rtl
            if forward:
                self.active_reader.next_page()
            else:
                self.active_reader.previous_page()
            return True

        return False

    def on_key_released(self, controller, keyval, keycode, state):
        if keyval in CTRL_KEYS:
            self.held_ctrl_keys.discard(keyval)
            return
        if self.scroll_direction(keyval) == self.webtoon.scroll_direction:
            self.webtoon.stop_scrolling()

    def scroll_direction(self, keyval):
        horizontal = self.webtoon.orientation == Gtk.Orientation.HORIZONTAL
        keys = (Gdk.KEY_Left, Gdk.KEY_Right) if horizontal else (Gdk.KEY_Up, Gdk.KEY_Down)
        if keyval not in keys:
            return 0
        forward = keyval in (Gdk.KEY_Down, Gdk.KEY_Right)
        if horizontal and self.direction == Gtk.TextDirection.RTL:
            forward = not forward
        return 1 if forward else -1

    def on_webtoon_key_pressed(self, keyval):
        if keyval == Gdk.KEY_Page_Down:
            self.webtoon.scroll_page(1)
        elif keyval == Gdk.KEY_Page_Up:
            self.webtoon.scroll_page(-1)
        elif keyval in (Gdk.KEY_f, Gdk.KEY_F):
            self.webtoon.toggle_fit_width()
        elif direction := self.scroll_direction(keyval):
            self.webtoon.start_scrolling(direction)
        return True

    def on_position_notify(self, page, pspec):
        chapter = self.chapter_model
        if chapter is None or self.loading():
            return
        saved = max(self.saved_pages.get(chapter.id, 0), chapter.last_page_read)
        if self.position + 1 > saved:
            self.save_progress()

    def save_progress(self):
        chapter = self.chapter_model
        total = chapter.page_count
        if total <= 0:
            return
        page = self.position + 1
        seen = self.position + self.active_reader.step
        self.saved_pages[chapter.id] = page
        asyncio.create_task(
            self.suwayomi.updateChapter(
                chapter_id=chapter.id,
                is_read=chapter.is_read or seen >= total,
                last_page_read=page,
            )
        )

    @Gtk.Template.Callback()
    def on_settings_clicked(self, *args):
        SettingsDialog(self.stack).present(self)

    async def load_settings(self):
        try:
            settings = await self.suwayomi.getReaderSettings(self.manga_model.id)
        except Exception:
            settings = {}
        self.apply_settings(settings or {})
        self.settings_loaded = True

    def apply_settings(self, settings):
        self.applying_settings = True
        try:
            if settings.get("mode") in self.readers:
                self.stack.set_visible_child_name(settings["mode"])
            if settings.get("orientation") in ORIENTATIONS:
                self.webtoon.orientation = ORIENTATIONS[settings["orientation"]]
            if settings.get("direction") in DIRECTIONS:
                self.direction = DIRECTIONS[settings["direction"]]
        finally:
            self.applying_settings = False

    def current_settings(self):
        return {
            "mode": self.stack.get_visible_child_name(),
            "orientation": self.webtoon.orientation.value_nick,
            "direction": self.direction.value_nick,
        }

    def on_setting_changed(self, *args):
        if self.applying_settings or not self.settings_loaded:
            return
        if self.save_settings_id:
            GLib.source_remove(self.save_settings_id)
        self.save_settings_id = GLib.timeout_add(SETTINGS_SAVE_DELAY, self.flush_settings)

    def flush_settings(self):
        self.save_settings_id = 0
        asyncio.create_task(self.suwayomi.setReaderSettings(self.manga_model.id, self.current_settings()))
        return GLib.SOURCE_REMOVE

    @Gtk.Template.Callback()
    def on_fullscreen_clicked(self, *args):
        self.toggle_fullscreen()
        self.restore_focus()

    def toggle_fullscreen(self):
        """Kaori over the whole screen, taskbar included (only while reading)."""
        window = self.get_root()
        if window is None:
            return
        if window.is_fullscreen():
            self.exit_fullscreen(window)
        else:
            if not self.fullscreen_handler:
                self.fullscreen_window = window
                self.fullscreen_handler = window.connect("notify::fullscreened", self.on_fullscreened)
            self.was_maximized = window.is_maximized()
            window.fullscreen()

    def exit_fullscreen(self, window):
        window.unfullscreen()
        # On Windows GTK comes back from full screen as a small window, not maximized as it was
        if self.was_maximized:
            window.maximize()

    def leave_fullscreen(self) -> bool:
        """Back to the normal window; True if it was in full screen."""
        window = self.get_root()
        if window is not None and window.is_fullscreen():
            self.exit_fullscreen(window)
            return True
        return False

    def on_fullscreened(self, window, pspec):
        full = window.is_fullscreen()
        self.fullscreen_button.set_icon_name("view-restore-symbolic" if full else "view-fullscreen-symbolic")
        self.fullscreen_button.set_tooltip_text("Salir de pantalla completa (F11 o Esc)" if full else
                                                "Pantalla completa, sin la barra de tareas (F11)")

    @Gtk.Template.Callback()
    def on_back_clicked(self, *args):
        self.go_back()

    def go_back(self):
        self.leave_fullscreen()
        self.get_root().main_nav_view.pop()

    @Gtk.Template.Callback()
    def on_title_clicked(self, *args):
        """Leave the reader for the series page; reuse it if the reader was opened from there."""
        from ..manga import MangaPage  # imported here: the manga page itself imports the reader
        window = self.get_root()
        section = window.main_stack.get_visible_child()
        self.go_back()
        under = section.get_visible_page()
        if not (isinstance(under, MangaPage) and under.model is self.manga_model):
            window.activate_action("app.show_manga", GLib.Variant("i", self.manga_model.id))
