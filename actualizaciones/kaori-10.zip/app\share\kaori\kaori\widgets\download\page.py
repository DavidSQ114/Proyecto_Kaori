import asyncio
from gi.repository import Gtk, Adw, Gio, GLib, Pango

from .row import DownloadRow

@Gtk.Template(resource_path='/io/github/riyaniii/Kaori/download/page.ui')
class DownloadsPage(Adw.NavigationPage):
    __gtype_name__ = "KaoriDownloadsPage"

    download_stack = Gtk.Template.Child()
    download_list = Gtk.Template.Child()
    search_entry = Gtk.Template.Child()
    toggle_button = Gtk.Template.Child()
    clear_button = Gtk.Template.Child()
    view_stack = Gtk.Template.Child()
    downloaded_stack = Gtk.Template.Child()
    downloaded_box = Gtk.Template.Child()

    def __init__(self):
        super().__init__()
        self.suwayomi = Gio.Application.get_default().suwayomi
        self.poll_id = 0
        self.refreshing = False

        self.filter = Gtk.CustomFilter.new(self.filter_download)
        self.filtered = Gtk.FilterListModel.new(self.suwayomi.download_queue, self.filter)

        self.manga_rank = {}
        self.update_manga_rank()
        self.section_sorter = Gtk.CustomSorter.new(self.compare_manga)
        self.sectioned = Gtk.SortListModel(model=self.filtered, section_sorter=self.section_sorter)
        self.download_list.set_model(Gtk.NoSelection.new(self.sectioned))

        header_factory = Gtk.SignalListItemFactory()
        header_factory.connect("setup", self.on_header_setup)
        header_factory.connect("bind", self.on_header_bind)
        self.download_list.set_header_factory(header_factory)

        factory = Gtk.SignalListItemFactory()
        factory.connect("setup", self.on_factory_setup)
        factory.connect("bind", self.on_factory_bind)
        factory.connect("unbind", self.on_factory_unbind)
        self.download_list.set_factory(factory)

        self.search_entry.connect("search-changed", self.on_search_changed)
        self.suwayomi.download_queue.connect("items-changed", self.on_queue_changed)
        self.suwayomi.connect("notify::downloader-state", self.on_downloader_state_changed)

        self.update_stack()
        self.update_toggle_button()
        self.downloaded_task = None
        self.view_stack.connect("notify::visible-child-name", self.on_tab_changed)
        self.on_tab_changed()

        asyncio.create_task(self.refresh())
        GLib.timeout_add_seconds(1, self.on_poll)

    def on_poll(self):
        asyncio.create_task(self.refresh())
        return GLib.SOURCE_CONTINUE

    async def refresh(self):
        if self.refreshing:
            return
        self.refreshing = True
        try:
            await self.suwayomi.getDownloadStatus()
        finally:
            self.refreshing = False

    def on_factory_setup(self, factory, list_item):
        list_item.set_selectable(False)
        list_item.set_activatable(False)
        row = DownloadRow()
        row.connect("reorder-requested", self.on_reorder_requested)
        row.connect("remove-requested", self.on_remove_requested)
        row.connect("retry-requested", self.on_retry_requested)
        list_item.set_child(row)

    def on_factory_bind(self, factory, list_item):
        list_item.get_child().model = list_item.get_item()

    def on_factory_unbind(self, factory, list_item):
        list_item.get_child().model = None

    def filter_download(self, download):
        text = self.search_entry.get_text().strip().lower()
        if not text:
            return True
        return text in download.manga_title.lower() or text in download.chapter_name.lower()

    def on_search_changed(self, entry):
        self.filter.changed(Gtk.FilterChange.DIFFERENT)

    def on_queue_changed(self, store, position, removed, added):
        self.update_stack()
        if removed and self.view_stack.get_visible_child_name() == "downloaded":
            self.refresh_downloaded()  # a chapter finished downloading
        self.update_manga_rank()
        self.section_sorter.changed(Gtk.SorterChange.DIFFERENT)

    def update_manga_rank(self):
        self.manga_rank = {}
        for download in self.suwayomi.download_queue:
            self.manga_rank.setdefault(download.manga_id, len(self.manga_rank))

    def compare_manga(self, a, b, *_):
        rank_a = self.manga_rank.get(a.manga_id, len(self.manga_rank))
        rank_b = self.manga_rank.get(b.manga_id, len(self.manga_rank))
        return (rank_a > rank_b) - (rank_a < rank_b)

    def on_header_setup(self, factory, header):
        label = Gtk.Label(xalign=0.0, ellipsize=Pango.EllipsizeMode.END)
        label.add_css_class("heading")
        label.set_margin_start(12)
        label.set_margin_end(12)
        label.set_margin_top(12)
        label.set_margin_bottom(6)
        header.set_child(label)
        header.connect("notify::item", lambda h, _: self.update_header(h))

    def on_header_bind(self, factory, header):
        self.update_header(header)

    def update_header(self, header):
        item = header.get_item()
        header.get_child().set_label(item.manga_title if item else "")

    def update_stack(self):
        if self.suwayomi.download_queue.get_n_items() == 0:
            self.download_stack.set_visible_child_name("greeter")
        else:
            self.download_stack.set_visible_child_name("downloads")

    # --- Descargados: what is on disk ---

    def on_tab_changed(self, *_):
        queue = self.view_stack.get_visible_child_name() != "downloaded"
        self.toggle_button.set_visible(queue)
        self.clear_button.set_visible(queue)
        if not queue:
            self.refresh_downloaded()

    def refresh_downloaded(self):
        if self.downloaded_task and not self.downloaded_task.done():
            return
        self.downloaded_task = asyncio.create_task(self.load_downloaded())

    async def load_downloaded(self):
        if self.downloaded_box.get_first_child() is None:
            self.downloaded_stack.set_visible_child_name("loading")
        try:
            series = await self.suwayomi.getDownloadedChapters()
        except Exception as error:
            print(f"[descargas] no se pudo leer lo descargado: {error!r}")
            series = []
        while child := self.downloaded_box.get_first_child():
            self.downloaded_box.remove(child)
        for manga, chapters in series:
            self.downloaded_box.append(self.build_series(manga, chapters))
        self.downloaded_stack.set_visible_child_name("list" if series else "empty")

    def build_series(self, manga, chapters):
        group = Adw.PreferencesGroup(title=GLib.markup_escape_text(manga['title']),
                                     description=f"{manga['source']} · {len(chapters)} "
                                                 f"{'capítulo descargado' if len(chapters) == 1 else 'capítulos descargados'}")
        series_button = Gtk.Button(label="Ver serie", valign=Gtk.Align.CENTER, css_classes=["flat"])
        series_button.connect("clicked", lambda button: button.activate_action(
            "app.show_manga", GLib.Variant("i", manga['id'])))
        group.set_header_suffix(series_button)
        for chapter in chapters:
            row = Adw.ActionRow(title=GLib.markup_escape_text(chapter.name), activatable=True)
            if chapter.is_read:
                row.set_subtitle("Leído")
            elif chapter.last_page_read > 0:
                row.set_subtitle(f"Ibas por la página {chapter.last_page_read}")
            row.add_prefix(Gtk.Image(icon_name="drive-harddisk-symbolic"))
            delete = Gtk.Button(icon_name="user-trash-symbolic", valign=Gtk.Align.CENTER,
                                tooltip_text="Borrar la descarga", css_classes=["flat"])
            delete.connect("clicked", lambda button, c=chapter: self.ask_delete(manga, c))
            row.add_suffix(delete)
            row.add_suffix(Gtk.Image(icon_name="go-next-symbolic"))
            row.connect("activated", lambda row, c=chapter: asyncio.create_task(self.open_chapter(manga['id'], c)))
            group.add(row)
        return group

    async def open_chapter(self, manga_id, chapter):
        """Straight to the reader, from the server's database: works without internet."""
        from ..reader import ReaderPage
        window = self.get_root()
        manga = self.suwayomi.getModel(manga_id, 'Manga')
        if manga is None or not manga.chapters.get_n_items():
            try:
                manga = await self.suwayomi.getStoredManga(manga_id) or manga
            except Exception as error:
                print(f"[descargas] {chapter.name}: {error!r}")
        if manga is None:
            window.toast_overlay.add_toast(Adw.Toast(title="No se pudo abrir la serie", timeout=3))
            return
        window.chapter_panel.set_manga_model(manga)
        reader = ReaderPage(manga, chapter)
        resume = 0 if chapter.is_read else max(0, chapter.last_page_read - 1)
        reader.start_load(chapter, resume_position=resume)
        window.main_nav_view.push(reader)

    def ask_delete(self, manga, chapter):
        dialog = Adw.AlertDialog(heading="¿Borrar la descarga?",
                                 body=f"«{chapter.name}» de {manga['title']} se borrará del disco. "
                                      "Podrás volver a leerlo con internet o descargarlo otra vez.")
        dialog.add_response("cancel", "Cancelar")
        dialog.add_response("delete", "Borrar")
        dialog.set_response_appearance("delete", Adw.ResponseAppearance.DESTRUCTIVE)
        dialog.set_default_response("cancel")
        dialog.set_close_response("cancel")
        dialog.connect("response", lambda d, response: response == "delete" and asyncio.create_task(
            self.delete_chapter(chapter)))
        dialog.present(self)

    async def delete_chapter(self, chapter):
        try:
            await self.suwayomi.deleteDownloadedChapter(chapter.id)
        except Exception as error:
            self.get_root().toast_overlay.add_toast(Adw.Toast(title=f"No se pudo borrar: {error}", timeout=4))
        self.refresh_downloaded()

    def on_downloader_state_changed(self, *_):
        self.update_toggle_button()

    def update_toggle_button(self):
        if self.suwayomi.downloader_state == "STARTED":
            self.toggle_button.set_icon_name("media-playback-pause-symbolic")
            self.toggle_button.set_tooltip_text("Pausar descargas")
        else:
            self.toggle_button.set_icon_name("media-playback-start-symbolic")
            self.toggle_button.set_tooltip_text("Empezar descargas")

    def on_reorder_requested(self, row, dragged_chapter_id, target_chapter_id):
        for index, download in enumerate(self.suwayomi.download_queue):
            if download.chapter_id == target_chapter_id:
                asyncio.create_task(
                    self.suwayomi.reorderChapterDownload(dragged_chapter_id, index)
                )
                return

    def on_remove_requested(self, row, chapter_id):
        asyncio.create_task(self.suwayomi.dequeueChapterDownload(chapter_id))

    def on_retry_requested(self, row, chapter_id):
        asyncio.create_task(self.retry(chapter_id))

    async def retry(self, chapter_id):
        await self.suwayomi.dequeueChapterDownload(chapter_id)
        await self.suwayomi.enqueueChapterDownload(chapter_id)

    @Gtk.Template.Callback()
    def on_toggle_clicked(self, *_):
        if self.suwayomi.downloader_state == "STARTED":
            asyncio.create_task(self.suwayomi.stopDownloader())
        else:
            asyncio.create_task(self.suwayomi.startDownloader())

    @Gtk.Template.Callback()
    def on_clear_clicked(self, *_):
        dialog = Adw.AlertDialog(
            heading="¿Vaciar la cola de descargas?",
            body="Se quitarán todos los capítulos en espera. Los que ya se descargaron se quedan.",
        )
        dialog.add_response("cancel", "Cancelar")
        dialog.add_response("clear", "Vaciar")
        dialog.set_response_appearance("clear", Adw.ResponseAppearance.DESTRUCTIVE)
        dialog.set_default_response("cancel")
        dialog.set_close_response("cancel")
        dialog.connect("response", self.on_clear_response)
        dialog.present(self)

    def on_clear_response(self, dialog, response):
        if response == "clear":
            asyncio.create_task(self.suwayomi.clearDownloader())
