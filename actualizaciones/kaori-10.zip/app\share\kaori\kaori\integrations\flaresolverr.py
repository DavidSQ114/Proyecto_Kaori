"""FlareSolverr: a hidden Chrome that opens pages protected by Cloudflare (LectorXD) for the server.

Optional: Kaori uses it only when Kaori's folder has flaresolverr\\flaresolverr.exe. Suwayomi asks it for
each blocked page; with "as response fallback" it uses the page Chrome got, because Cloudflare keeps
refusing Java's own requests even with the cookies Chrome earned."""
import asyncio
import os
import shutil
import subprocess
import sys
import urllib.request

PORT = 8191
READY_WAIT = 90  # s to wait for it to answer after starting
URL = f"http://127.0.0.1:{PORT}"
SETTINGS = {
    "flareSolverrEnabled": True,
    "flareSolverrUrl": URL,
    "flareSolverrAsResponseFallback": True,
    # s per page: a check it can't solve (Turnstile) must fail before the extension's own 30 s request
    # limit, else Kaori only sees "timeout" and keeps retrying as if the site were just slow
    "flareSolverrTimeout": 25,
}


class FlareSolverr:
    def __init__(self, root: str, log_dir: str):
        self.exe = os.path.join(root, "flaresolverr", "flaresolverr.exe")
        self.log_path = os.path.join(log_dir, "flaresolverr.log")
        # Its Chrome makes a new 500-800 MB profile in the temp folder on every start and never deletes it
        # when stopped (3 GB of C: in one evening): keep them in Kaori's data and clear them before starting
        self.work_dir = os.path.join(log_dir, "flaresolverr")
        self.process = None
        self.log = None

    def clear_old_profiles(self):
        tmp = os.path.join(self.work_dir, "tmp")
        if os.path.isdir(tmp):
            for name in os.listdir(tmp):
                shutil.rmtree(os.path.join(tmp, name), ignore_errors=True)
        os.makedirs(tmp, exist_ok=True)
        return tmp

    @property
    def installed(self) -> bool:
        return os.path.isfile(self.exe)

    @staticmethod
    def running() -> bool:
        try:
            with urllib.request.urlopen(URL, timeout=1) as response:
                return b"FlareSolverr" in response.read()
        except OSError:
            return False

    def start(self) -> bool:
        """Start it in the background (it takes a few seconds to be ready). False if not installed."""
        if not self.installed:
            return False
        if self.process and self.process.poll() is None:
            return True
        if self.running():  # one left over from a Kaori that didn't close cleanly
            return True
        # LANG: its Chrome in English. In Spanish Cloudflare's check page says "Un momento…", FlareSolverr
        # (which looks for "Just a moment...") takes it for the real page and the server gets an empty series
        env = {**os.environ, "HOST": "127.0.0.1", "PORT": str(PORT), "LOG_LEVEL": "info", "LANG": "en_US"}
        tmp = self.clear_old_profiles()
        # Chrome's profiles (TEMP) and the patched chromedriver (APPDATA) out of C:
        env.update(TEMP=tmp, TMP=tmp, TMPDIR=tmp, APPDATA=self.work_dir)
        self.log = open(self.log_path, "ab")
        flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        try:
            self.process = subprocess.Popen(
                [self.exe], stdout=self.log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                cwd=os.path.dirname(self.exe), env=env, creationflags=flags)
        except OSError as error:
            print(f"[flaresolverr] no se pudo iniciar: {error}")
            return False
        print("[flaresolverr] iniciado")
        return True

    def stop(self):
        if self.process:
            if sys.platform == "win32":
                # The whole tree: its Chrome would otherwise stay open
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(self.process.pid)],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               creationflags=subprocess.CREATE_NO_WINDOW)
            else:
                self.process.terminate()
            self.process.wait()
            self.process = None
            self.clear_old_profiles()
        if self.log:
            self.log.close()
            self.log = None

    async def configure(self, suwayomi):
        """Tell the server to use it (or to stop using it if it was removed)."""
        try:
            # Off until it answers: its Chrome takes ~20 s to start, and meanwhile every protected page
            # would fail with "Failed to connect to 127.0.0.1:8191" instead of the server's usual path
            await suwayomi.setServerSettings(flareSolverrEnabled=False)
            if not self.installed:
                return
            for _ in range(READY_WAIT):
                if await asyncio.to_thread(self.running):
                    await suwayomi.setServerSettings(**SETTINGS)
                    print("[flaresolverr] listo")
                    return
                if self.process is not None and self.process.poll() is not None:
                    break  # it closed: leave it off
                await asyncio.sleep(1)
            print("[flaresolverr] no respondió: queda desactivado")
        except Exception as error:
            print(f"[flaresolverr] no se pudo configurar el servidor: {error!r}")
