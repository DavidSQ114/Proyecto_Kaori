import asyncio
import html
import re

from gi.repository import Adw, Gio, Gtk, Pango

STATUS = {
    "FINISHED": "Finalizado",
    "RELEASING": "En publicación",
    "NOT_YET_RELEASED": "Próximamente",
    "CANCELLED": "Cancelado",
    "HIATUS": "En pausa",
}
COVER_WIDTH = 230
COVER_HEIGHT = 340


def clean_description(text: str | None) -> str:
    """AniList descriptions carry light HTML (<br>, <i>, links); turn them into plain text."""
    if not text:
        return "Sin sinopsis disponible."
    text = re.sub(r"<br\s*/?>", "\n", text)
    text = re.sub(r"<[^>]+>", "", text)
    text = re.sub(r"\n{3,}", "\n\n", html.unescape(text))
    return text.strip()


def search_in_sources(window, titles: list[str], title: str, compare: bool = False):
    """Switch to the global Search page and look the series up in every installed source."""
    window.main_stack.set_visible_child_name("search")
    search_nav = window.main_stack.get_child_by_name("search")
    search_nav.pop_to_page(search_nav.get_navigation_stack().get_item(0))  # leave any manga page open there
    window.search_page.search_titles(titles, compare=compare)
    window.toast_overlay.add_toast(Adw.Toast(title=f"Buscando «{title}» en tus fuentes…", timeout=2))


def label(text, *classes, **props):
    return Gtk.Label(label=text, xalign=0, wrap=True, wrap_mode=Pango.WrapMode.WORD_CHAR,
                     css_classes=list(classes), **props)


class RankingDetailPage(Adw.NavigationPage):
    __gtype_name__ = "KaoriRankingDetailPage"

    def __init__(self, entry: dict, anilist):
        super().__init__(title=entry['title'])
        self.entry = entry
        self.anilist = anilist
        self.suwayomi = Gio.Application.get_default().suwayomi
        self.site_url = None

        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE)
        self.stack.add_named(Adw.Spinner(halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER,
                                         width_request=48, height_request=48), "loading")
        self.error_page = Adw.StatusPage(icon_name="network-error-symbolic", title="No se pudo cargar la información")
        self.stack.add_named(self.error_page, "error")

        self.content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18,
                               margin_top=18, margin_bottom=30, margin_start=18, margin_end=18)
        scrolled = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER,
                                      child=Adw.Clamp(maximum_size=1000, child=self.content))
        self.stack.add_named(scrolled, "content")

        view = Adw.ToolbarView(content=self.stack)
        view.add_top_bar(Adw.HeaderBar())
        self.set_child(view)

        self.build_header()
        asyncio.create_task(self.load())

    def build_header(self):
        """Cover, title, score and the search button: available before the details arrive."""
        entry = self.entry
        top = Gtk.Box(spacing=24)

        self.cover = Gtk.Picture(content_fit=Gtk.ContentFit.COVER, can_shrink=True,
                                 width_request=COVER_WIDTH, height_request=COVER_HEIGHT,
                                 valign=Gtk.Align.START, css_classes=["poster"])
        top.append(self.cover)
        asyncio.create_task(self.load_cover(entry.get('cover_url')))

        info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, hexpand=True, valign=Gtk.Align.START)
        info.append(label(entry['title'], "title-1"))
        self.subtitle = label("", "dim-label")
        info.append(self.subtitle)

        score = f"★ {entry['score']}" if entry.get('score') else "★ sin nota"
        rank = f"#{entry['rank']} en el ranking  ·  " if entry.get('rank') else ""
        info.append(label(f"{rank}{score}  ·  {entry['kind']}", "title-4"))
        self.facts = label("", "dim-label")
        info.append(self.facts)
        if entry.get('genres'):
            info.append(label(", ".join(entry['genres'])))

        buttons = Gtk.Box(spacing=12, margin_top=12)
        search = Gtk.Button(label="Buscar en mis fuentes", css_classes=["pill", "suggested-action"])
        search.connect("clicked", self.on_search_clicked)
        buttons.append(search)
        self.web_button = Gtk.Button(label="Ver en AniList", css_classes=["pill"], sensitive=False)
        self.web_button.connect("clicked", self.on_web_clicked)
        buttons.append(self.web_button)
        info.append(buttons)

        top.append(info)
        self.content.append(top)

    async def load_cover(self, url):
        if url:
            try:
                self.cover.set_paintable(await self.suwayomi.getPaintable(url))
            except Exception:
                pass

    async def load(self):
        try:
            media = await self.anilist.details(self.entry['id'])
        except Exception as error:
            self.error_page.set_description(str(error))
            self.stack.set_visible_child_name("error")
            return

        title = media.get('title') or {}
        alt = [t for t in (title.get('romaji'), title.get('native')) if t and t != self.entry['title']]
        self.subtitle.set_label(" · ".join(alt))

        start, end = (media.get('startDate') or {}).get('year'), (media.get('endDate') or {}).get('year')
        years = f"{start}–{end or ''}" if start else ""
        facts = [STATUS.get(media.get('status'), ""), years]
        if media.get('chapters'):
            facts.append(f"{media['chapters']} capítulos")
        if media.get('volumes'):
            facts.append(f"{media['volumes']} tomos")
        if media.get('favourites'):
            facts.append(f"♥ {media['favourites']:,} favoritos".replace(",", "."))
        self.facts.set_label("  ·  ".join(f for f in facts if f))

        if better := (media.get('coverImage') or {}).get('extraLarge'):
            asyncio.create_task(self.load_cover(better))
        self.site_url = media.get('siteUrl')
        self.web_button.set_sensitive(bool(self.site_url))

        self.content.append(label("De qué trata", "title-3"))
        self.content.append(label(clean_description(media.get('description')), selectable=True))
        self.content.append(label("La sinopsis y las reseñas vienen de AniList (en inglés).", "dim-label", "caption"))

        reviews = (media.get('reviews') or {}).get('nodes') or []
        self.content.append(label("Reseñas de la comunidad", "title-3", margin_top=6))
        if not reviews:
            self.content.append(label("Todavía no hay reseñas.", "dim-label"))
        group = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE, css_classes=["boxed-list"])
        for review in reviews:
            group.append(self.review_row(review))
        if reviews:
            self.content.append(group)

        self.stack.set_visible_child_name("content")

    def review_row(self, review):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4,
                      margin_top=10, margin_bottom=10, margin_start=12, margin_end=12)
        box.append(label(f"“{review.get('summary', '')}”", "heading"))
        user = (review.get('user') or {}).get('name', '?')
        votes = f"{review.get('rating', 0)} de {review.get('ratingAmount', 0)} lo encontraron útil"
        box.append(label(f"★ {review.get('score', '?')}/100  ·  por {user}  ·  {votes}", "dim-label", "caption"))
        return Gtk.ListBoxRow(child=box, activatable=False)

    def on_search_clicked(self, button):
        asyncio.create_task(self.search_everywhere(button))

    async def search_everywhere(self, button):
        """Search with every name the series goes by, Spanish ones included (each source keeps
        trying until one works there)."""
        button.set_sensitive(False)
        button.set_label("Preparando nombres…")
        try:
            titles = await Gio.Application.get_default().names.for_entry(self.entry)
        except Exception:
            titles = self.entry['search_titles']
        finally:
            button.set_sensitive(True)
            button.set_label("Buscar en mis fuentes")
        search_in_sources(self.get_root(), titles, self.entry['title'])

    def on_web_clicked(self, button):
        if self.site_url:
            Gtk.UriLauncher(uri=self.site_url).launch(self.get_root(), None, None, None)
