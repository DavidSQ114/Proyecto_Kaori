import asyncio
import math
from gi.repository import Adw, Gdk, Gio, GLib, GObject, Gtk

from ...integrations import models
from .base import ReaderBase, adjacent_chapter
from .canvas import Canvas

PREFETCH_PAGES = 6
BANNER_RATIO = 2.2
SCROLL_SPEED = 800
SCROLL_ACCEL_TIME = 0.08
SCROLL_DECEL_TIME = 0.18
SCROLL_STOP_SPEED = 5
MAX_FRAME_DELTA = 0.05
PAGE_SCROLL_DURATION = 250
PAGE_SCROLL_RATIO = 0.9
AUTOSCROLL_DEAD_ZONE = 12
AUTOSCROLL_SPEED = 4  # px/s per px the pointer is away from the anchor
WHEEL_STEP = 150  # px per mouse wheel notch at 100% speed
WHEEL_SCROLL_DURATION = 180
BASE_WIDTH = 0.4  # "100%" in the width setting is 40% of the window width

class TransitionPage(models.Page):
    def __init__(self, chapter):
        super().__init__(index=-1, chapter_id=chapter.id)
        self.chapter = chapter


@Gtk.Template(resource_path='/io/github/riyaniii/Kaori/reader/webtoon.ui')
class WebtoonReader(ReaderBase):
    __gtype_name__ = "KaoriWebtoonReader"

    orientation = GObject.Property(type=Gtk.Orientation, default=Gtk.Orientation.VERTICAL)

    canvas = Gtk.Template.Child()

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.current_position = 0

        self.store = Gio.ListStore(item_type=models.Page)
        self.chapters = []
        self.loading = set()

        self.scroll_direction = 0
        self.scroll_velocity = 0.0
        self.tick_id = 0
        self.last_frame_time = 0

        self.page_animation = None
        self.page_progress = 0.0
        self.page_target = 0.0

        # Start at the width chosen in the reader settings (persisted globally)
        self.canvas.zoom = self.default_zoom

        self.canvas.bind_store(self.store)
        for name in ("orientation", "direction"):
            self.bind_property(name, self.canvas, name, GObject.BindingFlags.SYNC_CREATE)
        self.canvas.connect("page-changed", self.on_page_changed)

        self.connect("notify::chapter-model", self.on_chapter_model_changed)

        # Left-click drag pans the strip, like grabbing the page
        self.drag_origin = (0.0, 0.0)
        drag = Gtk.GestureDrag(button=Gdk.BUTTON_PRIMARY)
        drag.connect("drag-begin", self.on_drag_begin)
        drag.connect("drag-update", self.on_drag_update)
        drag.connect("drag-end", self.on_drag_end)
        self.add_controller(drag)

        # Middle click toggles browser-style autoscroll; any other click stops it
        self.autoscroll_anchor = None
        self.autoscroll_tick_id = 0
        self.autoscroll_last_time = 0
        autoscroll = Gtk.GestureClick(button=0, propagation_phase=Gtk.PropagationPhase.CAPTURE)
        autoscroll.connect("pressed", self.on_autoscroll_pressed)
        self.add_controller(autoscroll)

        # Mouse wheel notches scroll smoothly by a configurable step (touchpads keep native scrolling)
        wheel = Gtk.EventControllerScroll(
            flags=Gtk.EventControllerScrollFlags.VERTICAL,
            propagation_phase=Gtk.PropagationPhase.CAPTURE,
        )
        wheel.connect("scroll", self.on_wheel)
        self.add_controller(wheel)

    @property
    def scroll_speed(self):
        return Gio.Application.get_default().settings.get_double("scroll-speed")

    def reload_current(self, forget=True):
        self.canvas.reload_visible()

    @property
    def default_zoom(self):
        return BASE_WIDTH * Gio.Application.get_default().settings.get_double("webtoon-zoom")

    def reset_zoom(self):
        self.zoom_to(self.default_zoom, self.get_width() / 2, self.get_height() / 2)

    def toggle_fit_width(self, x=None, y=None):
        """Switch between filling the whole width and the configured width."""
        fitted = abs(self.zoom - 1.0) < 0.01
        target = self.default_zoom if fitted else 1.0
        self.zoom_to(target, self.get_width() / 2 if x is None else x, self.get_height() / 2 if y is None else y)

    def on_double_tap(self, gesture, n_press, x, y):
        if n_press == 2:
            self.toggle_fit_width(x, y)

    def bind_store(self, store: Gio.ListStore):
        pass

    @GObject.Property(type=int, default=0)
    def position(self):
        return self.current_position

    @position.setter
    def position(self, value):
        count = self.page_count
        self.current_position = max(0, min(value, count - 1)) if count else 0
        index = self.store_index(self.chapter_model, self.current_position)
        if index is not None:
            self.canvas.scroll_to_index(index)

    @property
    def zoom(self):
        return self.canvas.zoom

    def zoom_to(self, value, x, y):
        self.canvas.set_zoom_anchored(value, x, y)

    def scroll_page(self, direction):
        horizontal = self.orientation == Gtk.Orientation.HORIZONTAL
        size = self.canvas.get_width() if horizontal else self.canvas.get_height()
        self.scroll_smooth(direction * size * PAGE_SCROLL_RATIO, PAGE_SCROLL_DURATION)

    def on_wheel(self, controller, dx, dy):
        if controller.get_unit() != Gdk.ScrollUnit.WHEEL:
            return Gdk.EVENT_PROPAGATE
        if controller.get_current_event_state() & Gdk.ModifierType.CONTROL_MASK:
            return Gdk.EVENT_PROPAGATE  # Ctrl + wheel zooms (handled in ReaderBase)
        self.scroll_smooth(dy * WHEEL_STEP * self.scroll_speed, WHEEL_SCROLL_DURATION)
        return Gdk.EVENT_STOP

    def scroll_smooth(self, distance, duration):
        if self.page_animation is not None:
            distance += self.page_target - self.page_progress
            self.page_animation.pause()

        self.page_progress = 0.0
        self.page_target = distance
        self.page_animation = Adw.TimedAnimation.new(
            self,
            0.0,
            distance,
            duration,
            Adw.CallbackAnimationTarget.new(self.on_page_scroll),
        )
        self.page_animation.set_easing(Adw.Easing.EASE_OUT_CUBIC)
        self.page_animation.connect("done", self.on_page_scroll_done)
        self.page_animation.play()

    def on_page_scroll(self, value):
        self.canvas.scroll_by(value - self.page_progress)
        self.page_progress = value

    def on_page_scroll_done(self, animation):
        if animation is self.page_animation:
            self.page_animation = None

    def cancel_page_scroll(self):
        if self.page_animation is not None:
            self.page_animation.pause()
            self.page_animation = None

    def start_scrolling(self, direction):
        self.cancel_page_scroll()
        self.scroll_direction = direction
        if not self.tick_id:
            self.last_frame_time = self.get_frame_clock().get_frame_time()
            self.tick_id = self.add_tick_callback(self.on_tick)

    def stop_scrolling(self):
        self.scroll_direction = 0

    def on_tick(self, widget, frame_clock):
        frame_time = frame_clock.get_frame_time()
        elapsed = (frame_time - self.last_frame_time) / GLib.USEC_PER_SEC
        self.last_frame_time = frame_time
        elapsed = min(max(elapsed, 0.0), MAX_FRAME_DELTA)

        if not self.get_mapped():
            self.scroll_direction = 0
            self.scroll_velocity = 0.0
            self.tick_id = 0
            return GLib.SOURCE_REMOVE

        target = self.scroll_direction * SCROLL_SPEED * self.scroll_speed
        tau = SCROLL_ACCEL_TIME if self.scroll_direction else SCROLL_DECEL_TIME
        self.scroll_velocity += (target - self.scroll_velocity) * (1 - math.exp(-elapsed / tau))

        if not self.scroll_direction and abs(self.scroll_velocity) < SCROLL_STOP_SPEED:
            self.scroll_velocity = 0.0
            self.tick_id = 0
            return GLib.SOURCE_REMOVE

        self.canvas.scroll_by(self.scroll_velocity * elapsed)
        return GLib.SOURCE_CONTINUE

    @property
    def cross_adjustment(self):
        vertical = self.orientation == Gtk.Orientation.VERTICAL
        return self.canvas.hadjustment if vertical else self.canvas.vadjustment

    def on_drag_begin(self, gesture, x, y):
        if gesture.get_device().get_source() == Gdk.InputSource.TOUCHSCREEN:
            gesture.set_state(Gtk.EventSequenceState.DENIED)
            return
        self.cancel_page_scroll()
        self.drag_origin = (
            self.canvas.scroll_value(self.canvas.main_adjustment),
            self.canvas.scroll_value(self.cross_adjustment),
        )

    def on_drag_update(self, gesture, offset_x, offset_y):
        if offset_x or offset_y:
            self.set_cursor_from_name("grabbing")
        if self.orientation == Gtk.Orientation.VERTICAL:
            main_offset, cross_offset = offset_y, offset_x
        else:
            main_offset, cross_offset = offset_x, offset_y
        # scroll_value() is already flipped for right-to-left, so flip the horizontal offset too
        if self.canvas.mirrored:
            if self.orientation == Gtk.Orientation.VERTICAL:
                cross_offset = -cross_offset
            else:
                main_offset = -main_offset
        main_origin, cross_origin = self.drag_origin
        self.canvas.set_scroll_value(self.canvas.main_adjustment, main_origin - main_offset)
        self.canvas.set_scroll_value(self.cross_adjustment, cross_origin - cross_offset)

    def on_drag_end(self, gesture, offset_x, offset_y):
        self.set_cursor(None)

    def on_autoscroll_pressed(self, gesture, n_press, x, y):
        if self.autoscroll_anchor is not None:
            self.stop_autoscroll()
            gesture.set_state(Gtk.EventSequenceState.CLAIMED)
        elif gesture.get_current_button() == Gdk.BUTTON_MIDDLE:
            self.start_autoscroll(x, y)
            gesture.set_state(Gtk.EventSequenceState.CLAIMED)

    def start_autoscroll(self, x, y):
        self.cancel_page_scroll()
        self.autoscroll_anchor = (x, y)
        self.set_cursor_from_name("all-scroll")
        if not self.autoscroll_tick_id:
            self.autoscroll_last_time = self.get_frame_clock().get_frame_time()
            self.autoscroll_tick_id = self.add_tick_callback(self.on_autoscroll_tick)

    def stop_autoscroll(self):
        self.autoscroll_anchor = None
        self.set_cursor(None)

    def on_autoscroll_tick(self, widget, frame_clock):
        if self.autoscroll_anchor is None or not self.get_mapped():
            self.stop_autoscroll()
            self.autoscroll_tick_id = 0
            return GLib.SOURCE_REMOVE

        frame_time = frame_clock.get_frame_time()
        elapsed = min(max((frame_time - self.autoscroll_last_time) / GLib.USEC_PER_SEC, 0.0), MAX_FRAME_DELTA)
        self.autoscroll_last_time = frame_time

        axis = 1 if self.orientation == Gtk.Orientation.VERTICAL else 0
        distance = self.pointer[axis] - self.autoscroll_anchor[axis]
        if axis == 0 and self.canvas.mirrored:
            distance = -distance
        if abs(distance) > AUTOSCROLL_DEAD_ZONE:
            speed = math.copysign(abs(distance) - AUTOSCROLL_DEAD_ZONE, distance) * AUTOSCROLL_SPEED * self.scroll_speed
            self.canvas.scroll_by(speed * elapsed)
        return GLib.SOURCE_CONTINUE

    def find_chapter(self, chapter_id):
        return next((chapter for chapter in self.chapters if chapter.id == chapter_id), None)

    def store_index(self, chapter, position):
        if chapter is None:
            return None
        return next(
            (
                index
                for index, page in enumerate(self.store)
                if page.chapter_id == chapter.id and page.index == position
            ),
            None,
        )

    def on_chapter_model_changed(self, reader, pspec):
        chapter = self.chapter_model
        if chapter is None or self.find_chapter(chapter.id) is not None:
            return
        self.chapters = []
        self.store.remove_all()
        asyncio.create_task(self.load_chapter_pages(chapter, prepend=False))

    async def load_chapter_pages(self, chapter, prepend: bool):
        side = "before" if prepend else "after"
        self.loading.add(side)
        try:
            pages = await self.suwayomi.getChapterPages(chapter.id)
        except Exception:
            return
        finally:
            self.loading.discard(side)

        banner = [TransitionPage(chapter)] if self.chapters else []
        block = banner + pages

        if prepend:
            self.chapters.insert(0, chapter)
            banner_index = 0
        else:
            self.chapters.append(chapter)
            banner_index = self.store.get_n_items()
        self.store.splice(banner_index, 0, block)

        if banner:
            self.canvas.set_ratio(banner_index, BANNER_RATIO)

        self.position = self.current_position

    def maybe_prefetch(self, page):
        if not self.chapters:
            return

        leading, trailing = self.chapters[0], self.chapters[-1]

        near_start = page.chapter_id == leading.id and page.index < PREFETCH_PAGES
        if near_start and "before" not in self.loading:
            if previous := adjacent_chapter(self.manga_model, leading, -1):
                asyncio.create_task(self.load_chapter_pages(previous, prepend=True))

        near_end = page.chapter_id == trailing.id and trailing.page_count - page.index <= PREFETCH_PAGES
        if near_end and "after" not in self.loading:
            if following := adjacent_chapter(self.manga_model, trailing, 1):
                asyncio.create_task(self.load_chapter_pages(following, prepend=False))

    def on_page_changed(self, canvas, index):
        page = self.store.get_item(index)
        self.maybe_prefetch(page)

        if page.index < 0:
            return

        if page.chapter_id != self.chapter_model.id:
            self.mark_chapter_read(self.chapter_model)
            self.chapter_model = self.find_chapter(page.chapter_id)

        if page.index != self.current_position:
            self.current_position = page.index
            self.notify("position")

    def mark_chapter_read(self, chapter):
        if chapter.is_read:
            return
        asyncio.create_task(
            self.suwayomi.updateChapter(
                chapter_id=chapter.id,
                is_read=True,
                last_page_read=chapter.page_count,
            )
        )
